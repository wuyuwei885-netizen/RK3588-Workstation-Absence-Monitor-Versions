from __future__ import annotations

import copy
import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict


DEFAULT_CONFIG: Dict[str, Any] = {
    "app": {
        "host": "0.0.0.0",
        "port": 8090,
        "data_dir": "/root/workstation/worker17/data",
        "database": "/root/workstation/worker17/data/workstation.db",
        "enrollment_dir": "/root/workstation/worker17/data/face_data",
        "event_dir": "/root/workstation/worker17/data/events",
    },
    "camera": {
        "device": "/dev/video22",
        "width": 1920,
        "height": 1080,
        "fps": 20,
        "warmup": 10,
        "buffers": 4,
        "pixel_format": "NV12",
    },
    "models": {
        "pose": {
            "enabled": True,
            "path": "/root/yolov8_rk3588/code/model/yolov8n-pose-int8.rknn",
            "input_size": 640,
            "input_layout": "nhwc",
            "core": "0",
            "quantization": "INT8",
            "toolkit_version": "2.3.2",
            "confidence": 0.45,
            "nms": 0.40,
            "keypoint_confidence": 0.35,
        },
        "retinaface": {
            "enabled": True,
            "path": "/root/yolov8_rk3588/code/model/RetinaFace_mobile320-int8.rknn",
            "input_size": 320,
            "input_layout": "nhwc",
            "core": "1",
            "quantization": "INT8",
            "toolkit_version": "2.3.2",
            "candidate_confidence": 0.02,
            "confidence": 0.25,
            "nms": 0.50,
        },
        "face_recognition": {
            "enabled": True,
            "path": "/root/yolov8_rk3588/code/model/w600k_mbf-int8-calib500.rknn",
            "input_width": 112,
            "input_height": 112,
            "input_layout": "nhwc",
            "color": "rgb",
            "core": "2",
            "quantization": "INT8",
            "toolkit_version": "2.3.2",
            "normalize": False,
            "scale": 1.0,
            "mean": [0.0, 0.0, 0.0],
            "std": [1.0, 1.0, 1.0],
            "output_index": 0,
            "similarity_threshold": 0.55,
        },
    },
    "rknn": {
        "platform": "RK3588",
        "backend": "RKNNLite",
        "runtime_version_observed": "2.0.0b0",
        "driver_version_observed": "0.9.6",
        "metrics_window": 300
    },
    "runtime": {
        "pose_fps": 10.0,
        "face_fps": 3.0,
        "preview_fps": 10.0,
        "jpeg_quality": 75,
        "face_recognition_cooldown_sec": 1.5,
        "binding_ttl_sec": 20.0,
        "track_thresh": 0.45,
        "track_low_thresh": 0.10,
        "new_track_thresh": 0.55,
        "match_thresh": 0.75,
        "track_buffer": 30,
        "max_faces_per_cycle": 4,
    },
    "enrollment": {
        "minimum_samples": 5,
        "maximum_samples": 10,
        "required_slots": ["front", "left", "right", "up_down", "work"],
        "minimum_face_width": 100,
        "minimum_blur_score": 45.0,
        "minimum_detection_score": 0.60,
        "minimum_brightness": 45.0,
        "maximum_brightness": 220.0,
    },
    "presence": {
        "default_away_threshold_sec": 180,
        "default_grace_sec": 5,
        "default_return_confirm_sec": 2,
        "hip_keypoint_confidence": 0.30,
    },
    "fall_detection": {
        "enabled": True,
        "detect_unknown_person": True,
        "keypoint_confidence": 0.35,
        "bbox_aspect_ratio": 0.85,
        "torso_angle_deg": 55.0,
        "shoulder_hip_vertical_ratio": 0.25,
        "keypoint_vertical_spread_ratio": 0.42,
        "downward_speed_ratio_per_sec": 0.18,
        "minimum_score": 3,
        "recovery_score": 1,
        "confirm_seconds": 1.2,
        "recovery_seconds": 1.5,
        "track_expire_seconds": 3.0,
        "cooldown_seconds": 10.0,
        "snapshot_enabled": True,
    },
    "control": {
        "host": "0.0.0.0",
        "port": 8091,
        "main_service": "workstation-absence.service",
        "main_port": 8090,
        "status_timeout_sec": 1.2,
    },
}


def _merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _merge(result[key], value)
        else:
            result[key] = value
    return result


def _expand(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: _expand(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_expand(item) for item in value]
    if isinstance(value, str):
        return os.path.expanduser(os.path.expandvars(value))
    return value


@dataclass(frozen=True)
class AppConfig:
    raw: Dict[str, Any]
    source_path: Path

    @property
    def app(self) -> Dict[str, Any]:
        return self.raw["app"]

    @property
    def camera(self) -> Dict[str, Any]:
        return self.raw["camera"]

    @property
    def models(self) -> Dict[str, Any]:
        return self.raw["models"]

    @property
    def rknn(self) -> Dict[str, Any]:
        return self.raw["rknn"]

    @property
    def runtime(self) -> Dict[str, Any]:
        return self.raw["runtime"]

    @property
    def enrollment(self) -> Dict[str, Any]:
        return self.raw["enrollment"]

    @property
    def presence(self) -> Dict[str, Any]:
        return self.raw["presence"]

    @property
    def fall_detection(self) -> Dict[str, Any]:
        return self.raw["fall_detection"]

    @property
    def control(self) -> Dict[str, Any]:
        return self.raw["control"]

    def ensure_directories(self) -> None:
        for key in ("data_dir", "enrollment_dir", "event_dir"):
            Path(self.app[key]).mkdir(parents=True, exist_ok=True)
        Path(self.app["database"]).parent.mkdir(parents=True, exist_ok=True)


def load_config(path: str | Path) -> AppConfig:
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"配置文件不存在：{source}")
    override = json.loads(source.read_text(encoding="utf-8"))
    config = AppConfig(_expand(_merge(DEFAULT_CONFIG, override)), source)
    config.ensure_directories()
    return config
