# RK3588 工作台空岗检测 v1.0.6

本版本基于以下顺序整合：

```text
workstation_absence_rk3588_full
  → 覆盖 v1.0.4
  → 覆盖 v1.0.5
  → 集成 v1.0.6 三种排班模式、批量排班、区域缺员和请假审批
```

## 1. 系统链路

```text
IMX219 / V4L2
  → YOLOv8-Pose
  → ByteTrack
  → RetinaFace + W600K 人脸特征
  → employee_id ↔ track_id
  → 人体锚点进入工作台 ROI
  → 个人到岗/缺勤状态机
  → 工作台区域缺员状态机
  → FastAPI 现有五个页面
```

本版本没有新增独立 Web。全部功能直接加入原来的：

```text
排班配置 /schedule
实时监控 /monitor
历史记录 /history
```

## 2. 三种排班模式

### single

- 本轮只能选择 1 名员工；
- 不允许追加第二名员工；
- 个人缺勤和工作台区域缺员分别记录，并使用同一个 `incident_id` 关联。

### per_employee

- 同一工作台允许多人；
- 每名员工独立记录首次到岗、个人缺勤和返回；
- 工作台区域要求人数等于本轮活动员工总数；
- 任意员工不在岗都会触发区域缺员状态机；
- 同一工作台同时只保留一条区域缺员事件。

### minimum_staff

- 同一工作台允许多人；
- 区域要求人数为本轮配置的 `Nmin`；
- 允许第一批排班人数小于 `Nmin`；
- 即使区域仍满足 `Nmin`，离岗员工仍独立生成个人缺勤记录；
- 请假批准不会反向修改已结束班次的区域事实。

## 3. 本轮排班锁定规则

排班配置页面支持员工卡片多选和批量提交。

```text
第一批员工开始
  → 创建工作台本轮 round
  → 锁定 mode / Nmin / 首次到岗等待 / GRACE / ALERT / RETURN

本轮运行中
  → 可批量追加员工
  → 追加员工必须沿用全部锁定参数
  → 已在本轮员工不能取消
  → 单个员工不能下班

点击全部下班
  → 同一工作台所有员工同时结束
  → 所有 OPEN 个人缺勤和区域缺员自动关闭
  → 从未首次到岗的员工生成 NO_SHOW 记录
  → 本轮参数解除锁定
```

批量加入采用事务语义：任何一名员工不合法，整批失败。

## 4. 时间参数

默认值：

```text
首次到岗等待：10 分钟
GRACE：5 秒
ALERT：180 秒
RETURN：2 秒
Track 丢失绑定保留：5 秒
```

时间参数在每轮开始前配置，第一批开始后锁定。

首次到岗要求：

```text
人脸识别为排班员工
  + 对应人体 Track 有效
  + 人体锚点位于该工作台 ROI
```

员工首次到岗后，即使转身或脸被遮挡，只要原人体 Track 仍存在，继续算在岗。Track 消失后保留绑定 5 秒，再进入 GRACE。

## 5. 首次到岗与区域暂停

- 每名员工按自己的加入时间计算首次到岗等待；
- 超时后生成 `未到岗/迟到` 个人记录；
- 后续首次到岗时自动关闭，并记录实际迟到时长；
- 即使在等待上限内点击全部下班，从未到岗员工仍生成 NO_SHOW；
- 只要存在首次到岗等待员工，区域缺员计时可以暂停；
- 每轮累计暂停上限自动等于首次到岗等待上限；
- 暂停额度耗尽后，从原有区域缺员累计时长继续，不清零；
- 摄像头断流、模型异常、服务重启期间均不累计缺勤时间。

## 6. 个人缺勤、区域缺员和关联

所有模式同时运行两类状态机：

```text
个人：WAITING → PRESENT → GRACE → AWAY → ALERT
区域：WAITING/PRESENT → GRACE → AWAY → ALERT
```

同一次异常使用同一个 `incident_id`。区域缺员记录不能申请请假。

## 7. 请假审批

请假只允许在本轮全部下班、个人缺勤事件已经关闭后操作。

```text
个人缺勤 CLOSED
  → 填写备注申请请假
  → PENDING
  → 管理员批准或驳回

驳回
  → 可修改备注后重新申请

批准
  → 原缺勤记录在普通缺勤分类中归档
  → 在“已批准请假”分类显示
  → 原时间、截图、持续时长和完整审批审计仍保留
  → 关联区域缺员显示“关联缺勤已批准请假”
```

旧版历史数据保留为 `legacy`，不反向推导区域缺员，也不开放新请假流程。

## 8. 板端完整包部署

```bash
source /root/yolov8_rk3588/rknn310/bin/activate

cd /root
mv workstation_absence "workstation_absence.before_v106.$(date +%Y%m%d_%H%M%S)"
unzip -o workstation_absence_v1.0.6_full.zip -d /root
mv /root/workstation_absence_v1.0.6_full /root/workstation/worker16

cd /root/workstation/worker16
cp -n config.example.json config.json
python -m pip install -r requirements-rk3588.txt

export PYTHONPATH=/root/workstation/worker16
python -m compileall -q workstation
python -m unittest discover -s tests -v
python app.py --config config.json
```

浏览器：

```text
http://RK3588_IP:8090/schedule
```

## 9. 补丁包升级

解压补丁后执行 Python 脚本，不需要 `.sh`：

```bash
source /root/yolov8_rk3588/rknn310/bin/activate

cd /root
unzip -o workstation_absence_v1.0.6_patch_only.zip -d /root

cd /root/_patch_v106
python apply_patch.py --target /root/workstation/worker16
```

脚本自动完成：

- 备份被修改的代码、模板和静态文件；
- 备份 `config.json` 和 JSON 数据库；
- 覆盖 v1.0.6 文件；
- 将 `runtime.binding_ttl_sec` 更新为 5 秒；
- 触发数据库兼容迁移；
- 运行 Python 语法检查。

升级后：

```bash
source /root/yolov8_rk3588/rknn310/bin/activate
cd /root/workstation/worker16
export PYTHONPATH=/root/workstation/worker16
python -m unittest discover -s tests -v
python app.py --config config.json
```

浏览器按 `Ctrl+F5` 强制刷新。

## 10. 验证清单

```text
[ ] single 批量选择第二人被拒绝
[ ] per_employee 可批量选择多人
[ ] minimum_staff 可用少于 Nmin 的人数创建本轮
[ ] 第一批开始后参数变为只读
[ ] 运行中可批量追加员工
[ ] 非法员工导致整批失败
[ ] 页面不存在单人下班按钮
[ ] 全部下班无需二次确认
[ ] 员工首次进入 ROI 后显示 PRESENT
[ ] Track 短时丢失 5 秒内不进入 GRACE
[ ] 个人离岗和区域缺员同时生成，incident_id 相同
[ ] minimum_staff 满足人数时仍记录个人离岗
[ ] 摄像头离线期间计时暂停
[ ] 下班后才可申请请假
[ ] 批准后出现在“已批准请假”筛选中
[ ] 区域记录显示关联请假标记
```
