#!/usr/bin/env python3
from __future__ import annotations

import argparse
import logging

import uvicorn

from workstation.camera import CameraManager
from workstation.config import load_config
from workstation.database import Database
from workstation.enrollment import EnrollmentService
from workstation.models import ModelHub
from workstation.runtime import RuntimeService
from workstation.web import AlertBus, create_app


def parse_args():
    parser = argparse.ArgumentParser(description="RK3588工作台空岗检测系统")
    parser.add_argument("--config", default="config.json", help="配置文件路径")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    logging.basicConfig(level=20, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    config = load_config(args.config)
    database = Database(config.app["database"])
    camera = CameraManager(config.camera)
    models = ModelHub(config.models)
    alerts = AlertBus()
    enrollment = EnrollmentService(
        camera=camera,
        models=models,
        database=database,
        enrollment_dir=config.app["enrollment_dir"],
        config=config.enrollment,
    )
    runtime = RuntimeService(
        camera=camera,
        models=models,
        database=database,
        runtime_config=config.runtime,
        presence_config=config.presence,
        event_dir=config.app["event_dir"],
        alert_callback=alerts.publish,
    )
    app = create_app(
        config=config,
        camera=camera,
        models=models,
        database=database,
        enrollment=enrollment,
        runtime=runtime,
        alerts=alerts,
    )
    uvicorn.run(
        app,
        host=config.app["host"],
        port=int(config.app["port"]),
        log_config=None,
        log_level=20,
        access_log=False,
    )


if __name__ == "__main__":
    main()
