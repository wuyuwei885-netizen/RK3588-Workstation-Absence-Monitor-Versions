# v1.8.0-dual-camera

- 在 v1.0.7.5 / 1.7 业务基础上新增双摄像头多区域并发检测。
- 新增 MultiCameraManager，每路 V4L2 独立 FrameSlot。
- 新增 MultiCameraRuntime，每路独立 ByteTrack / Identity / Presence / Fall 状态。
- RKNN ModelHub 共享，沿用模型锁与 Core0/Core1/Core2 分配。
- 工作台按 camera_device 严格隔离，避免跨摄像头 ROI/告警串线。
- 摄像头掉线只影响所属区域，并暂停其 Presence 计时。
- 新增 camera-specific MJPEG / snapshot API。
- 监控页升级为专业多视觉节点控制台，并加入响应式布局。
- 人脸录入、工作台ROI、历史记录支持摄像头选择/显示。
- 新增双摄节点探测与配置生成工具。
- 新增多摄业务隔离测试；当前 19 tests passed。

# CHANGELOG

## 1.0.7.5
- 支持用户固定命令直接启动；自动停止旧的同项目 app.py，避免 8090 Address already in use。
- app.py 自动维护 /var/run/workstation-absence.pid，手机控制后台可管理手工启动进程。
- 新增 /npu NPU量化与推理数据后台。
- 记录真实 RKNNLite inference 调用次数、延迟 Avg/P50/P95、实际调度FPS、理论FPS、输入dtype/shape、模型大小与NPU Core。
- 新增离线量化精度数据录入，保存至 data/model_evaluation.json。
- 不下载或替换 RKNN Runtime，不修改 rknn310 虚拟环境。
