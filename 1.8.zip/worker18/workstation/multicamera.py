from __future__ import annotations

import threading
from typing import Any, Dict, List

from .camera import CameraManager, FrameSlot


class MultiCameraManager:
    """管理多路独立V4L2摄像头。

    兼容旧CameraManager常用接口：
    - active_device / frames / online：表示当前UI/录入选中的摄像头
    - switch(device)：只切换UI/录入选择，不停止其他摄像头
    - start()/stop()：同时启动/停止全部配置摄像头
    """

    def __init__(self, camera_configs: List[Dict[str, Any]]) -> None:
        if not camera_configs:
            raise ValueError("至少需要配置一路摄像头")

        self._lock = threading.RLock()
        self._by_id: Dict[str, CameraManager] = {}
        self._id_by_device: Dict[str, str] = {}
        self._specs: Dict[str, Dict[str, Any]] = {}

        for index, raw in enumerate(camera_configs, start=1):
            spec = dict(raw)
            camera_id = str(spec.get("id") or f"cam{index}").strip()
            device = str(spec.get("device") or "").strip()
            if not camera_id:
                raise ValueError(f"第{index}路摄像头缺少id")
            if not device:
                raise ValueError(f"摄像头{camera_id}缺少device")
            if camera_id in self._by_id:
                raise ValueError(f"重复摄像头id：{camera_id}")
            if device in self._id_by_device:
                raise ValueError(f"重复摄像头节点：{device}")

            spec.setdefault("name", f"Camera {index}")
            spec.setdefault("location", f"位置{index}")
            manager = CameraManager(spec)
            self._by_id[camera_id] = manager
            self._id_by_device[device] = camera_id
            self._specs[camera_id] = spec

        self._selected_id = next(iter(self._by_id))

    @property
    def camera_ids(self) -> List[str]:
        return list(self._by_id.keys())

    @property
    def primary_id(self) -> str:
        return self.camera_ids[0]

    @property
    def selected_id(self) -> str:
        with self._lock:
            return self._selected_id

    @property
    def active_device(self) -> str:
        return self.manager_for_id(self.selected_id).active_device

    @property
    def frames(self) -> FrameSlot:
        return self.manager_for_id(self.selected_id).frames

    @property
    def online(self) -> bool:
        return self.manager_for_id(self.selected_id).online

    def manager_for_id(self, camera_id: str) -> CameraManager:
        try:
            return self._by_id[str(camera_id)]
        except KeyError as exc:
            raise KeyError(f"未知摄像头ID：{camera_id}") from exc

    def manager_for_device(self, device: str) -> CameraManager:
        camera_id = self._id_by_device.get(str(device))
        if camera_id is None:
            raise KeyError(f"摄像头未配置：{device}")
        return self._by_id[camera_id]

    def id_for_device(self, device: str) -> str:
        camera_id = self._id_by_device.get(str(device))
        if camera_id is None:
            raise KeyError(f"摄像头未配置：{device}")
        return camera_id

    def spec_for_id(self, camera_id: str) -> Dict[str, Any]:
        return dict(self._specs[str(camera_id)])

    def spec_for_device(self, device: str) -> Dict[str, Any]:
        return self.spec_for_id(self.id_for_device(device))

    def start(self) -> None:
        for manager in self._by_id.values():
            manager.start()

    def stop(self) -> None:
        for manager in self._by_id.values():
            manager.stop()

    def switch(self, device: str) -> None:
        """切换前端ROI预览/人脸录入来源，不关闭其他正在检测的摄像头。"""
        camera_id = self.id_for_device(device)
        with self._lock:
            self._selected_id = camera_id

    def switch_id(self, camera_id: str) -> None:
        self.manager_for_id(camera_id)
        with self._lock:
            self._selected_id = str(camera_id)

    def configured(self) -> List[Dict[str, Any]]:
        result: List[Dict[str, Any]] = []
        for camera_id in self.camera_ids:
            manager = self.manager_for_id(camera_id)
            spec = self.spec_for_id(camera_id)
            result.append(
                {
                    "id": camera_id,
                    "name": str(spec.get("name", camera_id)),
                    "location": str(spec.get("location", "")),
                    "device": manager.active_device,
                    "width": int(spec["width"]),
                    "height": int(spec["height"]),
                    "fps": int(spec["fps"]),
                    "pixel_format": str(spec.get("pixel_format", "NV12")),
                    "online": manager.online,
                    "selected": camera_id == self.selected_id,
                }
            )
        return result

    def status(self) -> Dict[str, Any]:
        cameras = []
        online_count = 0
        for camera_id in self.camera_ids:
            spec = self.spec_for_id(camera_id)
            item = self.manager_for_id(camera_id).status()
            item.update(
                {
                    "id": camera_id,
                    "name": str(spec.get("name", camera_id)),
                    "location": str(spec.get("location", "")),
                }
            )
            cameras.append(item)
            if item.get("online"):
                online_count += 1
        return {
            "online": online_count == len(cameras) and bool(cameras),
            "degraded": 0 < online_count < len(cameras),
            "online_count": online_count,
            "total_count": len(cameras),
            "active_device": self.active_device,
            "selected_id": self.selected_id,
            "cameras": cameras,
        }
