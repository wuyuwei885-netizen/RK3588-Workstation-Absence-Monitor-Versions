from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np

from .database import Database, now_iso, parse_iso
from .geometry import point_in_polygon
from .identity import IdentityBinding
from .tracker import Track


@dataclass
class ShiftStatus:
    shift_id: int
    round_id: int
    employee_id: int
    employee_code: str
    employee_name: str
    workstation_id: int
    workstation_name: str
    mode: str
    state: str
    business_state: str
    present: bool
    track_id: Optional[int]
    similarity: Optional[float]
    latest_recognition_at: Optional[str]
    first_present_at: Optional[str]
    arrival_elapsed_sec: int
    arrival_remaining_sec: int
    elapsed_away_sec: int
    remaining_to_alert_sec: int
    last_present_at: Optional[str]
    away_started_at: Optional[str]
    alert_at: Optional[str]
    other_person_count: int
    observable: bool
    message: str


@dataclass
class RegionStatus:
    round_id: int
    workstation_id: int
    workstation_name: str
    mode: str
    state: str
    observable: bool
    assigned_count: int
    present_count: int
    required_count: int
    shortage_count: int
    waiting_arrival_count: int
    elapsed_shortage_sec: int
    remaining_to_alert_sec: int
    arrival_pause_used_sec: int
    arrival_pause_remaining_sec: int
    incident_id: Optional[str]
    message: str


class PresenceManager:
    MAX_CONTINUOUS_TICK_GAP_SEC = 2.5

    def __init__(
        self,
        *,
        database: Database,
        event_dir: str | Path,
        hip_confidence: float,
        binding_hold_sec: float = 5.0,
        alert_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> None:
        self.database = database
        self.event_dir = Path(event_dir)
        self.event_dir.mkdir(parents=True, exist_ok=True)
        self.hip_confidence = float(hip_confidence)
        self.binding_hold_sec = max(0.0, float(binding_hold_sec))
        self.alert_callback = alert_callback

    def anchor(self, track: Track) -> Tuple[float, float]:
        keypoints = np.asarray(track.keypoints)
        if keypoints.shape == (17, 3):
            left_hip = keypoints[11]
            right_hip = keypoints[12]
            if left_hip[2] >= self.hip_confidence and right_hip[2] >= self.hip_confidence:
                return (
                    float((left_hip[0] + right_hip[0]) / 2.0),
                    float((left_hip[1] + right_hip[1]) / 2.0),
                )
        x1, y1, x2, y2 = track.bbox
        return float((x1 + x2) / 2.0), float(y1 + (y2 - y1) * 0.65)

    def _snapshot(self, frame: Optional[np.ndarray], scope_key: str, suffix: str) -> Optional[str]:
        if frame is None:
            return None
        folder = self.event_dir / datetime.now().strftime("%Y-%m-%d")
        folder.mkdir(parents=True, exist_ok=True)
        safe_scope = scope_key.replace(":", "_")
        path = folder / f"{safe_scope}_{datetime.now().strftime('%H%M%S_%f')}_{suffix}.jpg"
        return str(path) if cv2.imwrite(str(path), frame) else None

    @staticmethod
    def _delta_seconds(runtime: Dict[str, Any], now: datetime, observable: bool) -> float:
        previous = parse_iso(runtime.get("last_tick_at") or runtime.get("updated_at"))
        if previous is None or not observable:
            return 0.0
        delta = max(0.0, (now - previous).total_seconds())
        # 服务重启、摄像头断流、模型阻塞期间不可观测，不计入缺勤。
        return delta if delta <= PresenceManager.MAX_CONTINUOUS_TICK_GAP_SEC else 0.0

    @staticmethod
    def _iso_or_none(value: Any) -> Optional[str]:
        if value is None:
            return None
        if isinstance(value, datetime):
            return value.isoformat(timespec="seconds")
        return str(value)

    def _load_shift_runtime(self, shift: Dict[str, Any]) -> Dict[str, Any]:
        shift_id = int(shift["id"])
        runtime = self.database.get_runtime_state(f"shift:{shift_id}") or {}
        # 兼容 v1.0.5 runtime_state。
        if "absence_elapsed_sec" not in runtime:
            away_started = parse_iso(runtime.get("away_started_at"))
            if away_started:
                runtime["absence_elapsed_sec"] = max(
                    0.0, (datetime.now().astimezone() - away_started).total_seconds()
                )
            else:
                runtime["absence_elapsed_sec"] = 0.0
        runtime.setdefault("state", "WAITING")
        runtime.setdefault("business_state", runtime.get("state", "WAITING"))
        runtime.setdefault("first_present_at", runtime.get("last_present_at"))
        runtime.setdefault("last_present_at", runtime.get("last_present_at"))
        runtime.setdefault("arrival_elapsed_sec", 0.0)
        runtime.setdefault("absence_elapsed_sec", 0.0)
        runtime.setdefault("return_elapsed_sec", 0.0)
        runtime.setdefault("track_missing_elapsed_sec", 0.0)
        runtime.setdefault("away_started_at", runtime.get("away_started_at"))
        runtime.setdefault("alert_at", runtime.get("alert_at"))
        runtime.setdefault("incident_id", None)
        runtime.setdefault("last_tick_at", runtime.get("updated_at"))
        return runtime

    def _load_region_runtime(self, round_id: int) -> Dict[str, Any]:
        runtime = self.database.get_runtime_state(f"round:{round_id}") or {}
        runtime.setdefault("state", "WAITING")
        runtime.setdefault("business_state", runtime.get("state", "WAITING"))
        runtime.setdefault("shortage_elapsed_sec", 0.0)
        runtime.setdefault("return_elapsed_sec", 0.0)
        runtime.setdefault("arrival_pause_used_sec", 0.0)
        runtime.setdefault("shortage_started_at", None)
        runtime.setdefault("alert_at", None)
        runtime.setdefault("incident_id", None)
        runtime.setdefault("last_tick_at", runtime.get("updated_at"))
        return runtime

    def _save_shift_runtime(self, shift_id: int, runtime: Dict[str, Any], now: datetime) -> None:
        payload = dict(runtime)
        payload.pop("scope_key", None)
        payload.pop("updated_at", None)
        payload["last_tick_at"] = now.isoformat(timespec="seconds")
        self.database.save_runtime_state(scope_key=f"shift:{shift_id}", **payload)

    def _save_region_runtime(self, round_id: int, runtime: Dict[str, Any], now: datetime) -> None:
        payload = dict(runtime)
        payload.pop("scope_key", None)
        payload.pop("updated_at", None)
        payload["last_tick_at"] = now.isoformat(timespec="seconds")
        self.database.save_runtime_state(scope_key=f"round:{round_id}", **payload)

    def evaluate(
        self,
        *,
        frame: Optional[np.ndarray],
        frame_width: int,
        frame_height: int,
        tracks: Sequence[Track],
        bindings: Dict[int, IdentityBinding],
        camera_online: bool,
        active_camera_device: str,
    ) -> Tuple[List[ShiftStatus], List[RegionStatus]]:
        now = datetime.now().astimezone()
        active_rounds = self.database.active_rounds()
        shift_results: List[ShiftStatus] = []
        region_results: List[RegionStatus] = []
        track_by_id = {track.track_id: track for track in tracks}

        # IdentityService 已确保同一员工最多一个绑定。若迁移缓存异常，仍优先旧字典顺序。
        binding_by_employee: Dict[int, Tuple[int, IdentityBinding]] = {}
        for track_id, binding in bindings.items():
            binding_by_employee.setdefault(int(binding.employee_id), (track_id, binding))

        for round_item in active_rounds:
            round_id = int(round_item["id"])
            workstation_id = int(round_item["workstation_id"])
            mode = str(round_item["mode"])
            shifts = [item for item in round_item.get("shifts", []) if item.get("status") == "ACTIVE"]
            if not shifts:
                continue

            # v1.8 多摄像头：每个Runtime只处理绑定到自己的工作台。
            # 这样Camera-A不会把Camera-B的班次写成CAMERA_OFFLINE，也不会互相覆盖runtime_state。
            bound_device = str(shifts[0].get("camera_device"))
            if bound_device != str(active_camera_device):
                continue

            roi = shifts[0].get("roi", [])
            observable = bool(camera_online and len(roi) >= 3)
            observable_state = (
                "CAMERA_OFFLINE"
                if not camera_online
                else "UNCONFIGURED"
                if len(roi) < 3
                else None
            )

            observations: Dict[int, Dict[str, Any]] = {}
            all_inside = [
                track
                for track in tracks
                if len(roi) >= 3 and point_in_polygon(self.anchor(track), roi, frame_width, frame_height)
            ]
            for shift in shifts:
                employee_id = int(shift["employee_id"])
                pair = binding_by_employee.get(employee_id)
                track_id: Optional[int] = pair[0] if pair else None
                binding = pair[1] if pair else None
                track = track_by_id.get(track_id) if track_id is not None else None
                raw_present = bool(
                    track is not None
                    and len(roi) >= 3
                    and point_in_polygon(self.anchor(track), roi, frame_width, frame_height)
                )
                other_count = sum(1 for item in all_inside if track is None or item.track_id != track.track_id)
                observations[int(shift["id"])] = {
                    "raw_present": raw_present,
                    "track_id": track_id,
                    "binding": binding,
                    "other_count": other_count,
                }

            # 先确定区域 incident_id，使同一次个人缺勤和区域缺员可以关联。
            region_runtime = self._load_region_runtime(round_id)
            preliminary_waiting = 0
            preliminary_present = 0
            for shift in shifts:
                sr = self._load_shift_runtime(shift)
                obs = observations[int(shift["id"])]
                if sr.get("first_present_at") is None and not obs["raw_present"]:
                    preliminary_waiting += 1
                if obs["raw_present"]:
                    preliminary_present += 1
            required_count = int(round_item["minimum_staff"]) if mode == "minimum_staff" else len(shifts)
            preliminary_shortage = preliminary_present < required_count
            if preliminary_shortage and not region_runtime.get("incident_id"):
                region_runtime["incident_id"] = self.database.new_incident_id()

            confirmed_present = 0
            waiting_count = 0
            for shift in shifts:
                shift_id = int(shift["id"])
                employee_id = int(shift["employee_id"])
                obs = observations[shift_id]
                binding: Optional[IdentityBinding] = obs["binding"]
                runtime = self._load_shift_runtime(shift)
                delta = self._delta_seconds(runtime, now, observable)
                previous_business = str(runtime.get("business_state", "WAITING"))
                first_present_at = runtime.get("first_present_at")
                raw_present = bool(obs["raw_present"] and observable)
                track_hold_active = False
                if raw_present:
                    runtime["track_missing_elapsed_sec"] = 0.0
                elif observable and first_present_at is not None and binding is not None and obs["track_id"] is not None:
                    # 身份绑定仍存在但人体 Track 暂时不在当前输出中，先保留 5 秒。
                    runtime["track_missing_elapsed_sec"] = float(runtime.get("track_missing_elapsed_sec", 0.0)) + delta
                    track_hold_active = runtime["track_missing_elapsed_sec"] < self.binding_hold_sec
                    if track_hold_active and previous_business == "PRESENT":
                        raw_present = True
                else:
                    runtime["track_missing_elapsed_sec"] = 0.0
                event_scope_key = f"shift:{shift_id}"
                common_incident = region_runtime.get("incident_id") if preliminary_shortage else None

                if not observable:
                    state = str(observable_state)
                    business_state = previous_business
                    present = False
                    message = "摄像头或模型不可观测，所有业务计时已暂停"
                elif first_present_at is None:
                    if raw_present:
                        first_present_at = now.isoformat(timespec="seconds")
                        runtime["first_present_at"] = first_present_at
                        runtime["last_present_at"] = first_present_at
                        business_state = "PRESENT"
                        state = "PRESENT"
                        present = True
                        runtime["return_elapsed_sec"] = 0.0
                        no_show = self.database.get_open_event(scope_key=event_scope_key, event_type="NO_SHOW")
                        if no_show:
                            self.database.close_event(
                                int(no_show["id"]),
                                return_at=now.isoformat(timespec="seconds"),
                                duration_sec=int(round(float(runtime.get("arrival_elapsed_sec", 0.0)))),
                                return_snapshot=self._snapshot(frame, event_scope_key, "arrival"),
                                closed_reason="ARRIVED",
                            )
                        message = "员工首次进入 ROI，已完成到岗确认"
                    else:
                        runtime["arrival_elapsed_sec"] = float(runtime.get("arrival_elapsed_sec", 0.0)) + delta
                        arrival_elapsed = float(runtime["arrival_elapsed_sec"])
                        arrival_limit = int(round_item["first_arrival_wait_sec"])
                        present = False
                        if arrival_elapsed < arrival_limit:
                            business_state = "WAITING"
                            state = "WAITING"
                            waiting_count += 1
                            message = "等待员工首次识别并进入 ROI"
                        else:
                            business_state = "NO_SHOW"
                            state = "NO_SHOW"
                            incident_id = common_incident or runtime.get("incident_id") or self.database.new_incident_id()
                            runtime["incident_id"] = incident_id
                            event = self.database.get_open_event(scope_key=event_scope_key, event_type="NO_SHOW")
                            if event is None:
                                event_id = self.database.open_event(
                                    event_scope="PERSONAL",
                                    event_type="NO_SHOW",
                                    scope_key=event_scope_key,
                                    incident_id=incident_id,
                                    round_id=round_id,
                                    shift_id=shift_id,
                                    employee_id=employee_id,
                                    workstation_id=workstation_id,
                                    leave_at=str(shift.get("joined_at") or shift.get("start_at")),
                                    leave_snapshot=self._snapshot(frame, event_scope_key, "no_show"),
                                )
                                self.database.mark_event_alert(
                                    event_id,
                                    now.isoformat(timespec="seconds"),
                                    self._snapshot(frame, event_scope_key, "no_show_alert"),
                                )
                                self._publish_alert(
                                    event_type="NO_SHOW",
                                    shift=shift,
                                    elapsed=int(arrival_elapsed),
                                    now=now,
                                )
                            message = "超过首次到岗等待上限，已记录未到岗/迟到"
                else:
                    if raw_present:
                        if previous_business in {"GRACE", "AWAY", "ALERT"}:
                            runtime["return_elapsed_sec"] = float(runtime.get("return_elapsed_sec", 0.0)) + delta
                            if runtime["return_elapsed_sec"] < int(round_item["return_confirm_sec"]):
                                business_state = previous_business
                                state = previous_business
                                present = False
                                message = "员工已返回，正在稳定确认"
                            else:
                                business_state = "PRESENT"
                                state = "PRESENT"
                                present = True
                                open_event = self.database.get_open_event(scope_key=event_scope_key, event_type="ABSENCE")
                                if open_event:
                                    self.database.close_event(
                                        int(open_event["id"]),
                                        return_at=now.isoformat(timespec="seconds"),
                                        duration_sec=int(round(float(runtime.get("absence_elapsed_sec", 0.0)))),
                                        return_snapshot=self._snapshot(frame, event_scope_key, "return"),
                                        closed_reason="RETURNED",
                                    )
                                runtime["absence_elapsed_sec"] = 0.0
                                runtime["away_started_at"] = None
                                runtime["alert_at"] = None
                                runtime["incident_id"] = None
                                runtime["return_elapsed_sec"] = 0.0
                                runtime["last_present_at"] = now.isoformat(timespec="seconds")
                                message = "员工在岗"
                        else:
                            business_state = "PRESENT"
                            state = "PRESENT"
                            present = True
                            runtime["last_present_at"] = now.isoformat(timespec="seconds")
                            runtime["absence_elapsed_sec"] = 0.0
                            runtime["return_elapsed_sec"] = 0.0
                            message = "人体 Track 短暂丢失，5 秒绑定保留中" if track_hold_active else "员工在岗"
                    else:
                        present = False
                        runtime["return_elapsed_sec"] = 0.0
                        if not runtime.get("away_started_at"):
                            runtime["away_started_at"] = (now - timedelta(seconds=delta)).isoformat(timespec="seconds")
                        runtime["absence_elapsed_sec"] = float(runtime.get("absence_elapsed_sec", 0.0)) + delta
                        elapsed = float(runtime["absence_elapsed_sec"])
                        grace = int(round_item["grace_sec"])
                        alert_threshold = int(round_item["away_threshold_sec"])
                        if elapsed < grace:
                            business_state = "GRACE"
                            state = "GRACE"
                            message = "疑似离岗，短时遮挡容忍中"
                        elif elapsed < alert_threshold:
                            business_state = "AWAY"
                            state = "AWAY"
                            message = "员工缺勤，正在告警倒计时"
                        else:
                            business_state = "ALERT"
                            state = "ALERT"
                            message = "员工缺勤告警"

                        if business_state in {"AWAY", "ALERT"}:
                            incident_id = common_incident or runtime.get("incident_id") or self.database.new_incident_id()
                            runtime["incident_id"] = incident_id
                            event = self.database.get_open_event(scope_key=event_scope_key, event_type="ABSENCE")
                            if event is None:
                                event_id = self.database.open_event(
                                    event_scope="PERSONAL",
                                    event_type="ABSENCE",
                                    scope_key=event_scope_key,
                                    incident_id=incident_id,
                                    round_id=round_id,
                                    shift_id=shift_id,
                                    employee_id=employee_id,
                                    workstation_id=workstation_id,
                                    leave_at=str(runtime["away_started_at"]),
                                    leave_snapshot=self._snapshot(frame, event_scope_key, "leave"),
                                )
                            else:
                                event_id = int(event["id"])
                            if business_state == "ALERT" and not runtime.get("alert_at"):
                                runtime["alert_at"] = now.isoformat(timespec="seconds")
                                self.database.mark_event_alert(
                                    event_id,
                                    runtime["alert_at"],
                                    self._snapshot(frame, event_scope_key, "alert"),
                                )
                                self._publish_alert(
                                    event_type="ABSENCE",
                                    shift=shift,
                                    elapsed=int(elapsed),
                                    now=now,
                                )

                runtime["state"] = state
                runtime["business_state"] = business_state
                runtime["first_present_at"] = first_present_at
                self._save_shift_runtime(shift_id, runtime, now)
                if present:
                    confirmed_present += 1

                arrival_elapsed = int(round(float(runtime.get("arrival_elapsed_sec", 0.0))))
                absence_elapsed = int(round(float(runtime.get("absence_elapsed_sec", 0.0))))
                shift_results.append(
                    ShiftStatus(
                        shift_id=shift_id,
                        round_id=round_id,
                        employee_id=employee_id,
                        employee_code=str(shift["employee_code"]),
                        employee_name=str(shift["employee_name"]),
                        workstation_id=workstation_id,
                        workstation_name=str(shift["workstation_name"]),
                        mode=mode,
                        state=state,
                        business_state=business_state,
                        present=present,
                        track_id=obs["track_id"],
                        similarity=round(binding.similarity, 4) if binding else None,
                        latest_recognition_at=binding.last_recognized_at if binding else None,
                        first_present_at=first_present_at,
                        arrival_elapsed_sec=arrival_elapsed,
                        arrival_remaining_sec=max(0, int(round_item["first_arrival_wait_sec"]) - arrival_elapsed),
                        elapsed_away_sec=absence_elapsed,
                        remaining_to_alert_sec=max(0, int(round_item["away_threshold_sec"]) - absence_elapsed),
                        last_present_at=runtime.get("last_present_at"),
                        away_started_at=runtime.get("away_started_at"),
                        alert_at=runtime.get("alert_at"),
                        other_person_count=int(obs["other_count"]),
                        observable=observable,
                        message=message,
                    )
                )

            # ---------- 工作台区域状态机：所有模式都生成区域缺员 ----------
            region_delta = self._delta_seconds(region_runtime, now, observable)
            shortage = confirmed_present < required_count
            shortage_count = max(0, required_count - confirmed_present)
            pause_limit = int(round_item["first_arrival_wait_sec"])
            pause_used = float(region_runtime.get("arrival_pause_used_sec", 0.0))
            shortage_elapsed = float(region_runtime.get("shortage_elapsed_sec", 0.0))
            previous_region_business = str(region_runtime.get("business_state", "WAITING"))
            region_scope_key = f"round:{round_id}"

            if not observable:
                region_state = str(observable_state)
                region_business = previous_region_business
                region_message = "区域不可观测，缺员和等待计时全部暂停"
            elif not shortage:
                if previous_region_business in {"GRACE", "AWAY", "ALERT"}:
                    region_runtime["return_elapsed_sec"] = float(region_runtime.get("return_elapsed_sec", 0.0)) + region_delta
                    if region_runtime["return_elapsed_sec"] < int(round_item["return_confirm_sec"]):
                        region_business = previous_region_business
                        region_state = previous_region_business
                        region_message = "区域人数已恢复，正在稳定确认"
                    else:
                        region_business = "PRESENT"
                        region_state = "PRESENT"
                        event = self.database.get_open_event(scope_key=region_scope_key, event_type="REGION_SHORTAGE")
                        if event:
                            self.database.close_event(
                                int(event["id"]),
                                return_at=now.isoformat(timespec="seconds"),
                                duration_sec=int(round(shortage_elapsed)),
                                return_snapshot=self._snapshot(frame, region_scope_key, "region_return"),
                                closed_reason="RETURNED",
                            )
                        region_runtime["shortage_elapsed_sec"] = 0.0
                        region_runtime["shortage_started_at"] = None
                        region_runtime["alert_at"] = None
                        region_runtime["incident_id"] = None
                        region_runtime["return_elapsed_sec"] = 0.0
                        shortage_elapsed = 0.0
                        region_message = "区域在岗人数满足要求"
                else:
                    region_business = "PRESENT"
                    region_state = "PRESENT"
                    region_runtime["shortage_elapsed_sec"] = 0.0
                    region_runtime["shortage_started_at"] = None
                    region_runtime["return_elapsed_sec"] = 0.0
                    if self.database.get_open_event(scope_key=region_scope_key, event_type="REGION_SHORTAGE") is None:
                        region_runtime["incident_id"] = None
                    shortage_elapsed = 0.0
                    if previous_region_business == "WAITING" and waiting_count:
                        region_message = "当前人数满足要求，仍有员工等待首次到岗"
                    else:
                        region_message = "区域在岗人数满足要求"
            else:
                region_runtime["return_elapsed_sec"] = 0.0
                if not region_runtime.get("incident_id"):
                    region_runtime["incident_id"] = self.database.new_incident_id()
                active_delta = region_delta
                waiting_for_pause = preliminary_waiting > 0
                if waiting_for_pause and pause_used < pause_limit:
                    pause_delta = min(active_delta, float(pause_limit) - pause_used)
                    pause_used += pause_delta
                    active_delta -= pause_delta
                region_runtime["arrival_pause_used_sec"] = pause_used
                if active_delta > 0:
                    if not region_runtime.get("shortage_started_at"):
                        region_runtime["shortage_started_at"] = (now - timedelta(seconds=active_delta)).isoformat(timespec="seconds")
                    shortage_elapsed += active_delta
                    region_runtime["shortage_elapsed_sec"] = shortage_elapsed

                if waiting_for_pause and active_delta <= 0 and pause_used <= pause_limit:
                    region_business = "WAITING"
                    region_state = "WAITING"
                    region_message = "存在首次到岗等待员工，区域缺员计时已暂停"
                else:
                    grace = int(round_item["grace_sec"])
                    threshold = int(round_item["away_threshold_sec"])
                    if shortage_elapsed < grace:
                        region_business = "GRACE"
                        region_state = "GRACE"
                        region_message = "区域疑似缺员，短时容忍中"
                    elif shortage_elapsed < threshold:
                        region_business = "AWAY"
                        region_state = "AWAY"
                        region_message = "区域缺员，正在告警倒计时"
                    else:
                        region_business = "ALERT"
                        region_state = "ALERT"
                        region_message = "区域缺员告警"

                    if region_business in {"AWAY", "ALERT"}:
                        event = self.database.get_open_event(scope_key=region_scope_key, event_type="REGION_SHORTAGE")
                        if event is None:
                            event_id = self.database.open_event(
                                event_scope="REGION",
                                event_type="REGION_SHORTAGE",
                                scope_key=region_scope_key,
                                incident_id=region_runtime.get("incident_id"),
                                round_id=round_id,
                                shift_id=None,
                                employee_id=None,
                                workstation_id=workstation_id,
                                leave_at=str(region_runtime.get("shortage_started_at") or now.isoformat(timespec="seconds")),
                                leave_snapshot=self._snapshot(frame, region_scope_key, "region_leave"),
                                present_count=confirmed_present,
                                required_count=required_count,
                            )
                        else:
                            event_id = int(event["id"])
                        if region_business == "ALERT" and not region_runtime.get("alert_at"):
                            region_runtime["alert_at"] = now.isoformat(timespec="seconds")
                            self.database.mark_event_alert(
                                event_id,
                                region_runtime["alert_at"],
                                self._snapshot(frame, region_scope_key, "region_alert"),
                            )
                            self._publish_region_alert(
                                round_item=round_item,
                                present_count=confirmed_present,
                                required_count=required_count,
                                elapsed=int(shortage_elapsed),
                            )

            region_runtime["state"] = region_state
            region_runtime["business_state"] = region_business
            self._save_region_runtime(round_id, region_runtime, now)
            region_results.append(
                RegionStatus(
                    round_id=round_id,
                    workstation_id=workstation_id,
                    workstation_name=str(round_item["workstation_name"]),
                    mode=mode,
                    state=region_state,
                    observable=observable,
                    assigned_count=len(shifts),
                    present_count=confirmed_present,
                    required_count=required_count,
                    shortage_count=shortage_count,
                    waiting_arrival_count=waiting_count,
                    elapsed_shortage_sec=int(round(shortage_elapsed)),
                    remaining_to_alert_sec=max(0, int(round_item["away_threshold_sec"]) - int(round(shortage_elapsed))),
                    arrival_pause_used_sec=int(round(pause_used)),
                    arrival_pause_remaining_sec=max(0, pause_limit - int(round(pause_used))),
                    incident_id=region_runtime.get("incident_id"),
                    message=region_message,
                )
            )

        return shift_results, region_results

    def _publish_alert(self, *, event_type: str, shift: Dict[str, Any], elapsed: int, now: datetime) -> None:
        if not self.alert_callback:
            return
        self.alert_callback(
            {
                "type": "absence_alert",
                "event_type": event_type,
                "shift_id": int(shift["id"]),
                "employee_id": int(shift["employee_id"]),
                "employee_code": shift["employee_code"],
                "employee_name": shift["employee_name"],
                "workstation_id": int(shift["workstation_id"]),
                "workstation_name": shift["workstation_name"],
                "alert_at": now.isoformat(timespec="seconds"),
                "elapsed_sec": elapsed,
            }
        )

    def _publish_region_alert(self, *, round_item: Dict[str, Any], present_count: int, required_count: int, elapsed: int) -> None:
        if not self.alert_callback:
            return
        self.alert_callback(
            {
                "type": "region_shortage_alert",
                "event_type": "REGION_SHORTAGE",
                "round_id": int(round_item["id"]),
                "employee_code": "区域",
                "employee_name": "缺员",
                "workstation_id": int(round_item["workstation_id"]),
                "workstation_name": round_item["workstation_name"],
                "present_count": present_count,
                "required_count": required_count,
                "elapsed_sec": elapsed,
            }
        )
