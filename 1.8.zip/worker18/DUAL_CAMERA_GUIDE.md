# RK3588 工作台检测系统 v1.8.0：双摄像头多区域版使用说明

> 基于用户上传的 v1.0.7.5 / 1.7 系列工程改造。目标是：两只摄像头放在两个不同位置，同时检测，业务数据统一进入同一个后台与前端。

## 一、先明确：这不是“传统双目测距”

当前需求是：

- Camera A 放在位置 A，例如收银台；
- Camera B 放在位置 B，例如通道/另一个工作台；
- 两个画面没有必要重叠；
- 两路分别做人体姿态、ByteTrack、人脸识别、ROI 在岗/离岗、摔倒检测；
- 最后在同一个网页上统一管理。

因此工程上应叫 **双摄像头多区域检测 / Multi-Camera Multi-Zone Detection**。

传统“立体双目视觉”要求两摄像头具有重叠视野、固定基线、同步采集、双目标定、极线校正和视差/深度计算。两个摄像头放在不同地方时，不能用左右目三角测量计算同一目标深度。

本版本按“两个不同位置同时检测”实现。

---

# 二、为什么原 1.7.5 不能直接开两路

原工程虽然工作台数据库已经保存 `camera_device`，但运行时仍是：

```text
1 x CameraManager
        ↓
1 x FrameSlot
        ↓
1 x RuntimeService
        ↓
1 x ByteTrack / Identity / Presence / FallDetector
        ↓
1 x monitor.mjpg
```

原 `CameraManager` 的设计是“任意时刻只打开一个 V4L2 节点”。切换摄像头意味着旧摄像头停止。

如果只在前端增加第二个 `<img>`，会出现：

1. 实际后台仍只有一路推理；
2. Camera A 和 Camera B 的 Track ID 会混淆；
3. 工作台 ROI 状态可能被错误摄像头覆盖；
4. 一路离线可能错误影响另一路的离岗状态；
5. 人脸 Track 绑定缓存可能跨摄像头串线。

所以本版本不是“改两个视频框”，而是重构运行时。

---

# 三、v1.8.0 双摄像头架构

```text
                         ┌───────────────────────┐
                         │ Shared RKNN ModelHub  │
                         │ Pose / Face / W600K   │
                         │ Core0 / Core1 / Core2 │
                         └──────────┬────────────┘
                                    │ 模型上下文共享 + 锁保护
                 ┌──────────────────┴──────────────────┐
                 │                                     │
Camera A         │                                     │          Camera B
/dev/videoXX     │                                     │          /dev/videoYY
     │           │                                     │               │
     ▼           │                                     │               ▼
CameraManager A  │                                     │     CameraManager B
     │           │                                     │               │
FrameSlot A      │                                     │          FrameSlot B
     │           │                                     │               │
     ▼           ▼                                     ▼               ▼
Runtime A                                             Runtime B
  ├─ Pose                                               ├─ Pose
  ├─ ByteTrack A        （跟踪状态完全隔离）             ├─ ByteTrack B
  ├─ Identity A                                        ├─ Identity B
  ├─ Presence A                                       ├─ Presence B
  ├─ Fall A                                           ├─ Fall B
  └─ JPEG A                                           └─ JPEG B
      │                                                   │
      └────────────────────┬──────────────────────────────┘
                           ▼
                  MultiCameraRuntime
                           │
                 FastAPI / WebSocket / DB
                           │
                           ▼
              专业双路监控控制台 + 历史记录
```

## 关键隔离原则

- 每一路摄像头有自己的 FrameSlot；
- 每一路有自己的 ByteTrack；
- 每一路有自己的 Track→Employee 绑定缓存；
- 每一路有自己的 Presence 状态视图；
- 每一路有自己的 FallDetector；
- Track ID 在前端使用联合标识，例如 `cam1:T3`、`cam2:T3`；
- 工作台只允许由其绑定的 `camera_device` 对应 Runtime 处理；
- Camera A 掉线不会停止 Camera B；
- Camera A 掉线时，A 区域变为 `CAMERA_OFFLINE`，离岗计时暂停，不把摄像头故障误判为员工离岗。

RKNN 模型仍只加载一套，避免两份模型额外占内存；不同摄像头调用同一模型时由原 ModelHub 锁保护。

---

# 四、完整业务流程

## 4.1 系统启动

```text
启动服务
  ↓
读取 config.json 中 cameras[]
  ↓
同时打开 Camera A + Camera B
  ↓
创建 Runtime A + Runtime B
  ↓
加载 Pose / RetinaFace / W600K RKNN
  ↓
加载员工人脸特征
  ↓
读取工作台、ROI、排班
  ↓
两路同时进入检测循环
```

## 4.2 员工录入

```text
员工管理 → 添加员工
       ↓
进入人脸录入
       ↓
选择“录入摄像头”
       ↓
前/左/右/上下/工作态拍摄
       ↓
RetinaFace → 5点对齐 → W600K embedding
       ↓
保存员工特征
```

“录入摄像头切换”只改变拍照来源，不会关闭另一路在线检测。

## 4.3 工作台配置

示例：

```text
工作台 1：收银台
camera_device = Camera A
ROI = 收银台区域

工作台 2：通道岗位
camera_device = Camera B
ROI = 通道岗位区域
```

工作台页面选择某个工作台后，会自动显示该工作台绑定摄像头的实时原始画面，再绘制 ROI。

## 4.4 排班

原 1.7 的三种模式继续保留：

- `single`：一个工作台一人；
- `per_employee`：同一 ROI 多人，每人独立计算离岗；
- `minimum_staff`：同一 ROI 可多人，只检查最低在岗人数。

排班绑定的是工作台，而工作台已经绑定摄像头，所以业务链自动变为：

```text
员工 → 班次 → 工作台 → camera_device → 对应 Runtime
```

## 4.5 Camera A 在线检测链

```text
V4L2 NV12 取帧
    ↓
最新帧 FrameSlot（旧帧自动覆盖，不积压）
    ↓
YOLOv8-Pose
    ↓
人体框 + 关键点
    ↓
ByteTrack A
    ↓
RetinaFace + W600K
    ↓
Track A ↔ Employee 绑定
    ↓
脚点/人体锚点是否落在 Camera A 对应 ROI
    ↓
Presence 状态机
    ↓
PRESENT / GRACE / ALERT / RETURN / CAMERA_OFFLINE
    ↓
事件写入数据库 + 截图 + 前端告警
```

Camera B 完全执行自己的同一条链路。

## 4.6 摔倒检测

两路 Runtime 各自根据 Pose 关键点和人体几何状态判断摔倒：

```text
Pose关键点
  ↓
躯干角度 / 框宽高比 / 关键点垂直分布 / 下落速度
  ↓
疑似
  ↓ 持续达到 confirm_seconds
FALL
  ↓
保存摄像头、Track、时间、截图、评分
  ↓
历史记录 + 前端告警
```

摔倒事件同时保存摄像头位置，方便知道事件发生在哪个区域。

## 4.7 摄像头故障

```text
Camera A 断开
  ↓
Runtime A = waiting_camera
  ↓
A 区工作台 = CAMERA_OFFLINE
  ↓
A 区离岗计时暂停

Camera B 正常
  ↓
Runtime B 继续 Pose / Track / Face / ROI / Fall
```

这是多摄像头工程必须具备的故障隔离。

---

# 五、专业前端改造内容

## 5.1 实时监控页 `/monitor`

新版改为“多区域智能视觉监控中心”，不是简单双画面：

- 顶部系统健康状态；
- 视觉节点在线数；
- 当前 Track 总数；
- 活动班次；
- 关键告警数；
- Camera A / B 双路监控墙；
- 每路显示：名称、位置、V4L2节点、在线状态；
- 每路 Pose FPS、Face FPS、Recognition、Track 数；
- 每路独立抓图；
- 工作台区域状态卡；
- 排班/人员状态；
- 摔倒状态；
- 跨摄像头 Track 表；
- Track 显示 `cam1:T1` / `cam2:T1`，避免误认为同一轨迹。

## 5.2 工作台页 `/workstations`

- 摄像头显示逻辑名称 + 物理位置 + `/dev/videoXX`；
- 工作台绑定哪路摄像头，ROI 预览自动切到该路；
- “摄像头切换”只切 ROI 配置界面，不再停止后台另一摄像头；
- ROI 测试调用对应 Runtime。

## 5.3 人脸录入页

- 新增“录入摄像头”选择；
- 预览和真正抓拍使用同一路；
- 后台其他摄像头检测不中断。

## 5.4 历史记录页

新增摄像头列：

```text
事件类型 | 员工/区域 | 工作台 | 摄像头/位置 | 开始 | 告警 | 结束 | 证据
```

## 5.5 响应式适配

CSS 已加入桌面/较窄屏幕的自适应布局。双路 Camera Wall 在宽屏使用并列卡片，较窄屏幕自动单列，监控数据卡同步重排。

---

# 六、RK3588 部署：完整可复制步骤

下面以：

```text
项目目录：/root/workstation/worker18
Python环境：/root/yolov8_rk3588/rknn310
Web端口：8090
```

为例。

## 6.1 先停止旧 1.7 服务

RK3588：

```bash
/etc/init.d/workstation-absence stop 2>/dev/null || true; pkill -f '/root/workstation/worker18/app.py' 2>/dev/null || true
```

如果你的系统是 systemd：

```bash
systemctl stop workstation-absence 2>/dev/null || true; pkill -f '/root/workstation/worker18/app.py' 2>/dev/null || true
```

## 6.2 备份原 1.7

```bash
[ -d /root/workstation/worker18 ] && cp -a /root/workstation/worker18 "/root/workstation/worker18_backup_$(date +%Y%m%d_%H%M%S)" || true
```

然后把本压缩包解压/覆盖到：

```text
/root/workstation/worker18
```

不要复制旧工程的 `data/` 到公开仓库；正式升级时如需保留员工/排班/历史，可继续使用原 `/root/workstation/worker18/data`。

## 6.3 激活你现有 RKNN Python 环境

```bash
source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker18
```

## 6.4 一次性枚举两个物理摄像头

```bash
source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker18 && python3 tools/probe_dual_cameras.py
```

重点看：

- V4L2 节点；
- Card；
- Bus；
- 是否支持 NV12；
- 当前分辨率；
- **两个节点是否真的属于两个不同物理 IMX219**。

注意：同一 IMX219 / ISP 有时会暴露多个 `/dev/video*` 节点，因此不能仅因为 `/dev/video22` 和 `/dev/video23` 不同就认为是两个相机。

## 6.5 分别做 30 帧 V4L2 裸采集验证

将下面的节点换成上一步真正确定的两个节点。

Camera A：

```bash
v4l2-ctl -d /dev/video22 --set-fmt-video=width=1920,height=1080,pixelformat=NV12 --set-parm=15 --stream-mmap=4 --stream-count=30 --stream-to=/tmp/cam1_30f.nv12
```

Camera B：

```bash
v4l2-ctl -d /dev/video31 --set-fmt-video=width=1920,height=1080,pixelformat=NV12 --set-parm=15 --stream-mmap=4 --stream-count=30 --stream-to=/tmp/cam2_30f.nv12
```

正常结果：两条命令都完成，不出现 `Device or resource busy`、`VIDIOC_STREAMON` 失败等错误，并生成非 0 字节文件。

检查大小：

```bash
ls -lh /tmp/cam1_30f.nv12 /tmp/cam2_30f.nv12
```

1920×1080 NV12 一帧约 `1920*1080*1.5 = 3,110,400` 字节；30帧理论约 93 MB，驱动实际输出应在对应数量级。

## 6.6 自动生成双摄 `config.json`

示例：

```bash
source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker18 && python3 tools/make_dual_config.py --cam-a /dev/video22 --cam-b /dev/video31 --name-a '收银区摄像头' --location-a '收银台' --name-b '通道摄像头' --location-b '货架通道' --output config.json --force
```

检查 JSON：

```bash
cd /root/workstation/worker18 && python3 -m json.tool config.json >/dev/null && echo 'config.json OK'
```

你的最终关键配置应类似：

```json
"cameras": [
  {
    "id": "cam1",
    "name": "收银区摄像头",
    "location": "收银台",
    "device": "/dev/video22"
  },
  {
    "id": "cam2",
    "name": "通道摄像头",
    "location": "货架通道",
    "device": "/dev/video31"
  }
]
```

## 6.7 首次不要先注册后台服务，直接前台运行

```bash
source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker18 && export PYTHONPATH=/root/workstation/worker18 && python3 app.py --config config.json
```

浏览器打开：

```text
http://<RK3588-IP>:8090/monitor
```

## 6.8 一条命令检查双路 API 状态

RK3588 新开一个终端：

```bash
source /root/yolov8_rk3588/rknn310/bin/activate && python3 - <<'PY'
import json, urllib.request
s=json.load(urllib.request.urlopen('http://127.0.0.1:8090/api/status', timeout=3))
print('system_state =', s.get('state'))
print('camera_pool =', s.get('camera'))
for c in s.get('cameras', []):
    print('\n', c.get('camera_id'), c.get('camera_name'), c.get('camera_location'))
    print(' state =', c.get('state'))
    print(' device =', (c.get('camera') or {}).get('device'))
    print(' sequence =', (c.get('camera') or {}).get('sequence'))
    print(' pose_fps =', (c.get('performance') or {}).get('pose_actual_fps'))
    print(' face_fps =', (c.get('performance') or {}).get('face_actual_fps'))
    print(' tracks =', len(c.get('tracks') or []))
PY
```

正常期望：

```text
system_state = running
cam1 ... state = running
cam2 ... state = running
```

两路 `sequence` 都持续增长。

## 6.9 验证两路独立截图

```bash
curl -f 'http://127.0.0.1:8090/snapshot.jpg?camera_id=cam1' -o /tmp/cam1.jpg && curl -f 'http://127.0.0.1:8090/snapshot.jpg?camera_id=cam2' -o /tmp/cam2.jpg && ls -lh /tmp/cam1.jpg /tmp/cam2.jpg
```

两张图内容应来自两个不同位置。

---

# 七、第一次业务配置建议

不要一次配置很多工作台。先按下面最小闭环测试。

## Camera A：位置 A

1. `/employees` 添加测试员工 A；
2. 完成人脸录入；
3. `/workstations` 新建 `收银台-01`；
4. 绑定 Camera A；
5. 绘制收银台 ROI；
6. ROI 测试必须能显示当前人员；
7. `/schedule` 用 `single` 给员工 A 上班；
8. `/monitor` 看 Camera A 的 Track、员工身份、PRESENT 状态。

## Camera B：位置 B

1. 新建 `通道岗-01`；
2. 绑定 Camera B；
3. 绘制 B 区 ROI；
4. 给员工 B 或测试人员排班；
5. 在 `/monitor` 同时观察两路状态。

## 最关键的串线测试

让 Camera A 和 Camera B 同时各出现 1 人：

- A 可能出现 `cam1:T1`；
- B 也可能出现 `cam2:T1`；
- 两者必须在前端被视为不同轨迹；
- A 的人员不能让 B 的 ROI 变 PRESENT；
- B 的人员不能让 A 的 ROI 变 PRESENT。

再拔掉/关闭 Camera A：

- Camera A 应变 `CAMERA_OFFLINE`；
- Camera B 必须继续运行；
- A 区的缺勤计时不应该因相机故障继续累加。

---

# 八、双摄初始性能参数为什么这样设置

本示例不是一上来就把两路都设 30 FPS，而是：

```json
"camera.fps": 15,
"runtime.pose_fps": 8.0,
"runtime.face_fps": 2.0,
"runtime.preview_fps": 6.0,
"runtime.jpeg_quality": 72
```

原因：

- 两路 1080p NV12 都需要取帧；
- 当前仍存在 CPU 侧 NV12→BGR / resize / JPEG 工作；
- 两路 Runtime 共享一套 RKNN 模型上下文；
- 先保证业务稳定和 P95，再逐步加速，比直接追求 30 FPS 更可靠。

目标应首先量化：

```text
cam1 Pose实际FPS
cam2 Pose实际FPS
总Pose吞吐
NV12→BGR P50/P95
Pose pre / inference / post
JPEG P50/P95
frame_age P50/P95
skipped_frames
FrameSlot overwrite_ratio
CPU占用
NPU Core0/1/2负载
```

---

# 九、后续优化顺序

## P1：RGA

优先把两路 CPU 的：

```text
NV12 → BGR/RGB
resize 1920x1080 → 640x640 / 320x320
```

逐步迁移到 RGA，重点降低双摄时的 CPU 与 P95 抖动。

## P2：减少重复颜色转换

当前一帧如果 Pose、Face、预览各自做转换，会浪费带宽。理想方式：

```text
NV12 FrameSlot
   ├─ RGA → Pose input
   ├─ RGA/ROI → Face input
   └─ 仅预览周期 → BGR/JPEG
```

## P3：MPP JPEG

前端 MJPEG 编码可迁移到 MPP JPEG Encoder，减少 CPU `cv2.imencode()` 压力。

注意 MPP JPEG 最适合直接接 NV12/RGB 支持格式；如果输入格式、stride、颜色矩阵不正确，会出现颜色/细节问题，需要和 RGA 的格式转换一起设计，而不是单纯“上 MPP”。

## P4：动态推理频率

没有人员时降低 Face/Pose 频率；检测到人后提升 Pose/Face 频率，减少长期空场景 NPU 消耗。

## P5：模型复用与调度

当前 Core 分配延续原 1.7：

```text
Pose         → NPU Core0
RetinaFace   → NPU Core1
Recognition  → NPU Core2
```

双摄不是给每个相机固定一个 NPU Core，而是两路业务共享三种模型；这样更符合当前三个不同模型的负载结构。

---

# 十、代码改动索引

```text
workstation/multicamera.py    多摄像头采集管理
workstation/multiruntime.py   多Runtime统一聚合
workstation/config.py         cameras[] + 兼容旧camera配置
workstation/runtime.py        camera_id隔离、独立Track/状态、离线处理
workstation/presence.py       工作台按camera_device过滤
workstation/database.py       历史事件补充camera_device
workstation/web.py            双路API、Stream、状态聚合
app.py                        创建两路CameraManager + Runtime

templates/monitor.html        专业双路监控控制台
templates/workstations.html   按工作台绑定摄像头ROI配置
templates/enrollment.html     人脸录入摄像头选择
templates/history.html        历史摄像头信息
static/app.css                专业工业监控UI + 响应式
static/app.js                 多视觉节点状态

tools/probe_dual_cameras.py   一次性摄像头节点探测
tools/make_dual_config.py     一次性生成双摄配置
config.dual.example.json      双摄推荐配置模板
```

---

# 十一、当前版本验证结果

开发环境静态/逻辑测试：

```text
pytest:       19 passed
compileall:   PASS
app.js:       node --check PASS
```

新增的多摄像头单元测试明确验证：

- Camera A Runtime 只处理绑定 Camera A 的工作台；
- Camera B Runtime 只处理绑定 Camera B 的工作台；
- 相机离线时对应工作台进入 CAMERA_OFFLINE。

真正上线前仍必须在你的 RK3588 + 两路 IMX219 上完成 V4L2 并发采集、RKNN 双Runtime吞吐和 30～60 分钟稳定性实测，因为开发容器没有你的 CSI/ISP/NPU 硬件。
