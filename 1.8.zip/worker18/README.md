> **v1.8.0 双摄像头多区域版**：本目录已基于 1.7.5 增加两路不同位置摄像头并发检测、按摄像头隔离的 Runtime/Track/ROI/告警以及专业双路监控前端。完整部署与业务说明请先阅读 [`DUAL_CAMERA_GUIDE.md`](DUAL_CAMERA_GUIDE.md)。

# workstation_absence v1.0.7.5

固定直接启动命令：
```bash
source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker18 && export PYTHONPATH=/root/workstation/worker18 && python app.py --config config.json
```

该命令会自动接管同项目旧进程，避免 8090 端口冲突；不会下载、替换或删除 RKNN Runtime、rknn-toolkit、rknn310 虚拟环境。

## 页面
- 实时监控：`http://板卡IP:8090/monitor`
- NPU量化后台：`http://板卡IP:8090/npu`
- 历史记录：`http://板卡IP:8090/history`
- 手机控制：`http://板卡IP:8091/`

## NPU数据解释
`/npu` 的 calls、Avg/P50/P95、输入shape/dtype来自实际 `RKNNLite.inference()`；模型至少完成一次 inference 后显示“NPU已验证”。mAP/Precision/Recall必须使用标注验证集离线评测后录入。

# workstation_absence v1.0.7.4 完整安全版

该包是在 v1.0.6 基础上整合后的完整项目源码，不是增量补丁。

## 已包含

- YOLOv8-Pose 人体检测与 17 点关键点；
- ByteTrackLite 人体跟踪；
- RetinaFace 人脸检测；
- MobileFaceNet/W600K 人脸特征识别；
- 员工、工作台 ROI、排班、空岗状态机；
- `single / per_employee / minimum_staff` 三种排班方式；
- 历史查询、CSV 导出、单条删除、按筛选条件批量删除；
- 摄像头全画面摔倒检测，覆盖所有 Pose Track，包括 UNKNOWN 人员；
- 摔倒状态 `NORMAL → SUSPECTED → FALLEN → RECOVERING → NORMAL`；
- 摔倒截图、实时红框、历史摔倒事件；
- 8090 主系统；
- 8091 手机控制后台；
- 启动检测、停止检测、重启检测、重启 RK3588、关闭 RK3588；
- BusyBox/SysVinit 开机启动脚本。

## 环境保护原则

`tools/install_v1074_safe.py` **不会**执行以下操作：

- 不下载 RKNN Runtime；
- 不执行 `curl`、`wget`、`pip`、`apt`；
- 不替换 `/usr/lib/librknnrt.so`；
- 不删除或修改 `/root/yolov8_rk3588/rknn310`；
- 不删除 `rknn-toolkit`；
- 不覆盖原有 `config.json` 中的模型、摄像头、数据库路径；
- 不覆盖 `data/`、人脸库、事件截图和现有 RKNN 模型。

安装器只做四件事：备份现有代码、复制完整源码、补齐新配置、安装 SysVinit 服务。

## 包内不重复携带的内容

为了保护现有数据并避免模型重复打包，本压缩包不含：

- 三个 RKNN 模型二进制文件；
- `config.json`；
- `data/workstation.db`；
- 员工人脸样本；
- 历史事件截图。

默认继续使用现有模型：

```text
/root/yolov8_rk3588/code/model/yolov8n-pose-int8.rknn
/root/yolov8_rk3588/code/model/RetinaFace_mobile320-int8.rknn
/root/yolov8_rk3588/code/model/w600k_mbf-int8-calib500.rknn
```

## 一次性安装

将压缩包上传到：

```text
/root/workstation_absence_v1.0.7.4_full_safe.zip
```

执行：

```bash
rm -rf /root/v1074_full && mkdir -p /root/v1074_full && unzip -q /root/workstation_absence_v1.0.7.4_full_safe.zip -d /root/v1074_full && source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/v1074_full/workstation_absence_v1.0.7.4_full && export PYTHONPATH=/root/v1074_full/workstation_absence_v1.0.7.4_full && python tools/install_v1074_safe.py
```

安装器会把完整代码部署到：

```text
/root/workstation/worker18
```

并保留现有：

```text
/root/workstation/worker18/config.json
/root/workstation/worker18/data/
/root/workstation/worker18/models/
```

## 启动与停止

```bash
/etc/init.d/workstation-control restart
/etc/init.d/workstation-absence restart
```

状态：

```bash
/etc/init.d/workstation-control status
/etc/init.d/workstation-absence status
```

日志：

```bash
tail -f /var/log/workstation-absence.log
tail -f /var/log/workstation-control.log
```

## 页面地址

```text
实时监控：http://192.168.10.66:8090/monitor
历史数据：http://192.168.10.66:8090/history
手机控制：http://192.168.10.66:8091/
```

8091 页面显示：设备在线状态、真实 IP、运行时间、CPU 温度、内存、磁盘、摄像头、Pose、人脸模型、摔倒检测、活动班次、开放告警和实时画面。

## 手工前台启动主模型

不使用服务时，可直接运行：

```bash
source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker18 && export PYTHONPATH=/root/workstation/worker18 && unset UVICORN_LOG_LEVEL LOG_LEVEL && python -u app.py --config /root/workstation/worker18/config.json
```

## 静态检查

不加载模型、不访问摄像头、不修改环境：

```bash
source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker18 && export PYTHONPATH=/root/workstation/worker18 && python tools/check_v1074.py
```

## 单元测试

测试脚本已移除对 `fastapi.testclient/httpx2` 的依赖：

```bash
source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker18 && export PYTHONPATH=/root/workstation/worker18 && python -m unittest discover -s tests -p 'test_*.py' -v
```

## RKNN 版本提示

该包不会处理或替换 RKNN Runtime。当前板端若输出模型 2.3.2 与 Runtime 2.0.0 的版本提示，但模型能正常推理，可以继续使用。运行时升级应作为独立任务处理，不能与业务代码安装混在一起。
