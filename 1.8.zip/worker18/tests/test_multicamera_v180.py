from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from workstation.database import Database
from workstation.presence import PresenceManager


class MultiCameraV180Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.temp.name) / "db.json")
        self.employee_a = self.db.create_employee("A001", "员工A")
        self.employee_b = self.db.create_employee("B001", "员工B")
        self.db.set_employee_enrolled(self.employee_a, True)
        self.db.set_employee_enrolled(self.employee_b, True)

        self.ws_a = self.db.create_workstation(
            name="区域A",
            camera_device="/dev/video22",
            away_threshold_sec=180,
            grace_sec=5,
            return_confirm_sec=2,
        )
        self.ws_b = self.db.create_workstation(
            name="区域B",
            camera_device="/dev/video31",
            away_threshold_sec=180,
            grace_sec=5,
            return_confirm_sec=2,
        )
        roi = [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]]
        self.db.update_workstation_roi(self.ws_a, roi)
        self.db.update_workstation_roi(self.ws_b, roi)
        self.db.start_shift_batch(
            employee_ids=[self.employee_a],
            workstation_id=self.ws_a,
            mode="single",
            minimum_staff=1,
            first_arrival_wait_sec=600,
            grace_sec=5,
            away_threshold_sec=180,
            return_confirm_sec=2,
        )
        self.db.start_shift_batch(
            employee_ids=[self.employee_b],
            workstation_id=self.ws_b,
            mode="single",
            minimum_staff=1,
            first_arrival_wait_sec=600,
            grace_sec=5,
            away_threshold_sec=180,
            return_confirm_sec=2,
        )
        self.manager = PresenceManager(
            database=self.db,
            event_dir=Path(self.temp.name) / "events",
            hip_confidence=0.3,
        )

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_runtime_only_evaluates_its_bound_camera(self):
        shifts_a, regions_a = self.manager.evaluate(
            frame=None,
            frame_width=1920,
            frame_height=1080,
            tracks=[],
            bindings={},
            camera_online=False,
            active_camera_device="/dev/video22",
        )
        self.assertEqual({item.workstation_id for item in shifts_a}, {self.ws_a})
        self.assertEqual({item.workstation_id for item in regions_a}, {self.ws_a})
        self.assertTrue(all(item.state == "CAMERA_OFFLINE" for item in shifts_a))

        shifts_b, regions_b = self.manager.evaluate(
            frame=None,
            frame_width=1920,
            frame_height=1080,
            tracks=[],
            bindings={},
            camera_online=False,
            active_camera_device="/dev/video31",
        )
        self.assertEqual({item.workstation_id for item in shifts_b}, {self.ws_b})
        self.assertEqual({item.workstation_id for item in regions_b}, {self.ws_b})
        self.assertTrue(all(item.state == "CAMERA_OFFLINE" for item in shifts_b))


if __name__ == "__main__":
    unittest.main(verbosity=2)
