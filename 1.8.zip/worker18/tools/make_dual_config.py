#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="生成双摄像头 config.json")
    parser.add_argument("--cam-a", required=True, help="第一路V4L2节点，例如/dev/video22")
    parser.add_argument("--cam-b", required=True, help="第二路V4L2节点，例如/dev/video31")
    parser.add_argument("--name-a", default="区域摄像头 A")
    parser.add_argument("--name-b", default="区域摄像头 B")
    parser.add_argument("--location-a", default="位置 A")
    parser.add_argument("--location-b", default="位置 B")
    parser.add_argument("--output", default="config.json")
    parser.add_argument("--force", action="store_true", help="即使节点当前不存在也生成配置")
    args = parser.parse_args()

    if args.cam_a == args.cam_b:
        raise SystemExit("cam-a 与 cam-b 不能是同一个V4L2节点")
    if not args.force:
        missing = [item for item in (args.cam_a, args.cam_b) if not Path(item).exists()]
        if missing:
            raise SystemExit(f"摄像头节点不存在：{', '.join(missing)}；如仅离线生成配置可加 --force")

    root = Path(__file__).resolve().parent.parent
    template_path = root / "config.dual.example.json"
    config = json.loads(template_path.read_text(encoding="utf-8"))
    first, second = config["cameras"]
    first.update({"device": args.cam_a, "name": args.name_a, "location": args.location_a})
    second.update({"device": args.cam_b, "name": args.name_b, "location": args.location_b})

    output = Path(args.output)
    if not output.is_absolute():
        output = Path.cwd() / output
    output.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"已生成：{output}")
    print(f"cam1: {args.cam_a} -> {args.location_a}")
    print(f"cam2: {args.cam_b} -> {args.location_b}")


if __name__ == "__main__":
    main()
