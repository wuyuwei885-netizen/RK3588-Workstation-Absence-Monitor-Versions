#!/usr/bin/env python3
from __future__ import annotations

import glob
import re
import shutil
import subprocess
from pathlib import Path


def run(*args: str) -> str:
    try:
        return subprocess.check_output(args, text=True, stderr=subprocess.STDOUT, timeout=4)
    except Exception as exc:
        return f"ERROR: {type(exc).__name__}: {exc}"


def field(text: str, name: str) -> str:
    match = re.search(rf"^\s*{re.escape(name)}\s*:\s*(.+)$", text, flags=re.M)
    return match.group(1).strip() if match else "-"


def main() -> None:
    if shutil.which("v4l2-ctl") is None:
        raise SystemExit("找不到 v4l2-ctl。请先安装/确认 v4l-utils。")

    devices = sorted(
        glob.glob("/dev/video*"),
        key=lambda item: int(re.findall(r"\d+", item)[-1]),
    )
    print("=" * 106)
    print("RK3588 双摄像头候选节点扫描（目标：1920x1080 NV12）")
    print("=" * 106)
    print(f"{'NODE':<14} {'NV12':<6} {'CARD':<34} {'BUS':<32} CURRENT")
    print("-" * 106)

    candidates = []
    for device in devices:
        all_text = run("v4l2-ctl", "-d", device, "--all")
        formats = run("v4l2-ctl", "-d", device, "--list-formats-ext")
        current = run("v4l2-ctl", "-d", device, "--get-fmt-video").replace("\n", " ")
        current = re.sub(r"\s+", " ", current)[:42]
        nv12 = "NV12" in formats or "NV12" in all_text
        card = field(all_text, "Card type")[:33]
        bus = field(all_text, "Bus info")[:31]
        print(f"{device:<14} {('YES' if nv12 else 'no'):<6} {card:<34} {bus:<32} {current}")
        if nv12:
            candidates.append(device)

    print("-" * 106)
    print("NV12候选：", " ".join(candidates) if candidates else "未找到")
    print()
    print("下一步：从上表选择两个分别对应两颗物理摄像头的节点。")
    print("不要只因为 /dev/video22 和 /dev/video23 都存在就认为它们是两颗摄像头；同一ISP可能暴露多个video节点。")
    print("确认后执行：")
    print("python3 tools/make_dual_config.py --cam-a /dev/videoXX --cam-b /dev/videoYY")


if __name__ == "__main__":
    main()
