#!/usr/bin/env python3
from __future__ import annotations

import argparse
import atexit
import os
import signal
import time
from pathlib import Path
from typing import Iterable, Set

import uvicorn

from workstation.multicamera import MultiCameraManager
from workstation.config import load_config
from workstation.database import Database
from workstation.enrollment import EnrollmentService
from workstation.models import ModelHub
from workstation.runtime import RuntimeService
from workstation.multiruntime import MultiCameraRuntime
from workstation.web import AlertBus, create_app

PID_FILE = Path("/var/run/workstation-absence.pid")
APP_PATH = Path(__file__).resolve()


def parse_args():
    parser = argparse.ArgumentParser(description="RK3588工作台空岗与摔倒检测系统")
    parser.add_argument("--config", default="config.json", help="配置文件路径")
    return parser.parse_args()


def _cmdline(pid: int) -> list[str]:
    try:
        raw = Path(f"/proc/{pid}/cmdline").read_bytes()
    except OSError:
        return []
    return [part.decode("utf-8", errors="ignore") for part in raw.split(b"\0") if part]


def _is_same_app(pid: int) -> bool:
    if pid <= 1 or pid == os.getpid():
        return False
    parts = _cmdline(pid)
    if not parts or "python" not in Path(parts[0]).name.lower():
        return False
    app_text = str(APP_PATH)
    for part in parts[1:]:
        if part == app_text:
            return True
        if part == "app.py":
            try:
                cwd = Path(f"/proc/{pid}/cwd").resolve()
                if (cwd / part).resolve() == APP_PATH:
                    return True
            except OSError:
                pass
    return False


def _existing_project_pids() -> Iterable[int]:
    found: Set[int] = set()
    try:
        if PID_FILE.is_file():
            found.add(int(PID_FILE.read_text(encoding="utf-8").strip()))
    except (OSError, ValueError):
        pass
    for proc in Path("/proc").iterdir():
        if proc.name.isdigit():
            pid = int(proc.name)
            if _is_same_app(pid):
                found.add(pid)
    return sorted(found)


def _stop_existing_instances() -> None:
    targets = [pid for pid in _existing_project_pids() if _is_same_app(pid)]
    for pid in targets:
        print(f"[启动] 检测到旧主程序 PID={pid}，先停止，避免8090端口冲突")
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            continue
    deadline = time.monotonic() + 8.0
    while time.monotonic() < deadline:
        alive = []
        for pid in targets:
            try:
                os.kill(pid, 0)
                alive.append(pid)
            except ProcessLookupError:
                pass
        if not alive:
            break
        time.sleep(0.2)
    for pid in targets:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            continue
        print(f"[启动] 旧主程序 PID={pid} 未退出，执行强制停止")
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    try:
        PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _register_pid() -> None:
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(str(os.getpid()), encoding="utf-8")

    def cleanup() -> None:
        try:
            if PID_FILE.is_file() and PID_FILE.read_text().strip() == str(os.getpid()):
                PID_FILE.unlink()
        except OSError:
            pass

    atexit.register(cleanup)


def main() -> None:
    args = parse_args()
    _stop_existing_instances()
    _register_pid()

    config = load_config(args.config)
    database = Database(config.app["database"])
    camera = MultiCameraManager(config.cameras)
    models = ModelHub(config.models, config.rknn)
    alerts = AlertBus()
    enrollment = EnrollmentService(
        camera=camera,
        models=models,
        database=database,
        enrollment_dir=config.app["enrollment_dir"],
        config=config.enrollment,
    )

    runtimes = {}
    for spec in config.cameras:
        camera_id = str(spec["id"])
        manager = camera.manager_for_id(camera_id)
        runtimes[camera_id] = RuntimeService(
            camera=manager,
            models=models,
            database=database,
            runtime_config=config.runtime,
            presence_config=config.presence,
            fall_config=config.fall_detection,
            event_dir=config.app["event_dir"],
            alert_callback=alerts.publish,
            camera_id=camera_id,
            camera_name=str(spec.get("name", camera_id)),
            camera_location=str(spec.get("location", "")),
        )
    runtime = MultiCameraRuntime(
        camera_pool=camera,
        models=models,
        database=database,
        runtimes=runtimes,
    )
    app = create_app(
        config=config,
        camera=camera,
        models=models,
        database=database,
        enrollment=enrollment,
        runtime=runtime,
        alerts=alerts,
    )
    print("[DualCam] 多摄像头Runtime已初始化；实时量化/NPU数据：http://<板卡IP>:8090/npu")
    uvicorn.run(
        app,
        host=str(config.app["host"]),
        port=int(config.app["port"]),
        log_level="info",
        log_config=None,
    )


if __name__ == "__main__":
    main()
