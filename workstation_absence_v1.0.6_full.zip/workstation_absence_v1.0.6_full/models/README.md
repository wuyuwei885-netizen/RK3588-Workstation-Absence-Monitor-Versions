# RKNN模型

项目默认使用板端现有的三份模型，不把模型重复打进项目压缩包：

```text
/root/yolov8_rk3588/code/model/yolov8n-pose-int8.rknn
/root/yolov8_rk3588/code/model/RetinaFace_mobile320-int8.rknn
/root/yolov8_rk3588/code/model/w600k_mbf-int8-calib500.rknn
```

职责：

- `yolov8n-pose-int8.rknn`：人体框、17个关键点和工作台ROI位置判断。
- `RetinaFace_mobile320-int8.rknn`：人脸框和5点关键点。
- `w600k_mbf-int8-calib500.rknn`：112×112对齐人脸的512维特征。

W600K模型转换时已将`mean=127.5/std=127.5`写入RKNN，因此板端配置保持：

```json
"normalize": false
```

板端输入为RGB、uint8、NHWC四维张量`[1,112,112,3]`。
