from __future__ import annotations

import numpy as np

from workstation.models import PersonDetection
from workstation.tracker import ByteTrackLite


def detection(x1, y1, x2, y2, score=0.9):
    return PersonDetection(
        bbox=np.asarray([x1, y1, x2, y2], dtype=np.float32),
        score=score,
        keypoints=np.zeros((17, 3), dtype=np.float32),
    )


def main() -> None:
    tracker = ByteTrackLite(
        track_thresh=0.45,
        low_thresh=0.1,
        new_track_thresh=0.55,
        match_thresh=0.75,
        track_buffer=30,
    )
    first = tracker.update([detection(10, 10, 100, 200)])
    track_id = first[0].track_id
    second = tracker.update([detection(13, 12, 103, 202)])
    assert second[0].track_id == track_id
    print("Tracker test: PASS")


if __name__ == "__main__":
    main()
