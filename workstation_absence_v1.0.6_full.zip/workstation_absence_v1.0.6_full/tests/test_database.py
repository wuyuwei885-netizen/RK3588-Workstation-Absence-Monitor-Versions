from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np

from workstation.database import Database


def main() -> None:
    with tempfile.TemporaryDirectory() as temporary:
        database = Database(Path(temporary) / "test.db")
        employee_id = database.create_employee("E001", "测试员工", "测试组")
        embedding = np.arange(512, dtype=np.float32)
        embedding /= np.linalg.norm(embedding)
        database.add_face_sample(
            employee_id=employee_id,
            slot_label="front",
            source_type="test",
            image_path="frame.jpg",
            aligned_image_path="aligned.jpg",
            embedding=embedding,
            quality={"quality_score": 88},
        )
        database.save_face_profile(employee_id, embedding, 5, 88)
        workstation_id = database.create_workstation(
            name="工作台01",
            camera_device="/dev/video22",
            away_threshold_sec=180,
            grace_sec=5,
            return_confirm_sec=2,
        )
        database.update_workstation_roi(
            workstation_id, [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]]
        )
        result = database.start_shift_batch(
            employee_ids=[employee_id],
            workstation_id=workstation_id,
            mode="single",
            minimum_staff=1,
            first_arrival_wait_sec=600,
            grace_sec=5,
            away_threshold_sec=180,
            return_confirm_sec=2,
        )
        assert database.active_shifts()[0]["id"] == result["shift_ids"][0]
        assert database.load_face_profiles()[0]["embedding_array"].shape == (512,)
        database.stop_workstation_round(workstation_id)
        assert not database.active_shifts()
        print("Database test: PASS")


if __name__ == "__main__":
    main()
