from __future__ import annotations

import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np

from workstation.database import Database
from workstation.identity import IdentityBinding
from workstation.presence import PresenceManager
from workstation.tracker import Track


class StaffingV106Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.temp.name) / "db.json")
        self.employees = []
        for index in range(1, 5):
            employee_id = self.db.create_employee(f"E{index:03d}", f"员工{index}")
            self.db.set_employee_enrolled(employee_id, True)
            self.employees.append(employee_id)
        self.ws = self.db.create_workstation(
            name="收银台",
            camera_device="/dev/video22",
            away_threshold_sec=1,
            grace_sec=0,
            return_confirm_sec=0,
        )
        self.db.update_workstation_roi(self.ws, [[0.1, 0.1], [0.9, 0.1], [0.9, 0.9], [0.1, 0.9]])

    def tearDown(self) -> None:
        self.temp.cleanup()

    def start(self, ids, mode="per_employee", minimum_staff=1):
        return self.db.start_shift_batch(
            employee_ids=ids,
            workstation_id=self.ws,
            mode=mode,
            minimum_staff=minimum_staff,
            first_arrival_wait_sec=1,
            grace_sec=0,
            away_threshold_sec=1,
            return_confirm_sec=0,
        )

    def test_batch_atomic_and_single(self):
        with self.assertRaisesRegex(ValueError, "只能选择 1"):
            self.start(self.employees[:2], mode="single")
        self.assertFalse(self.db.active_shifts())
        self.start([self.employees[0]], mode="single")
        with self.assertRaisesRegex(ValueError, "不能追加"):
            self.start([self.employees[1]], mode="single")

    def test_running_round_locked_and_all_stop(self):
        self.start(self.employees[:2], mode="per_employee")
        with self.assertRaisesRegex(ValueError, "锁定"):
            self.db.start_shift_batch(
                employee_ids=[self.employees[2]], workstation_id=self.ws,
                mode="minimum_staff", minimum_staff=2,
                first_arrival_wait_sec=1, grace_sec=0,
                away_threshold_sec=1, return_confirm_sec=0,
            )
        with self.assertRaisesRegex(ValueError, "全部下班"):
            self.db.stop_shift(self.db.active_shifts()[0]["id"])
        result = self.db.stop_workstation_round(self.ws)
        self.assertEqual(result["closed_shift_count"], 2)
        self.assertFalse(self.db.active_shifts())
        # 从未到岗，即使未超过等待上限也要留下 NO_SHOW。
        events = self.db.query_events(category="absence")
        self.assertEqual(sum(1 for item in events if item["event_type"] == "NO_SHOW"), 2)

    def test_minimum_staff_can_start_below_nmin(self):
        result = self.start([self.employees[0]], mode="minimum_staff", minimum_staff=2)
        self.assertEqual(result["added_count"], 1)
        self.assertEqual(self.db.get_active_round(self.ws)["minimum_staff"], 2)

    def test_employee_and_workstation_locked(self):
        self.start([self.employees[0]], mode="single")
        with self.assertRaisesRegex(ValueError, "不能停用"):
            self.db.set_employee_enabled(self.employees[0], False)
        with self.assertRaisesRegex(ValueError, "锁定"):
            self.db.update_workstation_roi(self.ws, [[0, 0], [1, 0], [1, 1]])

    def test_leave_workflow_after_round_end(self):
        self.start([self.employees[0]], mode="single")
        self.db.stop_workstation_round(self.ws)
        event = next(item for item in self.db.query_events() if item["event_scope"] == "PERSONAL")
        applied = self.db.apply_leave(event["id"], "临时处理事务")
        self.assertEqual(applied["leave_status"], "PENDING")
        rejected = self.db.review_leave(event["id"], approved=False)
        self.assertEqual(rejected["leave_status"], "REJECTED")
        self.db.apply_leave(event["id"], "补充说明")
        approved = self.db.review_leave(event["id"], approved=True)
        self.assertEqual(approved["leave_status"], "APPROVED")
        row = self.db.query_events(category="leave_approved")[0]
        self.assertEqual(row["history_category"], "LEAVE_APPROVED")
        self.assertGreaterEqual(len(row["leave_audit"]), 4)

    def test_personal_and_region_events_share_incident(self):
        started = self.start([self.employees[0]], mode="single")
        shift_id = started["shift_ids"][0]
        manager = PresenceManager(database=self.db, event_dir=Path(self.temp.name) / "events", hip_confidence=0.3)
        keypoints = np.zeros((17, 3), dtype=np.float32)
        track = Track(track_id=1, bbox=np.asarray([200, 100, 400, 800], dtype=np.float32), score=0.9, keypoints=keypoints)
        binding = IdentityBinding(1, self.employees[0], "E001", "员工1", 0.8, 0.0, datetime.now().astimezone().isoformat(timespec="seconds"))
        shifts, regions = manager.evaluate(
            frame=None, frame_width=1000, frame_height=1000,
            tracks=[track], bindings={1: binding}, camera_online=True, active_camera_device="/dev/video22",
        )
        self.assertEqual(shifts[0].state, "PRESENT")
        # 人员消失，人工把上次 tick 推前 1.1 秒，使个人和区域同时进入 ALERT。
        old = (datetime.now().astimezone() - timedelta(seconds=1.1)).isoformat(timespec="seconds")
        shift_runtime = self.db.get_runtime_state(f"shift:{shift_id}")
        shift_runtime["last_tick_at"] = old
        shift_runtime.pop("scope_key", None)
        shift_runtime.pop("updated_at", None)
        self.db.save_runtime_state(scope_key=f"shift:{shift_id}", **shift_runtime)
        round_id = started["round_id"]
        region_runtime = self.db.get_runtime_state(f"round:{round_id}")
        region_runtime["last_tick_at"] = old
        region_runtime.pop("scope_key", None)
        region_runtime.pop("updated_at", None)
        self.db.save_runtime_state(scope_key=f"round:{round_id}", **region_runtime)
        shifts, regions = manager.evaluate(
            frame=None, frame_width=1000, frame_height=1000,
            tracks=[], bindings={}, camera_online=True, active_camera_device="/dev/video22",
        )
        self.assertEqual(shifts[0].state, "ALERT")
        self.assertEqual(regions[0].state, "ALERT")
        events = self.db.query_events()
        personal = next(item for item in events if item["event_scope"] == "PERSONAL")
        region = next(item for item in events if item["event_scope"] == "REGION")
        self.assertEqual(personal["incident_id"], region["incident_id"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
