# v1.0.6 变更文件

```text
workstation/database.py
workstation/identity.py
workstation/presence.py
workstation/runtime.py
workstation/web.py
templates/schedule.html
templates/history.html
templates/monitor.html
static/app.css
static/app.js
config.example.json
tests/test_database.py
tests/test_staffing_v106.py
README.md
CHANGELOG_v1.0.6.md
```

关键数据库新增字段由 `Database._migrate()` 自动补齐，不覆盖旧员工、人脸、工作台、班次和历史记录。
