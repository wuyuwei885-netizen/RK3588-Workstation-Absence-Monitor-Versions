from __future__ import annotations

from typing import Sequence, Tuple

import cv2
import numpy as np


def denormalize_polygon(
    polygon: Sequence[Sequence[float]], width: int, height: int
) -> np.ndarray:
    return np.asarray(
        [
            [int(round(float(x) * width)), int(round(float(y) * height))]
            for x, y in polygon
        ],
        dtype=np.int32,
    )


def point_in_polygon(
    point: Tuple[float, float],
    polygon: Sequence[Sequence[float]],
    width: int,
    height: int,
) -> bool:
    if len(polygon) < 3:
        return False
    contour = denormalize_polygon(polygon, width, height).reshape(-1, 1, 2)
    return cv2.pointPolygonTest(contour, point, False) >= 0


def bbox_iou(box_a: Sequence[float], box_b: Sequence[float]) -> float:
    ax1, ay1, ax2, ay2 = map(float, box_a)
    bx1, by1, bx2, by2 = map(float, box_b)
    xx1 = max(ax1, bx1)
    yy1 = max(ay1, by1)
    xx2 = min(ax2, bx2)
    yy2 = min(ay2, by2)
    intersection = max(0.0, xx2 - xx1) * max(0.0, yy2 - yy1)
    area_a = max(0.0, ax2 - ax1) * max(0.0, ay2 - ay1)
    area_b = max(0.0, bx2 - bx1) * max(0.0, by2 - by1)
    return intersection / (area_a + area_b - intersection + 1e-9)


def face_center_in_upper_body(
    face_box: Sequence[float], person_box: Sequence[float]
) -> bool:
    fx1, fy1, fx2, fy2 = map(float, face_box)
    px1, py1, px2, py2 = map(float, person_box)
    center_x = (fx1 + fx2) / 2.0
    center_y = (fy1 + fy2) / 2.0
    return (
        px1 <= center_x <= px2
        and py1 <= center_y <= py2
        and center_y <= py1 + (py2 - py1) * 0.62
    )
