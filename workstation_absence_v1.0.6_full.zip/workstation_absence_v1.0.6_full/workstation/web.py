from __future__ import annotations

import asyncio
import csv
import io
import json
import shutil
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile, WebSocket
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .camera import CameraManager
from .config import AppConfig
from .database import Database
from .enrollment import EnrollmentService, SLOT_LABELS
from .models import ModelHub
from .runtime import JPEGStore, RuntimeService


class AlertBus:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._revision = 0
        self._latest: Optional[Dict[str, Any]] = None

    def publish(self, event: Dict[str, Any]) -> None:
        with self._lock:
            self._revision += 1
            self._latest = dict(event)

    def latest(self) -> tuple[int, Optional[Dict[str, Any]]]:
        with self._lock:
            return self._revision, dict(self._latest) if self._latest else None


def mjpeg_response(store: JPEGStore) -> StreamingResponse:
    def generator():
        version = -1
        while True:
            jpeg, current_version = store.wait(version, timeout=2.0)
            if jpeg is None or current_version == version:
                continue
            version = current_version
            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n"
                + f"Content-Length: {len(jpeg)}\r\n\r\n".encode("ascii")
                + jpeg
                + b"\r\n"
            )

    return StreamingResponse(
        generator(),
        media_type="multipart/x-mixed-replace; boundary=frame",
        headers={"Cache-Control": "no-store, no-cache"},
    )


def _safe_unlink(path_value: Optional[str], allowed_root: Path) -> bool:
    """只删除allowed_root目录内的普通文件。"""
    if not path_value:
        return False
    try:
        path = Path(path_value).resolve()
        root = allowed_root.resolve()
        path.relative_to(root)
    except Exception:
        return False
    try:
        if path.is_file():
            path.unlink()
            return True
    except OSError:
        return False
    return False


def _event_media_url(path: Optional[str], event_dir: Path) -> Optional[str]:
    if not path:
        return None
    try:
        relative = Path(path).resolve().relative_to(event_dir.resolve())
    except Exception:
        return None
    return "/media/events/" + "/".join(relative.parts)



def _template_response(
    templates: Jinja2Templates,
    request: Request,
    name: str,
    context: Optional[Dict[str, Any]] = None,
):
    """
    同时兼容新旧 Starlette/Jinja2Templates.TemplateResponse 参数签名。

    新版：
        TemplateResponse(request=request, name=name, context=context)

    旧版：
        TemplateResponse(name, context)
    """
    template_context: Dict[str, Any] = dict(context or {})
    template_context["request"] = request

    try:
        return templates.TemplateResponse(
            request=request,
            name=name,
            context=template_context,
        )
    except TypeError as exc:
        message = str(exc)
        if (
            "unexpected keyword argument" not in message
            and "multiple values" not in message
        ):
            raise
        return templates.TemplateResponse(
            name,
            template_context,
        )

def create_app(
    *,
    config: AppConfig,
    camera: CameraManager,
    models: ModelHub,
    database: Database,
    enrollment: EnrollmentService,
    runtime: RuntimeService,
    alerts: AlertBus,
) -> FastAPI:
    root = Path(__file__).resolve().parent.parent
    templates = Jinja2Templates(directory=str(root / "templates"))
    app = FastAPI(title="RK3588工作台空岗检测系统")
    app.mount("/static", StaticFiles(directory=str(root / "static")), name="static")
    app.mount(
        "/media/enrollment",
        StaticFiles(directory=config.app["enrollment_dir"]),
        name="enrollment-media",
    )
    app.mount(
        "/media/events",
        StaticFiles(directory=config.app["event_dir"]),
        name="event-media",
    )

    @app.on_event("startup")
    async def startup() -> None:
        saved_device = database.get_setting("active_camera_device")
        if saved_device and Path(saved_device).exists():
            camera.switch(saved_device)
        else:
            camera.start()
        if not runtime.is_alive():
            runtime.start()

    @app.on_event("shutdown")
    async def shutdown() -> None:
        runtime.stop()
        camera.stop()
        runtime.join(timeout=5)
        models.close()

    @app.get("/", include_in_schema=False)
    async def root_redirect():
        return RedirectResponse("/monitor", status_code=302)

    @app.get("/employees", response_class=HTMLResponse)
    async def employees_page(request: Request):
        return _template_response(
            templates,
            request,
            "employees.html",
            {"employees": database.list_employees()},
        )

    @app.get("/employees/{employee_id}/enroll", response_class=HTMLResponse)
    async def enrollment_page(request: Request, employee_id: int):
        employee = database.get_employee(employee_id)
        if employee is None:
            raise HTTPException(status_code=404, detail="员工不存在")
        status = enrollment.enrollment_status(employee_id)
        samples = status["samples"]
        for sample in samples:
            filename = Path(sample["aligned_image_path"]).name
            sample["aligned_url"] = (
                f"/media/enrollment/{employee['employee_code']}/{filename}"
            )
        return _template_response(
            templates,
            request,
            "enrollment.html",
            {
                "employee": employee,
                "enrollment": status,
                "samples": samples,
                "slot_labels": SLOT_LABELS,
            },
        )

    @app.get("/workstations", response_class=HTMLResponse)
    async def workstations_page(request: Request):
        return _template_response(
            templates,
            request,
            "workstations.html",
            {
                "workstations": database.list_workstations(),
                "cameras": CameraManager.list_devices(),
                "active_camera": camera.active_device,
            },
        )

    @app.get("/schedule", response_class=HTMLResponse)
    async def schedule_page(request: Request):
        return _template_response(
            templates,
            request,
            "schedule.html",
            {
                "employees": database.list_employees(include_disabled=True),
                "workstations": database.list_workstations(include_disabled=False),
                "active_rounds": database.active_rounds(),
                "active_shifts": database.active_shifts(),
                "shift_history": database.list_shifts(100),
                "defaults": {
                    "mode": "single",
                    "minimum_staff": 1,
                    "first_arrival_wait_sec": 600,
                    "grace_sec": 5,
                    "away_threshold_sec": 180,
                    "return_confirm_sec": 2,
                },
            },
        )

    @app.get("/monitor", response_class=HTMLResponse)
    async def monitor_page(request: Request):
        return _template_response(
            templates,
            request,
            "monitor.html",
            {"active_shifts": database.active_shifts()},
        )

    @app.get("/history", response_class=HTMLResponse)
    async def history_page(
        request: Request,
        employee_id: Optional[int] = None,
        workstation_id: Optional[int] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        category: Optional[str] = None,
    ):
        events = database.query_events(
            employee_id=employee_id,
            workstation_id=workstation_id,
            start_date=start_date,
            end_date=end_date,
            category=category,
        )
        event_dir = Path(config.app["event_dir"])
        for event in events:
            for field in ("leave_snapshot", "alert_snapshot", "return_snapshot"):
                event[field + "_url"] = _event_media_url(event.get(field), event_dir)
        return _template_response(
            templates,
            request,
            "history.html",
            {
                "events": events,
                "employees": database.list_employees(),
                "workstations": database.list_workstations(),
                "filters": {
                    "employee_id": employee_id,
                    "workstation_id": workstation_id,
                    "start_date": start_date or "",
                    "end_date": end_date or "",
                    "category": category or "all",
                },
            },
        )

    # Employee APIs
    @app.post("/api/employees")
    async def create_employee(request: Request):
        payload = await request.json()
        try:
            employee_id = database.create_employee(
                payload.get("employee_code", ""),
                payload.get("name", ""),
                payload.get("department", ""),
                payload.get("note", ""),
            )
            return {"ok": True, "employee_id": employee_id}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.put("/api/employees/{employee_id}")
    async def update_employee(employee_id: int, request: Request):
        payload = await request.json()
        try:
            database.update_employee(
                employee_id,
                employee_code=payload.get("employee_code", ""),
                name=payload.get("name", ""),
                department=payload.get("department", ""),
                note=payload.get("note", ""),
            )
            runtime.identity.reload_profiles()
            return {"ok": True}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.delete("/api/employees/{employee_id}")
    async def delete_employee(employee_id: int):
        employee = database.get_employee(employee_id)
        if employee is None:
            raise HTTPException(status_code=404, detail="员工不存在")

        try:
            deleted = database.delete_employee(employee_id)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        enrollment_root = Path(config.app["enrollment_dir"]).resolve()
        employee_dir = enrollment_root / str(employee["employee_code"])
        try:
            employee_dir.resolve().relative_to(enrollment_root)
            if employee_dir.is_dir():
                shutil.rmtree(employee_dir)
        except Exception:
            pass

        event_root = Path(config.app["event_dir"])
        removed_event_files = 0
        for event in deleted.get("events", []):
            for field in ("leave_snapshot", "alert_snapshot", "return_snapshot"):
                if _safe_unlink(event.get(field), event_root):
                    removed_event_files += 1

        runtime.identity.remove_employee(employee_id)
        runtime.latest_bindings = {
            track_id: binding
            for track_id, binding in runtime.latest_bindings.items()
            if int(binding.employee_id) != int(employee_id)
        }

        return {
            "ok": True,
            "employee_id": employee_id,
            "employee_code": employee["employee_code"],
            "deleted_samples": len(deleted.get("samples", [])),
            "deleted_shifts": len(deleted.get("shifts", [])),
            "deleted_events": len(deleted.get("events", [])),
            "deleted_event_files": removed_event_files,
        }

    @app.post("/api/employees/{employee_id}/enabled")
    async def toggle_employee(employee_id: int, request: Request):
        payload = await request.json()
        try:
            database.set_employee_enabled(employee_id, bool(payload.get("enabled")))
            runtime.identity.reload_profiles()
            return {"ok": True}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/employees/{employee_id}/capture")
    async def capture_employee(employee_id: int, request: Request):
        payload = await request.json()
        try:
            return enrollment.capture(employee_id, str(payload.get("slot_label", "")))
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/employees/{employee_id}/upload")
    async def upload_employee_photo(
        employee_id: int,
        slot_label: str = Form(...),
        file: UploadFile = File(...),
    ):
        try:
            return enrollment.upload(employee_id, slot_label, await file.read())
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.delete("/api/face-samples/{sample_id}")
    async def delete_face_sample(sample_id: int):
        try:
            sample = database.delete_face_sample(sample_id)
            if sample is None:
                raise HTTPException(status_code=404, detail="照片不存在")
            database.set_employee_enrolled(int(sample["employee_id"]), False)
            runtime.identity.reload_profiles()
            return {"ok": True}
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/employees/{employee_id}/regenerate")
    async def regenerate_profile(employee_id: int):
        try:
            result = enrollment.regenerate_profile(employee_id)
            runtime.identity.reload_profiles()
            return result
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/api/employees/{employee_id}/quality")
    async def employee_quality(employee_id: int):
        return enrollment.enrollment_status(employee_id)

    # Camera and workstation APIs
    @app.get("/api/cameras")
    async def list_cameras():
        return {"active": camera.active_device, "devices": CameraManager.list_devices()}

    @app.post("/api/cameras/select")
    async def select_camera(request: Request):
        payload = await request.json()
        device = str(payload.get("device", ""))
        try:
            camera.switch(device)
            database.set_setting("active_camera_device", device)
            return {"ok": True, "device": device}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/workstations")
    async def create_workstation(request: Request):
        payload = await request.json()
        try:
            workstation_id = database.create_workstation(
                name=payload.get("name", ""),
                camera_device=payload.get("camera_device", camera.active_device),
                away_threshold_sec=int(payload.get("away_threshold_sec", 180)),
                grace_sec=int(payload.get("grace_sec", 5)),
                return_confirm_sec=int(payload.get("return_confirm_sec", 2)),
            )
            return {"ok": True, "workstation_id": workstation_id}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.delete("/api/workstations/{workstation_id}/roi")
    async def clear_workstation_roi(workstation_id: int):
        try:
            database.clear_workstation_roi(workstation_id)
            return {"ok": True, "workstation_id": workstation_id, "roi": []}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.delete("/api/workstations/{workstation_id}")
    async def delete_workstation(workstation_id: int):
        try:
            deleted = database.delete_workstation(workstation_id)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        event_root = Path(config.app["event_dir"])
        removed_event_files = 0
        for event in deleted.get("events", []):
            for field in ("leave_snapshot", "alert_snapshot", "return_snapshot"):
                if _safe_unlink(event.get(field), event_root):
                    removed_event_files += 1

        return {
            "ok": True,
            "workstation_id": workstation_id,
            "workstation_name": deleted["workstation"]["name"],
            "deleted_shifts": len(deleted.get("shifts", [])),
            "deleted_events": len(deleted.get("events", [])),
            "deleted_event_files": removed_event_files,
        }

    @app.put("/api/workstations/{workstation_id}")
    async def update_workstation(workstation_id: int, request: Request):
        payload = await request.json()
        try:
            database.update_workstation(
                workstation_id,
                name=payload.get("name", ""),
                camera_device=payload.get("camera_device", camera.active_device),
                away_threshold_sec=int(payload.get("away_threshold_sec", 180)),
                grace_sec=int(payload.get("grace_sec", 5)),
                return_confirm_sec=int(payload.get("return_confirm_sec", 2)),
                enabled=bool(payload.get("enabled", True)),
            )
            return {"ok": True}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/workstations/{workstation_id}/roi")
    async def save_roi(workstation_id: int, request: Request):
        payload = await request.json()
        roi = payload.get("roi")
        if not isinstance(roi, list) or len(roi) < 3:
            raise HTTPException(status_code=400, detail="ROI至少需要3个点")
        for point in roi:
            if (
                not isinstance(point, list)
                or len(point) != 2
                or not 0 <= float(point[0]) <= 1
                or not 0 <= float(point[1]) <= 1
            ):
                raise HTTPException(status_code=400, detail="ROI必须为0~1归一化坐标")
        database.update_workstation_roi(workstation_id, roi)
        return {"ok": True, "roi": roi}

    @app.post("/api/workstations/{workstation_id}/test")
    async def test_workstation_draft(workstation_id: int, request: Request):
        payload = await request.json()
        roi = payload.get("roi")
        try:
            return runtime.test_workstation(workstation_id, roi_override=roi)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/api/workstations/{workstation_id}/test")
    async def test_workstation_saved(workstation_id: int):
        """兼容旧网页：测试数据库中已保存的ROI。"""
        try:
            return runtime.test_workstation(workstation_id)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    # Shift APIs
    @app.post("/api/shifts/start")
    async def start_shift(request: Request):
        payload = await request.json()
        try:
            employee_ids = payload.get("employee_ids")
            if employee_ids is None:
                legacy_employee = payload.get("employee_id")
                employee_ids = [legacy_employee] if legacy_employee is not None else []
            result = database.start_shift_batch(
                employee_ids=[int(value) for value in employee_ids],
                workstation_id=int(payload.get("workstation_id")),
                mode=str(payload.get("mode", "single")),
                minimum_staff=int(payload.get("minimum_staff", 1)),
                first_arrival_wait_sec=int(payload.get("first_arrival_wait_sec", 600)),
                grace_sec=int(payload.get("grace_sec", 5)),
                away_threshold_sec=int(payload.get("away_threshold_sec", 180)),
                return_confirm_sec=int(payload.get("return_confirm_sec", 2)),
            )
            return {"ok": True, **result}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/workstations/{workstation_id}/shifts/stop-all")
    async def stop_all_shifts(workstation_id: int):
        try:
            return {"ok": True, **database.stop_workstation_round(workstation_id)}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/shifts/{shift_id}/stop")
    async def stop_shift(shift_id: int):
        try:
            database.stop_shift(shift_id)
            return {"ok": True}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    # Leave application / approval APIs. Only closed PERSONAL events are eligible.
    @app.post("/api/events/{event_id}/leave/apply")
    async def apply_leave(event_id: int, request: Request):
        payload = await request.json()
        try:
            event = database.apply_leave(event_id, str(payload.get("note", "")))
            return {"ok": True, "event": event}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/events/{event_id}/leave/review")
    async def review_leave(event_id: int, request: Request):
        payload = await request.json()
        action = str(payload.get("action", "")).lower()
        if action not in {"approve", "reject"}:
            raise HTTPException(status_code=400, detail="action 必须为 approve 或 reject")
        try:
            event = database.review_leave(event_id, approved=action == "approve")
            return {"ok": True, "event": event}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    # Runtime, media and export
    @app.get("/api/status")
    async def status():
        return JSONResponse(runtime.status())

    @app.get("/stream/monitor.mjpg")
    async def monitor_stream():
        return mjpeg_response(runtime.annotated_store)

    @app.get("/stream/raw.mjpg")
    async def raw_stream():
        return mjpeg_response(runtime.raw_store)

    @app.get("/snapshot.jpg")
    async def snapshot():
        jpeg, _ = runtime.annotated_store.wait(-1, timeout=2.0)
        if jpeg is None:
            raise HTTPException(status_code=503, detail="尚无画面")
        return Response(jpeg, media_type="image/jpeg")

    @app.get("/api/events.csv")
    async def events_csv(
        employee_id: Optional[int] = None,
        workstation_id: Optional[int] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        category: Optional[str] = None,
    ):
        events = database.query_events(
            employee_id=employee_id,
            workstation_id=workstation_id,
            start_date=start_date,
            end_date=end_date,
            category=category,
            limit=10000,
        )
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(
            [
                "事件ID",
                "记录分类",
                "事件类型",
                "关联事件ID",
                "员工ID",
                "员工姓名",
                "工作台",
                "离开/未到岗时间",
                "告警时间",
                "返回/结束时间",
                "持续时长(秒)",
                "事件状态",
                "请假状态",
                "请假备注",
                "离开截图",
                "告警截图",
                "返回截图",
            ]
        )
        for event in events:
            writer.writerow(
                [
                    event.get("id"),
                    event.get("history_category"),
                    event.get("event_name"),
                    event.get("incident_id"),
                    event.get("employee_code"),
                    event.get("employee_name"),
                    event.get("workstation_name"),
                    event.get("leave_at"),
                    event.get("alert_at"),
                    event.get("return_at"),
                    event.get("duration_sec"),
                    event.get("status"),
                    event.get("leave_status"),
                    event.get("leave_note"),
                    event.get("leave_snapshot"),
                    event.get("alert_snapshot"),
                    event.get("return_snapshot"),
                ]
            )
        return Response(
            output.getvalue().encode("utf-8-sig"),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=absence_events.csv"},
        )

    @app.websocket("/ws/live")
    async def live_websocket(websocket: WebSocket):
        await websocket.accept()
        last_alert_revision = -1
        while True:
            revision, alert = alerts.latest()
            payload = {"status": runtime.status(), "alert": None}
            if revision != last_alert_revision:
                payload["alert"] = alert
                last_alert_revision = revision
            try:
                await websocket.send_json(payload)
                await asyncio.sleep(1.0)
            except Exception:
                break

    return app
