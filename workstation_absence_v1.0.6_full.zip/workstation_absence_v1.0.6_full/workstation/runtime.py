from __future__ import annotations

import json
import threading
import time
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

import cv2
import numpy as np

from .camera import CameraManager
from .database import Database
from .geometry import denormalize_polygon, point_in_polygon
from .identity import IdentityBinding, IdentityService
from .models import FaceDetection, ModelHub
from .presence import PresenceManager, RegionStatus, ShiftStatus
from .tracker import ByteTrackLite, Track


SKELETON = (
    (15, 13),
    (13, 11),
    (16, 14),
    (14, 12),
    (11, 12),
    (5, 11),
    (6, 12),
    (5, 6),
    (5, 7),
    (7, 9),
    (6, 8),
    (8, 10),
)


class JPEGStore:
    def __init__(self) -> None:
        self.condition = threading.Condition()
        self.jpeg: Optional[bytes] = None
        self.version = 0

    def update(self, jpeg: bytes) -> None:
        with self.condition:
            self.jpeg = jpeg
            self.version += 1
            self.condition.notify_all()

    def wait(self, previous_version: int, timeout: float = 2.0):
        with self.condition:
            self.condition.wait_for(
                lambda: self.version != previous_version, timeout=timeout
            )
            return self.jpeg, self.version


class RuntimeService(threading.Thread):
    def __init__(
        self,
        *,
        camera: CameraManager,
        models: ModelHub,
        database: Database,
        runtime_config: Dict[str, Any],
        presence_config: Dict[str, Any],
        event_dir: str | Path,
        alert_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> None:
        super().__init__(name="runtime-service", daemon=True)
        self.camera = camera
        self.models = models
        self.database = database
        self.runtime_config = runtime_config
        self.stop_event = threading.Event()
        self.error: Optional[str] = None
        self.annotated_store = JPEGStore()
        self.raw_store = JPEGStore()
        self._status_lock = threading.RLock()
        self._status: Dict[str, Any] = {"state": "starting"}

        self.tracker = ByteTrackLite(
            track_thresh=float(runtime_config.get("track_thresh", 0.45)),
            low_thresh=float(runtime_config.get("track_low_thresh", 0.10)),
            new_track_thresh=float(runtime_config.get("new_track_thresh", 0.55)),
            match_thresh=float(runtime_config.get("match_thresh", 0.75)),
            track_buffer=int(runtime_config.get("track_buffer", 30)),
        )
        recognition_config = (
            models.face_recognizer.config if models.face_recognizer else {}
        )
        self.identity = IdentityService(
            database=database,
            models=models,
            similarity_threshold=float(
                recognition_config.get("similarity_threshold", 0.55)
            ),
            recognition_cooldown_sec=float(
                runtime_config.get("face_recognition_cooldown_sec", 1.5)
            ),
            binding_ttl_sec=float(runtime_config.get("binding_ttl_sec", 5.0)),
        )
        self.presence = PresenceManager(
            database=database,
            event_dir=event_dir,
            hip_confidence=float(presence_config.get("hip_keypoint_confidence", 0.30)),
            binding_hold_sec=float(runtime_config.get("binding_ttl_sec", 5.0)),
            alert_callback=alert_callback,
        )
        self.latest_tracks: List[Track] = []
        self.latest_faces: List[FaceDetection] = []
        self.latest_bindings: Dict[int, IdentityBinding] = {}
        self.latest_shift_status: List[ShiftStatus] = []
        self.latest_region_status: List[RegionStatus] = []
        self._latest_frame_shape = (0, 0)

    def stop(self) -> None:
        self.stop_event.set()

    def status(self) -> Dict[str, Any]:
        with self._status_lock:
            return json.loads(json.dumps(self._status, ensure_ascii=False))

    def _set_status(self, value: Dict[str, Any]) -> None:
        with self._status_lock:
            self._status = value

    def test_workstation(
        self,
        workstation_id: int,
        roi_override: Optional[Sequence[Sequence[float]]] = None,
    ) -> Dict[str, Any]:
        """
        测试工作台区域。

        roi_override用于网页当前尚未保存的Canvas草稿，因此“测试区域判断”
        不再依赖数据库中已经保存的ROI。
        """
        workstation = self.database.get_workstation(workstation_id)
        if workstation is None:
            raise ValueError("工作台不存在")

        roi_source = roi_override if roi_override is not None else workstation["roi"]
        roi: List[List[float]] = []
        for point in roi_source or []:
            if not isinstance(point, (list, tuple)) or len(point) != 2:
                raise ValueError("ROI点格式错误")
            x = float(point[0])
            y = float(point[1])
            if not 0.0 <= x <= 1.0 or not 0.0 <= y <= 1.0:
                raise ValueError("ROI坐标必须位于0~1")
            roi.append([x, y])

        height, width = self._latest_frame_shape
        if height <= 0 or width <= 0:
            return {
                "ready": False,
                "message": "尚无摄像头画面",
                "people": [],
                "frame_size": [0, 0],
                "roi": roi,
            }

        if len(roi) < 3:
            return {
                "ready": False,
                "message": "当前ROI草稿至少需要3个点",
                "people": [],
                "frame_size": [width, height],
                "roi": roi,
            }

        people = []
        for track in self.latest_tracks:
            anchor = self.presence.anchor(track)
            binding = self.latest_bindings.get(track.track_id)
            people.append(
                {
                    "track_id": track.track_id,
                    "anchor": [round(anchor[0], 1), round(anchor[1], 1)],
                    "inside": point_in_polygon(anchor, roi, width, height),
                    "employee_code": binding.employee_code if binding else None,
                    "employee_name": binding.employee_name if binding else None,
                    "score": round(float(track.score), 4),
                }
            )

        if people:
            inside_count = sum(1 for person in people if person["inside"])
            message = f"检测到{len(people)}个人体，ROI内{inside_count}人"
        else:
            message = "ROI有效，但当前画面没有检测到人体"

        tested_workstation = dict(workstation)
        tested_workstation["roi"] = roi
        return {
            "ready": True,
            "message": message,
            "workstation": tested_workstation,
            "frame_size": [width, height],
            "people": people,
            "roi": roi,
        }

    @staticmethod
    def _draw_track(
        image: np.ndarray,
        track: Track,
        binding: Optional[IdentityBinding],
        keypoint_confidence: float,
    ) -> None:
        x1, y1, x2, y2 = np.round(track.bbox).astype(int)
        color = (0, 220, 0) if binding else (0, 180, 255)
        cv2.rectangle(image, (x1, y1), (x2, y2), color, 3)
        label = (
            f"{binding.employee_code} {binding.employee_name} T{track.track_id} {binding.similarity:.2f}"
            if binding
            else f"UNKNOWN T{track.track_id} {track.score:.2f}"
        )
        cv2.putText(
            image,
            label,
            (x1, max(28, y1 - 8)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.72,
            color,
            2,
            cv2.LINE_AA,
        )
        keypoints = np.asarray(track.keypoints)
        if keypoints.shape == (17, 3):
            for x, y, confidence in keypoints:
                if confidence >= keypoint_confidence:
                    cv2.circle(image, (int(x), int(y)), 4, (255, 0, 255), -1)
            for start, end in SKELETON:
                first = keypoints[start]
                second = keypoints[end]
                if first[2] >= keypoint_confidence and second[2] >= keypoint_confidence:
                    cv2.line(
                        image,
                        (int(first[0]), int(first[1])),
                        (int(second[0]), int(second[1])),
                        (255, 80, 0),
                        2,
                    )

    def _draw_overlay(self, frame: np.ndarray) -> np.ndarray:
        result = frame.copy()
        height, width = result.shape[:2]
        status_by_workstation = {
            status.workstation_id: status for status in self.latest_region_status
        }
        colors = {
            "PRESENT": (0, 210, 0),
            "WAITING": (0, 220, 255),
            "GRACE": (0, 220, 255),
            "AWAY": (0, 150, 255),
            "ALERT": (0, 0, 255),
            "CAMERA_OFFLINE": (100, 100, 100),
            "UNCONFIGURED": (180, 180, 180),
        }
        for workstation in self.database.list_workstations(include_disabled=False):
            roi = workstation["roi"]
            if len(roi) < 3:
                continue
            contour = denormalize_polygon(roi, width, height).reshape(-1, 1, 2)
            status = status_by_workstation.get(int(workstation["id"]))
            state = status.state if status else "UNASSIGNED"
            color = colors.get(state, (170, 170, 170))
            cv2.polylines(result, [contour], True, color, 4)
            x, y = contour[0, 0]
            text = f"{workstation['name']} {state}"
            if status and status.elapsed_shortage_sec:
                text += f" shortage={status.elapsed_shortage_sec}s {status.present_count}/{status.required_count}"
            cv2.putText(
                result,
                text,
                (int(x), max(35, int(y) - 10)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                color,
                3,
                cv2.LINE_AA,
            )

        keypoint_confidence = (
            self.models.pose.keypoint_confidence if self.models.pose else 0.35
        )
        for track in self.latest_tracks:
            self._draw_track(
                result,
                track,
                self.latest_bindings.get(track.track_id),
                keypoint_confidence,
            )
            anchor = self.presence.anchor(track)
            cv2.circle(result, (int(anchor[0]), int(anchor[1])), 7, (255, 255, 0), -1)

        for face in self.latest_faces:
            x1, y1, x2, y2 = np.round(face.bbox).astype(int)
            cv2.rectangle(result, (x1, y1), (x2, y2), (0, 0, 255), 2)
            for x, y in face.landmarks:
                cv2.circle(result, (int(x), int(y)), 3, (255, 255, 0), -1)
        return result

    @staticmethod
    def _resize_preview(frame: np.ndarray, maximum_width: int = 1280) -> np.ndarray:
        if frame.shape[1] <= maximum_width:
            return frame
        height = int(frame.shape[0] * maximum_width / frame.shape[1])
        return cv2.resize(frame, (maximum_width, height), interpolation=cv2.INTER_AREA)

    @staticmethod
    def _encode(frame: np.ndarray, quality: int) -> bytes:
        success, encoded = cv2.imencode(
            ".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, int(quality)]
        )
        if not success:
            raise RuntimeError("JPEG编码失败")
        return encoded.tobytes()

    def run(self) -> None:
        pose_interval = 1.0 / max(float(self.runtime_config.get("pose_fps", 10)), 0.1)
        face_interval = 1.0 / max(float(self.runtime_config.get("face_fps", 3)), 0.1)
        preview_interval = 1.0 / max(
            float(self.runtime_config.get("preview_fps", 10)), 0.1
        )
        quality = int(self.runtime_config.get("jpeg_quality", 75))
        max_faces = int(self.runtime_config.get("max_faces_per_cycle", 4))
        next_pose = next_face = next_preview = 0.0
        last_sequence = -1
        last_device = None
        pose_ms = face_detector_ms = recognition_ms = 0.0

        try:
            while not self.stop_event.is_set():
                active_device = self.camera.active_device
                if active_device != last_device:
                    last_sequence = -1
                    last_device = active_device
                    self.latest_tracks = []
                    self.latest_faces = []
                    self.latest_bindings = {}
                    self.tracker.tracks.clear()

                frame, sequence, frame_timestamp = self.camera.frames.latest(copy=True)
                if frame is None:
                    self._set_status(
                        {
                            "state": "waiting_camera",
                            "camera": self.camera.status(),
                            "models": {"error": self.error},
                            "shifts": [asdict(item) for item in self.latest_shift_status],
                            "regions": [asdict(item) for item in self.latest_region_status],
                        }
                    )
                    time.sleep(0.05)
                    continue
                if sequence == last_sequence:
                    time.sleep(0.003)
                    continue
                last_sequence = sequence
                now = time.monotonic()
                self._latest_frame_shape = frame.shape[:2]

                if self.models.pose is not None and now >= next_pose:
                    with self.models.pose_lock:
                        detections, pose_ms = self.models.pose.infer(frame)
                    self.latest_tracks = self.tracker.update(detections)
                    next_pose = now + pose_interval

                if self.models.face_detector is not None and now >= next_face:
                    with self.models.face_lock:
                        self.latest_faces, face_detector_ms = (
                            self.models.face_detector.infer(frame)
                        )
                        self.latest_bindings, recognition_ms = self.identity.update(
                            frame,
                            self.latest_faces,
                            self.latest_tracks,
                            max_faces=max_faces,
                        )
                    next_face = now + face_interval

                height, width = frame.shape[:2]
                self.latest_shift_status, self.latest_region_status = self.presence.evaluate(
                    frame=frame,
                    frame_width=width,
                    frame_height=height,
                    tracks=self.latest_tracks,
                    bindings=self.latest_bindings,
                    camera_online=self.camera.online,
                    active_camera_device=self.camera.active_device,
                )

                if now >= next_preview:
                    annotated = self._resize_preview(self._draw_overlay(frame))
                    raw = self._resize_preview(frame)
                    self.annotated_store.update(self._encode(annotated, quality))
                    self.raw_store.update(self._encode(raw, quality))
                    next_preview = now + preview_interval

                self._set_status(
                    {
                        "state": "running",
                        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "camera": self.camera.status(),
                        "performance": {
                            "pose_ms": round(pose_ms, 2),
                            "retinaface_ms": round(face_detector_ms, 2),
                            "recognition_ms": round(recognition_ms, 2),
                        },
                        "model_paths": {
                            "pose": str(self.models.pose.backend.path)
                            if self.models.pose
                            else None,
                            "retinaface": str(self.models.face_detector.backend.path)
                            if self.models.face_detector
                            else None,
                            "recognition": str(self.models.face_recognizer.backend.path)
                            if self.models.face_recognizer
                            else None,
                        },
                        "identity": {
                            "profile_count": self.identity.profile_count,
                            "binding_count": len(self.latest_bindings),
                            "similarity_threshold": self.identity.similarity_threshold,
                        },
                        "tracks": [
                            {
                                "track_id": track.track_id,
                                "bbox": [round(float(value), 1) for value in track.bbox],
                                "score": round(track.score, 3),
                                "anchor": [
                                    round(value, 1) for value in self.presence.anchor(track)
                                ],
                                "identity": (
                                    {
                                        "employee_id": self.latest_bindings[
                                            track.track_id
                                        ].employee_id,
                                        "employee_code": self.latest_bindings[
                                            track.track_id
                                        ].employee_code,
                                        "employee_name": self.latest_bindings[
                                            track.track_id
                                        ].employee_name,
                                        "similarity": round(
                                            self.latest_bindings[
                                                track.track_id
                                            ].similarity,
                                            4,
                                        ),
                                        "last_recognized_at": self.latest_bindings[
                                            track.track_id
                                        ].last_recognized_at,
                                    }
                                    if track.track_id in self.latest_bindings
                                    else None
                                ),
                            }
                            for track in self.latest_tracks
                        ],
                        "shifts": [asdict(item) for item in self.latest_shift_status],
                        "regions": [asdict(item) for item in self.latest_region_status],
                    }
                )
        except Exception as exc:
            self.error = f"RuntimeService失败：{type(exc).__name__}: {exc}"
            self._set_status({"state": "error", "error": self.error})
            print(self.error)
            self.stop_event.set()
