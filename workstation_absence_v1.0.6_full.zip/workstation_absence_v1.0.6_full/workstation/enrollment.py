from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import cv2
import numpy as np

from .camera import CameraManager
from .database import Database
from .models import FaceDetection, ModelHub


ARC_FACE_TEMPLATE_112 = np.asarray(
    [
        [38.2946, 51.6963],
        [73.5318, 51.5014],
        [56.0252, 71.7366],
        [41.5493, 92.3655],
        [70.7299, 92.2041],
    ],
    dtype=np.float32,
)

SLOT_LABELS = {
    "front": "正脸",
    "left": "轻微左转",
    "right": "轻微右转",
    "up_down": "轻微抬头或低头",
    "work": "正常工作姿态",
    "extra_1": "补充照片1",
    "extra_2": "补充照片2",
    "extra_3": "补充照片3",
    "extra_4": "补充照片4",
    "extra_5": "补充照片5",
}


def align_face_5points(
    frame_bgr: np.ndarray,
    landmarks: np.ndarray,
    output_width: int = 112,
    output_height: int = 112,
) -> np.ndarray:
    source = np.asarray(landmarks, dtype=np.float32).reshape(5, 2)
    template = ARC_FACE_TEMPLATE_112.copy()
    template[:, 0] *= output_width / 112.0
    template[:, 1] *= output_height / 112.0
    matrix, _ = cv2.estimateAffinePartial2D(source, template, method=cv2.LMEDS)
    if matrix is None:
        raise RuntimeError("5点人脸对齐失败")
    return cv2.warpAffine(
        frame_bgr,
        matrix,
        (output_width, output_height),
        flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=(0, 0, 0),
    )


def _pose_metrics(landmarks: np.ndarray) -> Dict[str, float]:
    points = np.asarray(landmarks, dtype=np.float32).reshape(5, 2)
    left_eye, right_eye, nose, left_mouth, right_mouth = points
    eye_distance = float(np.linalg.norm(right_eye - left_eye)) + 1e-6
    eye_mid = (left_eye + right_eye) / 2.0
    mouth_mid = (left_mouth + right_mouth) / 2.0
    yaw_proxy = float((nose[0] - eye_mid[0]) / eye_distance)
    roll_deg = float(
        np.degrees(np.arctan2(right_eye[1] - left_eye[1], right_eye[0] - left_eye[0]))
    )
    vertical_ratio = float((nose[1] - eye_mid[1]) / (mouth_mid[1] - eye_mid[1] + 1e-6))
    return {
        "yaw_proxy": yaw_proxy,
        "roll_deg": roll_deg,
        "vertical_ratio": vertical_ratio,
    }


def evaluate_quality(
    frame: np.ndarray,
    face: FaceDetection,
    config: Dict[str, Any],
) -> Dict[str, Any]:
    x1, y1, x2, y2 = face.bbox.astype(int)
    x1 = max(0, x1)
    y1 = max(0, y1)
    x2 = min(frame.shape[1], x2)
    y2 = min(frame.shape[0], y2)
    crop = frame[y1:y2, x1:x2]
    if crop.size == 0:
        raise ValueError("人脸裁剪区域为空")

    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    blur_score = float(cv2.Laplacian(gray, cv2.CV_64F).var())
    brightness = float(np.mean(gray))
    face_width = int(x2 - x1)
    face_height = int(y2 - y1)
    metrics = _pose_metrics(face.landmarks)

    minimum_width = int(config.get("minimum_face_width", 100))
    minimum_blur = float(config.get("minimum_blur_score", 45.0))
    minimum_detection = float(config.get("minimum_detection_score", 0.60))
    minimum_brightness = float(config.get("minimum_brightness", 45.0))
    maximum_brightness = float(config.get("maximum_brightness", 220.0))

    reasons = []
    if face_width < minimum_width:
        reasons.append(f"人脸太小：{face_width}px，至少需要{minimum_width}px")
    if blur_score < minimum_blur:
        reasons.append(f"画面模糊：{blur_score:.1f}，至少需要{minimum_blur:.1f}")
    if face.score < minimum_detection:
        reasons.append(f"检测置信度不足：{face.score:.3f}")
    if brightness < minimum_brightness:
        reasons.append(f"画面太暗：亮度{brightness:.1f}")
    if brightness > maximum_brightness:
        reasons.append(f"画面过曝：亮度{brightness:.1f}")
    if abs(metrics["roll_deg"]) > 25:
        reasons.append(f"头部倾斜过大：{metrics['roll_deg']:.1f}°")

    width_score = min(100.0, face_width / max(minimum_width, 1) * 70.0)
    blur_component = min(100.0, blur_score / max(minimum_blur, 1.0) * 70.0)
    brightness_component = max(0.0, 100.0 - abs(brightness - 132.0) * 0.8)
    confidence_component = min(100.0, float(face.score) * 100.0)
    quality_score = (
        width_score * 0.25
        + blur_component * 0.35
        + brightness_component * 0.15
        + confidence_component * 0.25
    )

    return {
        "accepted": not reasons,
        "reasons": reasons,
        "quality_score": round(float(quality_score), 1),
        "face_width": face_width,
        "face_height": face_height,
        "blur_score": round(blur_score, 2),
        "brightness": round(brightness, 2),
        "detection_score": round(float(face.score), 4),
        **{key: round(value, 4) for key, value in metrics.items()},
    }


class EnrollmentService:
    def __init__(
        self,
        *,
        camera: CameraManager,
        models: ModelHub,
        database: Database,
        enrollment_dir: str | Path,
        config: Dict[str, Any],
    ) -> None:
        self.camera = camera
        self.models = models
        self.database = database
        self.enrollment_dir = Path(enrollment_dir)
        self.enrollment_dir.mkdir(parents=True, exist_ok=True)
        self.config = config

    def _validate_slot(self, slot_label: str) -> str:
        if slot_label not in SLOT_LABELS:
            raise ValueError(f"无效拍照位置：{slot_label}")
        return slot_label

    def _process_frame(
        self,
        *,
        employee_id: int,
        slot_label: str,
        frame: np.ndarray,
        source_type: str,
    ) -> Dict[str, Any]:
        employee = self.database.get_employee(employee_id)
        if employee is None:
            raise ValueError("员工不存在")
        self._validate_slot(slot_label)
        if self.models.face_detector is None or self.models.face_recognizer is None:
            raise RuntimeError("RetinaFace或W600K模型未启用")

        with self.models.face_lock:
            faces, detector_ms = self.models.face_detector.infer(frame)
            if len(faces) == 0:
                raise ValueError("未检测到人脸，请正对摄像头")
            if len(faces) > 1:
                raise ValueError("画面中检测到多张人脸，录入时只能有一名员工")
            face = faces[0]
            quality = evaluate_quality(frame, face, self.config)
            if not quality["accepted"]:
                raise ValueError("；".join(quality["reasons"]))
            recognizer = self.models.face_recognizer
            aligned = align_face_5points(
                frame,
                face.landmarks,
                recognizer.input_width,
                recognizer.input_height,
            )
            embedding, recognition_ms = recognizer.infer(aligned)

        employee_dir = self.enrollment_dir / str(employee["employee_code"])
        employee_dir.mkdir(parents=True, exist_ok=True)
        timestamp_ms = int(time.time() * 1000)
        frame_path = employee_dir / f"{timestamp_ms}_{slot_label}_frame.jpg"
        aligned_path = employee_dir / f"{timestamp_ms}_{slot_label}_aligned.jpg"
        if not cv2.imwrite(str(frame_path), frame):
            raise RuntimeError(f"原始照片保存失败：{frame_path}")
        if not cv2.imwrite(str(aligned_path), aligned):
            raise RuntimeError(f"对齐照片保存失败：{aligned_path}")

        quality["retinaface_ms"] = round(detector_ms, 3)
        quality["recognition_ms"] = round(recognition_ms, 3)
        sample_id = self.database.add_face_sample(
            employee_id=employee_id,
            slot_label=slot_label,
            source_type=source_type,
            image_path=str(frame_path),
            aligned_image_path=str(aligned_path),
            embedding=embedding,
            quality=quality,
            replace_slot=True,
        )
        return {
            "sample_id": sample_id,
            "slot_label": slot_label,
            "slot_name": SLOT_LABELS[slot_label],
            "quality": quality,
            "aligned_url": (
                f"/media/enrollment/{employee['employee_code']}/{aligned_path.name}"
            ),
        }

    def capture(self, employee_id: int, slot_label: str) -> Dict[str, Any]:
        frame, sequence, _ = self.camera.frames.latest(copy=True)
        if frame is None:
            raise RuntimeError("摄像头尚未产生画面")
        result = self._process_frame(
            employee_id=employee_id,
            slot_label=slot_label,
            frame=frame,
            source_type="camera",
        )
        result["camera_sequence"] = sequence
        return result

    def upload(
        self, employee_id: int, slot_label: str, file_bytes: bytes
    ) -> Dict[str, Any]:
        array = np.frombuffer(file_bytes, dtype=np.uint8)
        frame = cv2.imdecode(array, cv2.IMREAD_COLOR)
        if frame is None:
            raise ValueError("上传文件不是有效图片")
        return self._process_frame(
            employee_id=employee_id,
            slot_label=slot_label,
            frame=frame,
            source_type="upload",
        )

    def regenerate_profile(self, employee_id: int) -> Dict[str, Any]:
        samples = self.database.list_face_samples(employee_id, include_embedding=True)
        minimum_samples = int(self.config.get("minimum_samples", 5))
        maximum_samples = int(self.config.get("maximum_samples", 10))
        required_slots = set(self.config.get("required_slots", []))
        slots = {sample["slot_label"] for sample in samples}
        missing_slots = sorted(required_slots - slots)
        if len(samples) < minimum_samples:
            raise ValueError(f"至少需要{minimum_samples}张合格照片，当前{len(samples)}张")
        if len(samples) > maximum_samples:
            raise ValueError(f"最多允许{maximum_samples}张照片，当前{len(samples)}张")
        if missing_slots:
            missing_names = [SLOT_LABELS.get(item, item) for item in missing_slots]
            raise ValueError("缺少必拍姿态：" + "、".join(missing_names))

        embeddings = np.stack([sample["embedding_array"] for sample in samples])
        centroid = embeddings.mean(axis=0)
        norm = float(np.linalg.norm(centroid))
        if norm <= 1e-12:
            raise RuntimeError("综合人脸特征为零向量")
        centroid /= norm
        quality_score = float(
            np.mean([sample["quality"].get("quality_score", 0.0) for sample in samples])
        )
        self.database.save_face_profile(
            employee_id,
            centroid,
            sample_count=len(samples),
            quality_score=quality_score,
        )
        return {
            "employee_id": employee_id,
            "sample_count": len(samples),
            "embedding_dim": int(centroid.size),
            "quality_score": round(quality_score, 1),
        }

    def enrollment_status(self, employee_id: int) -> Dict[str, Any]:
        samples = self.database.list_face_samples(employee_id)
        by_slot = {sample["slot_label"]: sample for sample in samples}
        required_slots = list(self.config.get("required_slots", []))
        minimum_samples = int(self.config.get("minimum_samples", 5))
        maximum_samples = int(self.config.get("maximum_samples", 10))
        return {
            "samples": samples,
            "by_slot": by_slot,
            "required_slots": required_slots,
            "minimum_samples": minimum_samples,
            "maximum_samples": maximum_samples,
            "completed_required": sum(1 for slot in required_slots if slot in by_slot),
            "ready": (
                len(samples) >= minimum_samples
                and all(slot in by_slot for slot in required_slots)
            ),
            "slot_labels": SLOT_LABELS,
        }
