from __future__ import annotations

import glob
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import cv2
import numpy as np


def _read_exact(stream, size: int) -> Optional[bytes]:
    chunks: List[bytes] = []
    remaining = size
    while remaining > 0:
        chunk = stream.read(remaining)
        if not chunk:
            return None
        chunks.append(chunk)
        remaining -= len(chunk)
    return b"".join(chunks)


class FrameSlot:
    """线程安全的最新帧缓存。旧帧直接覆盖，避免实时系统积压。"""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._frame: Optional[np.ndarray] = None
        self._sequence = -1
        self._timestamp = 0.0
        self._error: Optional[str] = None

    def update(self, frame: np.ndarray, timestamp: float) -> None:
        with self._lock:
            self._frame = frame
            self._sequence += 1
            self._timestamp = timestamp
            self._error = None

    def latest(self, copy: bool = False) -> Tuple[Optional[np.ndarray], int, float]:
        with self._lock:
            frame = self._frame.copy() if copy and self._frame is not None else self._frame
            return frame, self._sequence, self._timestamp

    def clear(self) -> None:
        with self._lock:
            self._frame = None
            self._sequence = -1
            self._timestamp = 0.0
            self._error = None

    def set_error(self, message: str) -> None:
        with self._lock:
            self._error = message

    def error(self) -> Optional[str]:
        with self._lock:
            return self._error


class V4L2CameraWorker(threading.Thread):
    def __init__(
        self,
        *,
        device: str,
        width: int,
        height: int,
        fps: int,
        warmup: int,
        buffers: int,
        pixel_format: str,
        frame_slot: FrameSlot,
    ) -> None:
        super().__init__(name=f"camera-{Path(device).name}", daemon=True)
        self.device = device
        self.width = int(width)
        self.height = int(height)
        self.fps = int(fps)
        self.warmup = int(warmup)
        self.buffers = int(buffers)
        self.pixel_format = pixel_format.upper()
        self.frame_slot = frame_slot
        self.stop_event = threading.Event()
        self.process: Optional[subprocess.Popen] = None
        self.frame_size = self.width * self.height * 3 // 2
        self.log_path = Path(f"/tmp/workstation_{Path(device).name}.log")

    def validate(self) -> None:
        if shutil.which("v4l2-ctl") is None:
            raise RuntimeError("找不到v4l2-ctl，请安装v4l-utils")
        if not Path(self.device).exists():
            raise FileNotFoundError(f"摄像头节点不存在：{self.device}")
        if self.pixel_format != "NV12":
            raise ValueError("当前CameraService只实现NV12采集")

    def stop(self) -> None:
        self.stop_event.set()
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.process.kill()

    def run(self) -> None:
        try:
            self.validate()
            command = [
                "v4l2-ctl",
                "-d",
                self.device,
                (
                    "--set-fmt-video="
                    f"width={self.width},height={self.height},pixelformat={self.pixel_format}"
                ),
                f"--set-parm={self.fps}",
                f"--stream-mmap={self.buffers}",
                f"--stream-skip={self.warmup}",
                "--stream-poll",
                "--stream-to=-",
            ]
            print("[Camera] " + " ".join(command))
            self.log_path.unlink(missing_ok=True)
            with self.log_path.open("w", encoding="utf-8") as log_file:
                self.process = subprocess.Popen(
                    command,
                    stdout=subprocess.PIPE,
                    stderr=log_file,
                    bufsize=0,
                )
                if self.process.stdout is None:
                    raise RuntimeError("无法读取v4l2-ctl标准输出")

                while not self.stop_event.is_set():
                    raw_bytes = _read_exact(self.process.stdout, self.frame_size)
                    if raw_bytes is None:
                        if self.stop_event.is_set():
                            break
                        log_file.flush()
                        detail = ""
                        if self.log_path.exists():
                            detail = self.log_path.read_text(
                                encoding="utf-8", errors="replace"
                            )[-3000:]
                        raise RuntimeError(
                            f"摄像头数据流中断，ret={self.process.poll()}\n{detail}"
                        )

                    raw = np.frombuffer(raw_bytes, dtype=np.uint8)
                    if raw.size != self.frame_size:
                        raise RuntimeError(
                            f"NV12帧大小错误：实际{raw.size}，预期{self.frame_size}"
                        )
                    nv12 = raw.reshape(self.height * 3 // 2, self.width)
                    frame = cv2.cvtColor(nv12, cv2.COLOR_YUV2BGR_NV12)
                    self.frame_slot.update(frame, time.monotonic())
        except Exception as exc:
            message = f"摄像头失败：{type(exc).__name__}: {exc}"
            self.frame_slot.set_error(message)
            print(message, file=sys.stderr)
        finally:
            self.stop()


class CameraManager:
    """系统唯一摄像头管理器。任何时刻只打开一个V4L2节点。"""

    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = dict(config)
        self.frames = FrameSlot()
        self._lock = threading.RLock()
        self._worker: Optional[V4L2CameraWorker] = None
        self._active_device = str(config["device"])
        self._started_at = 0.0

    @property
    def active_device(self) -> str:
        with self._lock:
            return self._active_device

    @property
    def online(self) -> bool:
        with self._lock:
            worker = self._worker
        frame, _, timestamp = self.frames.latest(copy=False)
        return (
            worker is not None
            and worker.is_alive()
            and frame is not None
            and self.frames.error() is None
            and time.monotonic() - timestamp < 3.0
        )

    def start(self) -> None:
        with self._lock:
            if self._worker is not None and self._worker.is_alive():
                return
            self._start_locked(self._active_device)

    def _start_locked(self, device: str) -> None:
        self.frames.clear()
        worker = V4L2CameraWorker(
            device=device,
            width=int(self.config["width"]),
            height=int(self.config["height"]),
            fps=int(self.config["fps"]),
            warmup=int(self.config.get("warmup", 10)),
            buffers=int(self.config.get("buffers", 4)),
            pixel_format=str(self.config.get("pixel_format", "NV12")),
            frame_slot=self.frames,
        )
        self._worker = worker
        self._active_device = device
        self._started_at = time.monotonic()
        worker.start()

    def switch(self, device: str) -> None:
        device = str(device)
        if not Path(device).exists():
            raise FileNotFoundError(f"摄像头节点不存在：{device}")
        with self._lock:
            if device == self._active_device and self._worker and self._worker.is_alive():
                return
            previous = self._worker
            if previous is not None:
                previous.stop()
                previous.join(timeout=3)
            self._start_locked(device)

    def stop(self) -> None:
        with self._lock:
            worker = self._worker
            self._worker = None
        if worker is not None:
            worker.stop()
            worker.join(timeout=3)

    def status(self) -> Dict[str, Any]:
        frame, sequence, timestamp = self.frames.latest(copy=False)
        return {
            "active_device": self.active_device,
            "online": self.online,
            "sequence": sequence,
            "frame_age_ms": (
                round(max(0.0, time.monotonic() - timestamp) * 1000.0, 1)
                if frame is not None
                else None
            ),
            "error": self.frames.error(),
            "width": int(self.config["width"]),
            "height": int(self.config["height"]),
            "fps": int(self.config["fps"]),
        }

    @staticmethod
    def list_devices() -> List[Dict[str, str]]:
        devices = sorted(glob.glob("/dev/video*"), key=lambda item: int(re.findall(r"\d+", item)[-1]))
        labels: Dict[str, str] = {}
        if shutil.which("v4l2-ctl"):
            try:
                output = subprocess.check_output(
                    ["v4l2-ctl", "--list-devices"],
                    text=True,
                    stderr=subprocess.DEVNULL,
                    timeout=3,
                )
                current = "V4L2 Camera"
                for line in output.splitlines():
                    if line and not line[0].isspace():
                        current = line.rstrip(":")
                    elif line.strip().startswith("/dev/video"):
                        labels[line.strip()] = current
            except Exception:
                pass
        return [{"device": device, "label": labels.get(device, device)} for device in devices]
