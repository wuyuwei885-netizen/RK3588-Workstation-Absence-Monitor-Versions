from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Sequence, Tuple

import numpy as np

from .geometry import bbox_iou
from .models import PersonDetection


@dataclass
class Track:
    track_id: int
    bbox: np.ndarray
    score: float
    keypoints: np.ndarray
    velocity: np.ndarray = field(default_factory=lambda: np.zeros(4, dtype=np.float32))
    age: int = 1
    hits: int = 1
    missed: int = 0
    active: bool = True

    def predict(self) -> np.ndarray:
        return self.bbox + self.velocity

    def update(self, detection: PersonDetection) -> None:
        new_box = detection.bbox.astype(np.float32, copy=True)
        self.velocity = 0.70 * self.velocity + 0.30 * (new_box - self.bbox)
        self.bbox = new_box
        self.score = float(detection.score)
        self.keypoints = detection.keypoints.copy()
        self.age += 1
        self.hits += 1
        self.missed = 0
        self.active = True


def _cost_matrix(tracks: Sequence[Track], detections: Sequence[PersonDetection]) -> np.ndarray:
    matrix = np.ones((len(tracks), len(detections)), dtype=np.float32)
    for row, track in enumerate(tracks):
        predicted = track.predict()
        for column, detection in enumerate(detections):
            matrix[row, column] = 1.0 - bbox_iou(predicted, detection.bbox)
    return matrix


def _greedy_assignment(
    cost: np.ndarray, maximum_cost: float
) -> Tuple[List[Tuple[int, int]], List[int], List[int]]:
    if cost.size == 0:
        return [], list(range(cost.shape[0])), list(range(cost.shape[1]))
    remaining_rows = set(range(cost.shape[0]))
    remaining_columns = set(range(cost.shape[1]))
    matches: List[Tuple[int, int]] = []
    while remaining_rows and remaining_columns:
        best: Tuple[int, int] | None = None
        best_cost = float("inf")
        for row in remaining_rows:
            for column in remaining_columns:
                value = float(cost[row, column])
                if value < best_cost:
                    best = (row, column)
                    best_cost = value
        if best is None or best_cost > maximum_cost:
            break
        row, column = best
        matches.append((row, column))
        remaining_rows.remove(row)
        remaining_columns.remove(column)
    return matches, sorted(remaining_rows), sorted(remaining_columns)


class ByteTrackLite:
    """ByteTrack风格的两阶段关联，避免额外安装PyTorch。"""

    def __init__(
        self,
        *,
        track_thresh: float,
        low_thresh: float,
        new_track_thresh: float,
        match_thresh: float,
        track_buffer: int,
    ) -> None:
        self.track_thresh = float(track_thresh)
        self.low_thresh = float(low_thresh)
        self.new_track_thresh = float(new_track_thresh)
        self.match_thresh = float(match_thresh)
        self.track_buffer = int(track_buffer)
        self.tracks: List[Track] = []
        self.next_id = 1

    def _new_track(self, detection: PersonDetection) -> Track:
        track = Track(
            track_id=self.next_id,
            bbox=detection.bbox.astype(np.float32, copy=True),
            score=float(detection.score),
            keypoints=detection.keypoints.copy(),
        )
        self.next_id += 1
        return track

    def update(self, detections: Sequence[PersonDetection]) -> List[Track]:
        high = [item for item in detections if item.score >= self.track_thresh]
        low = [
            item
            for item in detections
            if self.low_thresh <= item.score < self.track_thresh
        ]
        candidates = [track for track in self.tracks if track.missed <= self.track_buffer]

        first_matches, unmatched_tracks, unmatched_high = _greedy_assignment(
            _cost_matrix(candidates, high), self.match_thresh
        )
        matched_ids = set()
        for track_index, detection_index in first_matches:
            track = candidates[track_index]
            track.update(high[detection_index])
            matched_ids.add(track.track_id)

        remaining_tracks = [candidates[index] for index in unmatched_tracks]
        second_matches, _, _ = _greedy_assignment(
            _cost_matrix(remaining_tracks, low), min(self.match_thresh, 0.55)
        )
        for track_index, detection_index in second_matches:
            track = remaining_tracks[track_index]
            track.update(low[detection_index])
            matched_ids.add(track.track_id)

        for track in self.tracks:
            if track.track_id not in matched_ids:
                track.missed += 1
                track.age += 1
                track.bbox = track.predict()
                track.active = track.missed <= self.track_buffer

        for detection_index in unmatched_high:
            detection = high[detection_index]
            if detection.score >= self.new_track_thresh:
                self.tracks.append(self._new_track(detection))

        self.tracks = [track for track in self.tracks if track.missed <= self.track_buffer]
        return [track for track in self.tracks if track.active and track.missed == 0]
