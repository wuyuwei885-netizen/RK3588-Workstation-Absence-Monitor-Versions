from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from .database import Database
from .enrollment import align_face_5points
from .geometry import face_center_in_upper_body
from .models import FaceDetection, ModelHub
from .tracker import Track


@dataclass
class IdentityBinding:
    track_id: int
    employee_id: int
    employee_code: str
    employee_name: str
    similarity: float
    last_confirmed_monotonic: float
    last_recognized_at: str


class IdentityService:
    """
    员工身份与人体 Track 绑定。

    规则：
    - Track 持续存在时，即使暂时看不到人脸，绑定继续有效；
    - Track 消失后保留 binding_ttl_sec（本项目默认 5 秒）；
    - 旧绑定保留期内，新 Track 即使相似度更高也不能接管同一员工；
    - 旧绑定过期后，同一轮候选只保留相似度最高的新 Track；
    - 同一员工在任意时刻最多绑定一个 Track。
    """

    def __init__(
        self,
        *,
        database: Database,
        models: ModelHub,
        similarity_threshold: float,
        recognition_cooldown_sec: float,
        binding_ttl_sec: float,
    ) -> None:
        self.database = database
        self.models = models
        self.similarity_threshold = float(similarity_threshold)
        self.recognition_cooldown_sec = float(recognition_cooldown_sec)
        self.binding_ttl_sec = max(0.1, float(binding_ttl_sec))
        self._lock = threading.RLock()
        self._profiles: List[Dict] = []
        self._bindings: Dict[int, IdentityBinding] = {}
        self._last_attempt: Dict[int, float] = {}
        self._missing_since: Dict[int, float] = {}
        self.reload_profiles()

    def reload_profiles(self) -> None:
        with self._lock:
            self._profiles = self.database.load_face_profiles()

    def remove_employee(self, employee_id: int) -> None:
        with self._lock:
            self._profiles = [
                profile
                for profile in self._profiles
                if int(profile["employee_id"]) != int(employee_id)
            ]
            removed = [
                track_id
                for track_id, binding in self._bindings.items()
                if int(binding.employee_id) == int(employee_id)
            ]
            for track_id in removed:
                self._bindings.pop(track_id, None)
                self._missing_since.pop(track_id, None)

    @property
    def profile_count(self) -> int:
        with self._lock:
            return len(self._profiles)

    @property
    def binding_count(self) -> int:
        with self._lock:
            return len(self._bindings)

    def _expire(self, active_track_ids: Optional[set[int]] = None) -> None:
        now = time.monotonic()
        if active_track_ids is None:
            # 无活动 Track 信息时不推断丢失，只清理已经进入 missing 状态的绑定。
            expired = [
                track_id
                for track_id, missing_at in self._missing_since.items()
                if now - missing_at >= self.binding_ttl_sec
            ]
        else:
            expired = []
            for track_id in list(self._bindings):
                if track_id in active_track_ids:
                    self._missing_since.pop(track_id, None)
                    continue
                missing_at = self._missing_since.setdefault(track_id, now)
                if now - missing_at >= self.binding_ttl_sec:
                    expired.append(track_id)
        for track_id in expired:
            self._bindings.pop(track_id, None)
            self._missing_since.pop(track_id, None)
            self._last_attempt.pop(track_id, None)

    def bindings(self) -> Dict[int, IdentityBinding]:
        with self._lock:
            self._expire()
            return dict(self._bindings)

    def match_embedding(self, embedding: np.ndarray) -> Optional[Dict]:
        with self._lock:
            profiles = list(self._profiles)
        if not profiles:
            return None
        scores = [float(np.dot(embedding, profile["embedding_array"])) for profile in profiles]
        best_index = int(np.argmax(scores))
        best_score = scores[best_index]
        if best_score < self.similarity_threshold:
            return None
        result = dict(profiles[best_index])
        result["similarity"] = best_score
        return result

    @staticmethod
    def assign_faces_to_tracks(
        faces: Sequence[FaceDetection], tracks: Sequence[Track]
    ) -> List[Tuple[FaceDetection, Track]]:
        assignments: List[Tuple[FaceDetection, Track]] = []
        used_track_ids: set[int] = set()
        for face in sorted(faces, key=lambda item: item.score, reverse=True):
            candidates = [
                track
                for track in tracks
                if track.track_id not in used_track_ids
                and face_center_in_upper_body(face.bbox, track.bbox)
            ]
            if not candidates:
                continue
            face_center = np.asarray(
                [(face.bbox[0] + face.bbox[2]) / 2.0, (face.bbox[1] + face.bbox[3]) / 2.0],
                dtype=np.float32,
            )

            def distance(track: Track) -> float:
                x1, y1, x2, y2 = track.bbox
                expected = np.asarray([(x1 + x2) / 2.0, y1 + (y2 - y1) * 0.18], dtype=np.float32)
                return float(np.linalg.norm(face_center - expected))

            selected = min(candidates, key=distance)
            used_track_ids.add(selected.track_id)
            assignments.append((face, selected))
        return assignments

    def update(
        self,
        frame: np.ndarray,
        faces: Sequence[FaceDetection],
        tracks: Sequence[Track],
        max_faces: int = 4,
    ) -> Tuple[Dict[int, IdentityBinding], float]:
        recognizer = self.models.face_recognizer
        active_track_ids = {track.track_id for track in tracks}
        with self._lock:
            self._expire(active_track_ids)
        if recognizer is None:
            return self.bindings(), 0.0

        total_recognition_ms = 0.0
        now = time.monotonic()
        assignments = self.assign_faces_to_tracks(faces[:max_faces], tracks)
        candidates_by_employee: Dict[int, IdentityBinding] = {}

        for face, track in assignments:
            with self._lock:
                current_track_binding = self._bindings.get(track.track_id)
                last_attempt = self._last_attempt.get(track.track_id, 0.0)
            if current_track_binding and now - current_track_binding.last_confirmed_monotonic < self.recognition_cooldown_sec:
                continue
            if now - last_attempt < self.recognition_cooldown_sec:
                continue
            with self._lock:
                self._last_attempt[track.track_id] = now

            aligned = align_face_5points(
                frame,
                face.landmarks,
                recognizer.input_width,
                recognizer.input_height,
            )
            embedding, recognition_ms = recognizer.infer(aligned)
            total_recognition_ms += recognition_ms
            matched = self.match_embedding(embedding)
            if matched is None:
                continue

            employee_id = int(matched["employee_id"])
            recognized_at = datetime.now().astimezone().isoformat(timespec="seconds")
            candidate = IdentityBinding(
                track_id=track.track_id,
                employee_id=employee_id,
                employee_code=str(matched["employee_code"]),
                employee_name=str(matched["name"]),
                similarity=float(matched["similarity"]),
                last_confirmed_monotonic=now,
                last_recognized_at=recognized_at,
            )
            previous = candidates_by_employee.get(employee_id)
            if previous is None or candidate.similarity > previous.similarity:
                candidates_by_employee[employee_id] = candidate

        with self._lock:
            self._expire(active_track_ids)
            for employee_id, candidate in candidates_by_employee.items():
                existing_pair = next(
                    (
                        (track_id, binding)
                        for track_id, binding in self._bindings.items()
                        if int(binding.employee_id) == int(employee_id)
                    ),
                    None,
                )
                if existing_pair is not None:
                    old_track_id, old_binding = existing_pair
                    if old_track_id != candidate.track_id:
                        # 旧 Track 仍存在或仍在 5 秒保留期：旧绑定优先。
                        continue
                    # 同一 Track 的重新识别，只在相似度更高时更新显示分数；确认时间始终刷新。
                    if candidate.similarity < old_binding.similarity:
                        candidate.similarity = old_binding.similarity

                # 当前 Track 原来若绑定了另一个员工，识别确认后替换。
                self._bindings[candidate.track_id] = candidate
                self._missing_since.pop(candidate.track_id, None)

            # 最终防御：同一员工只保留一个绑定。若迁移数据存在重复，优先活动 Track，
            # 再优先最早已有绑定；这里不会用单帧高分抢占未过期旧绑定。
            employee_tracks: Dict[int, List[int]] = {}
            for track_id, binding in self._bindings.items():
                employee_tracks.setdefault(int(binding.employee_id), []).append(track_id)
            for employee_id, track_ids in employee_tracks.items():
                if len(track_ids) <= 1:
                    continue
                keep = next((track_id for track_id in track_ids if track_id in active_track_ids), track_ids[0])
                for track_id in track_ids:
                    if track_id != keep:
                        self._bindings.pop(track_id, None)
                        self._missing_since.pop(track_id, None)

            return dict(self._bindings), total_recognition_ms
