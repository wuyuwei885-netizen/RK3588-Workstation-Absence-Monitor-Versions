#!/usr/bin/env python3
from __future__ import annotations

import argparse
import platform
import shutil
import sys
from pathlib import Path

from workstation.camera import CameraManager
from workstation.config import load_config


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()
    config = load_config(args.config)

    print("=" * 72)
    print("Python:", sys.version.replace("\n", " "))
    print("Architecture:", platform.machine())
    print("v4l2-ctl:", shutil.which("v4l2-ctl"))

    import cv2
    import numpy

    print("OpenCV:", cv2.__version__)
    print("NumPy:", numpy.__version__)
    try:
        from rknnlite.api import RKNNLite

        print("RKNNLite: import OK")
    except Exception as exc:
        print("RKNNLite: FAIL", exc)

    print("\nCameras:")
    for item in CameraManager.list_devices():
        marker = "*" if item["device"] == config.camera["device"] else " "
        print(marker, item["device"], item["label"])

    print("\nModels:")
    for name, item in config.models.items():
        path = Path(item["path"])
        print(
            f"{name:18}",
            path,
            "OK" if path.is_file() else "MISSING",
            path.stat().st_size if path.is_file() else 0,
        )
    print("=" * 72)


if __name__ == "__main__":
    main()
