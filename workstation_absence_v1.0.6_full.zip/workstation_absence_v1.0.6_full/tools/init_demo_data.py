#!/usr/bin/env python3
from __future__ import annotations

import argparse

from workstation.config import load_config
from workstation.database import Database


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.json")
    args = parser.parse_args()
    config = load_config(args.config)
    database = Database(config.app["database"])
    if not database.list_workstations():
        workstation_id = database.create_workstation(
            name="工作台01",
            camera_device=config.camera["device"],
            away_threshold_sec=int(config.presence["default_away_threshold_sec"]),
            grace_sec=int(config.presence["default_grace_sec"]),
            return_confirm_sec=int(config.presence["default_return_confirm_sec"]),
        )
        print("创建演示工作台：", workstation_id)
    else:
        print("已有工作台，不重复创建")


if __name__ == "__main__":
    main()
