worker19 v1.9.1 离线量化评测数据说明

1. 此目录不再保存网页手填的量化指标，也不附带写死的 mAP/P/R/F1。
2. NPU 页面会根据当前盗窃模型路径，自动寻找板端真实评测文件：
   /root/rk3588_yolo11_shoplifting/quant_eval_fast/run1_best_i8_calib300.json
   /root/rk3588_yolo11_shoplifting/quant_eval/run1_best_i8_calib300.json
   /root/rk3588_yolo11_shoplifting/models/run1_best_i8_calib300.json
3. 如果这些文件不存在，页面显示“未找到真实离线评测文件”，不会补默认数值。
4. 校准集(calibration dataset)仅在 ONNX -> INT8 RKNN 的 PTQ 转换阶段用于统计激活范围/量化参数。
5. 验证集(validation/evaluation dataset)仅用于离线计算 mAP/P/R/F1，不参与实时摄像头推理。
