# worker19 v1.9.1 — RK3588 双摄人员异常 + 盗窃检测

## 版本目标

v1.9.1 在 1.8 双摄工作台系统基础上整合 YOLO11 Shoplifting INT8(calib300)，并针对本轮实际问题做三项修正：

1. **单网页端口**：`/monitor`、`/history`、`/npu`、`/control` 全部由主 FastAPI 服务提供，默认端口 `8090`。不再启动独立 8091 控制服务。
2. **RKNN 数据不写死**：Python RKNN Lite 包版本、当前进程实际加载的 `librknnrt.so` 路径/版本、内核驱动版本、NPU 频率/负载均由板端实时探测。读不到就显示“未读取”，不会填默认版本。
3. **实时预览低延迟**：Pose/Core0 与 Shoplifting/Core1 均改为 latest-only 异步推理；JPEG 独立线程；旧任务覆盖；V4L2 buffer=2；预览优先于 AI 调度；状态 JSON 降频刷新，避免网页看到积压旧帧。

## NPU 分配

| Core | 模型 | 作用 |
|---|---|---|
| Core0 | YOLOv8-Pose INT8 | 人体、关键点、ByteTrack、离岗、摔倒 |
| Core1 | YOLO11-Shoplifting INT8 calib300 | 盗窃检测 |
| Core2 | RetinaFace INT8 + W600K-MBF INT8 | 人脸检测与身份识别 |

盗窃模型默认路径：

```text
/root/rk3588_yolo11_shoplifting/models/run1_best_i8_calib300.rknn
```

## 网页地址

假设板卡 IP 为 `192.168.10.66`，默认主端口为 `8090`：

```text
主页面       http://192.168.10.66:8090/
实时监控     http://192.168.10.66:8090/monitor
历史记录     http://192.168.10.66:8090/history
NPU真实指标  http://192.168.10.66:8090/npu
设备控制     http://192.168.10.66:8090/control
真实JSON     http://192.168.10.66:8090/api/npu-metrics
```

手机和电脑访问的是**同一个端口**。主服务监听 `0.0.0.0`，因此同一局域网设备可通过板卡真实 IP 访问。

## 一次性安装

ZIP 放到 `/root/workstation/worker19_v1.9.1_complete.zip` 后执行：

```bash
cd /root/workstation && unzip -o worker19_v1.9.1_complete.zip && source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker19_v1.9.1 && export PYTHONPATH=/root/workstation/worker19_v1.9.1 && python tools/install_v191_safe.py
```

安装器默认正式部署到：

```text
/root/workstation/worker19
```

安装器会：

- 备份已有 worker19 代码和数据库；
- 停止并取消旧 `workstation-control` 分离服务的开机链接；
- 只安装一个 `/etc/init.d/workstation-absence`；
- 保留现有 `rknn310` 环境；
- 不执行 `pip/apt/curl/wget`；
- 不替换 `/usr/lib/librknnrt.so`；
- 检查 `/api/status`、`/control`、`/api/npu-metrics` 是否都在同一主端口返回 HTTP 200。

## 手工启动

```bash
source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker19 && export PYTHONPATH=/root/workstation/worker19 && python -u app.py --config config.json
```

SysV 服务：

```bash
/etc/init.d/workstation-absence restart
/etc/init.d/workstation-absence status
tail -f /var/log/workstation-absence.log
```

## 部署前检查

```bash
source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker19 && export PYTHONPATH=/root/workstation/worker19 && python tools/check_v191.py
```

模型完整性：

```bash
ls -lh /root/yolov8_rk3588/code/model/yolov8n-pose-int8.rknn /root/rk3588_yolo11_shoplifting/models/run1_best_i8_calib300.rknn /root/yolov8_rk3588/code/model/RetinaFace_mobile320-int8.rknn /root/yolov8_rk3588/code/model/w600k_mbf-int8-calib500.rknn
```

## “2.0.0b0”版本号现在如何处理

v1.9.0 曾把 Runtime 版本写在配置文件中，因此网页可能显示与实际运行库不一致的值。v1.9.1 删除该配置来源。

现在 `/api/npu-metrics` 的版本字段来自：

- `toolkit_lite_version`：当前 Python 环境安装包元数据；
- `runtime_library`：当前 worker19 进程 `/proc/self/maps` 中实际 mmap 的 `librknnrt.so`；
- `runtime_version_observed`：对上述**实际已加载库文件**读取 `librknnrt version:`；
- `driver_version_observed`：从 RKNN 驱动 sysfs/debugfs 节点读取；
- `npu_frequency_hz`、`npu_load_raw`：从内核节点读取。

如果板端真实加载的库就是 `2.0.0b0`，页面仍会显示 `2.0.0b0`，同时显示对应库路径；这时它是实测值，不是写死值。如果无法读取，则显示“未读取”。

## 离线量化评测文件有什么用

NPU 页底部的“离线量化评测文件”**不参与实时摄像头推理**。

系统自动寻找当前 calib300 模型对应的实际 JSON，例如：

```text
/root/rk3588_yolo11_shoplifting/quant_eval_fast/run1_best_i8_calib300.json
```

它用于回答：

- 100/200/300/500/1000 张校准集哪个量化精度更好；
- mAP50、mAP50-95、Precision、Recall、F1 是否有损失；
- calib300 是否值得作为最终部署模型。

两个数据概念必须分开：

- **PTQ calibration dataset**：ONNX → INT8 RKNN 转换时统计激活范围、scale/zero-point；转换结束后不随模型部署到摄像头实时推理。
- **validation/evaluation dataset**：离线计算 mAP/P/R/F1，只做验收，不进入 worker19 实时循环。

如果实际评测 JSON 不存在，网页显示 unavailable，不使用内置默认指标。

## 低延迟实现

实时链路：

```text
V4L2 NV12 -> BGR -> FrameSlot(latest only)
                         |-> Preview first -> JPEG latest-only -> MJPEG
                         |-> Pose Core0 latest-only async
                         |-> Shoplifting Core1 latest-only async
                         `-> RetinaFace/W600K Core2 low-rate
```

关键参数位于 `config.json`：

```json
{
  "camera": {"fps": 30, "buffers": 2},
  "runtime": {
    "pose_fps": 12.0,
    "theft_fps": 6.0,
    "face_fps": 3.0,
    "preview_fps": 12.0,
    "raw_preview_fps": 6.0,
    "preview_width": 960,
    "jpeg_quality": 68,
    "business_fps": 10.0,
    "status_fps": 5.0
  }
}
```

`/npu` 页面会显示：

- Preview frame age；
- Pose task frame age / Core0 lock wait / dropped old tasks；
- Theft task frame age / Core1 lock wait / dropped old tasks；
- JPEG 编码时间；
- 每个模型真实 `RKNNLite.inference()` Avg/P50/P95；
- YOLO11 Pre/NPU/Post/Pipeline。

这些指标用于区分延迟到底来自摄像头、NPU、CPU 后处理、模型锁还是 JPEG/Web。

## 单独测 YOLO11

停止主服务避免 Core1 被抢占：

```bash
/etc/init.d/workstation-absence stop
```

然后：

```bash
source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker19 && export PYTHONPATH=/root/workstation/worker19 && python tools/benchmark_theft_npu.py --loops 100 --warmup 10
```

输出会分别给出 `PRE / NPU inference / POST / PIPELINE` 的 Avg/P50/P95。

## 验证实时延迟

浏览器打开 `/npu`，优先观察：

```text
预览帧龄
Pose任务帧龄
Pose Core0锁等待
盗窃任务帧龄
Core1锁等待
丢弃旧Pose任务
丢弃旧盗窃任务
```

latest-only 架构允许“丢旧帧”，这是实时视觉系统的正常策略：宁可跳过过期帧，也不要让网页不断显示几秒前的画面。
