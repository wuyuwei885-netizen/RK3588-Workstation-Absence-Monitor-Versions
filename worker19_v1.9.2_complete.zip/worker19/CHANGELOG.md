# v1.9.2

- 修复 SHOPLIFTING 告警被前端默认分支错误显示为“空岗告警”。
- 空岗告警现在只接受 `type=absence_alert`，不再把未知事件当作空岗。
- 修复盗窃告警中的 `null null / undefined` 展示。
- WebSocket 新连接不再重放 AlertBus 中缓存的旧告警，刷新页面不会重复弹旧事件。
- 未识别事件统一显示为“系统告警”，避免业务类型误判。

# CHANGELOG

## v1.9.1

- 设备控制合并到主 FastAPI：`/control` 与 `/monitor`、`/npu` 使用同一端口；删除包内独立 `control_app.py` / `workstation-control` 服务。
- 安装器会停止并取消旧分离控制服务开机启动，避免手机仍被导向第二端口。
- 删除配置中的 Runtime/Driver/Toolkit 固定版本；NPU 页面只显示当前进程和内核实际探测结果。
- 新增 `workstation/system_metrics.py`：读取 Python RKNN Lite 包、当前进程已加载 `librknnrt.so`、驱动、NPU频率与负载。
- 删除网页手工填写/内置 `data/model_evaluation.json`；新增 `workstation/evaluation.py` 自动读取当前模型真实离线评测 JSON。
- Pose Core0 改为 latest-only 异步推理，主 Runtime 不再等待 Pose inference。
- YOLO11 Core1 改为 latest-only 异步推理，主 Runtime 不等待盗窃 pipeline。
- JPEG 编码独立线程；annotated 画面优先，raw 预览降频；预览帧龄按 annotated JPEG 真正发布时刻计算。
- 主循环先提交预览再调度 AI，减少“模型快但网页画面旧”的体验延迟。
- V4L2 buffer 默认 2；30FPS 采集；12FPS annotated preview；6FPS raw preview。
- 状态大 JSON 降到 5FPS 内部刷新，WebSocket 2Hz 推送，减少双摄 CPU 序列化负载。
- `/npu` 新增 Preview/Pose/Theft 帧龄、模型锁等待、旧任务丢弃数，用于定位实时延迟来源。
- calib300 盗窃模型继续使用 Core1：`/root/rk3588_yolo11_shoplifting/models/run1_best_i8_calib300.rknn`。
- 新增 `tools/install_v191_safe.py`、`tools/check_v191.py`。
- 自动测试：29 tests passed。

## v1.9.0

- 在 1.8 双摄业务基础上加入 YOLO11 Shoplifting INT8 calib300。
- 加入盗窃时间窗口状态机和历史事件。
- 初版 NPU 数据页面。

## v1.8.0

- 双摄像头 MultiCameraManager / MultiCameraRuntime。
- 每路独立 ByteTrack / Identity / Presence / Fall 状态。
- 工作台按 camera_device 隔离。
