# v1.9 模型路径

本代码包不重复打包 RKNN 二进制模型，默认直接使用板端现有模型：

- Pose / Core0: `/root/yolov8_rk3588/code/model/yolov8n-pose-int8.rknn`
- YOLO11 Shoplifting / Core1: `/root/rk3588_yolo11_shoplifting/models/run1_best_i8_calib300.rknn`
- RetinaFace / Core2: `/root/yolov8_rk3588/code/model/RetinaFace_mobile320-int8.rknn`
- W600K-MBF / Core2: `/root/yolov8_rk3588/code/model/w600k_mbf-int8-calib500.rknn`

安装前检查：

```bash
ls -lh /root/yolov8_rk3588/code/model/yolov8n-pose-int8.rknn /root/rk3588_yolo11_shoplifting/models/run1_best_i8_calib300.rknn /root/yolov8_rk3588/code/model/RetinaFace_mobile320-int8.rknn /root/yolov8_rk3588/code/model/w600k_mbf-int8-calib500.rknn
```

若实际路径不同，只改 `config.json -> models.*.path`，不要改 Python 源码。
