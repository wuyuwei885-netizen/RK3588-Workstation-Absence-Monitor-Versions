from __future__ import annotations

import copy
import json
import os
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

import numpy as np


VALID_MODES = {"single", "per_employee", "minimum_staff"}


def now_iso(timestamp: Optional[float] = None) -> str:
    if timestamp is None:
        return datetime.now().astimezone().isoformat(timespec="seconds")
    return datetime.fromtimestamp(float(timestamp)).astimezone().isoformat(timespec="seconds")


def parse_iso(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    return datetime.fromisoformat(str(value))


def normalize_embedding(embedding: np.ndarray | Sequence[float]) -> np.ndarray:
    array = np.asarray(embedding, dtype=np.float32).reshape(-1)
    norm = float(np.linalg.norm(array))
    return array / norm if norm > 1e-12 else array


def duration_seconds(start_iso: Optional[str], end_iso: Optional[str]) -> int:
    start = parse_iso(start_iso)
    end = parse_iso(end_iso)
    if start is None or end is None:
        return 0
    return max(0, int(round((end - start).total_seconds())))


class Database:
    """Buildroot 友好的 JSON 数据库，支持批量排班、三种模式和请假审批。"""

    FORMAT_VERSION = 2
    RUNTIME_FLUSH_INTERVAL_SEC = 5.0

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._last_runtime_flush = 0.0
        self._data = self._load_or_create()

    @staticmethod
    def _empty_data() -> Dict[str, Any]:
        return {
            "format_version": Database.FORMAT_VERSION,
            "counters": {
                "employees": 0,
                "face_samples": 0,
                "workstations": 0,
                "shift_rounds": 0,
                "shifts": 0,
                "absence_events": 0,
            },
            "employees": [],
            "face_samples": [],
            "face_profiles": {},
            "workstations": [],
            "shift_rounds": [],
            "shifts": [],
            "absence_events": [],
            "runtime_state": {},
            "settings": {},
        }

    def _load_or_create(self) -> Dict[str, Any]:
        if not self.path.exists() or self.path.stat().st_size == 0:
            data = self._empty_data()
            self._atomic_write(data)
            return data
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RuntimeError(
                f"数据文件不是有效JSON：{self.path}。如果这是旧SQLite文件，请先备份后改名。"
            ) from exc
        data = self._migrate(data)
        self._atomic_write(data)
        return data

    def _migrate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        template = self._empty_data()
        for key, value in template.items():
            data.setdefault(key, copy.deepcopy(value))
        counters = data.setdefault("counters", {})
        for key in template["counters"]:
            counters.setdefault(key, 0)

        # 旧版 ACTIVE 班次在升级时自动归入一个活动轮次，历史 CLOSED 记录不重算。
        active_by_ws: Dict[int, List[Dict[str, Any]]] = {}
        for shift in data.get("shifts", []):
            shift.setdefault("round_id", None)
            shift.setdefault("joined_at", shift.get("start_at"))
            if shift.get("status") == "ACTIVE":
                active_by_ws.setdefault(int(shift["workstation_id"]), []).append(shift)

        for workstation_id, shifts in active_by_ws.items():
            existing_round_id = next(
                (int(item["round_id"]) for item in shifts if item.get("round_id")),
                None,
            )
            if existing_round_id is not None:
                continue
            workstation = self._find(data.get("workstations", []), workstation_id) or {}
            counters["shift_rounds"] = int(counters.get("shift_rounds", 0)) + 1
            round_id = int(counters["shift_rounds"])
            mode = "single" if len(shifts) == 1 else "per_employee"
            start_at = min(str(item.get("start_at") or now_iso()) for item in shifts)
            data["shift_rounds"].append(
                {
                    "id": round_id,
                    "workstation_id": workstation_id,
                    "mode": mode,
                    "minimum_staff": 1,
                    "first_arrival_wait_sec": 600,
                    "grace_sec": int(workstation.get("grace_sec", 5)),
                    "away_threshold_sec": int(workstation.get("away_threshold_sec", 180)),
                    "return_confirm_sec": int(workstation.get("return_confirm_sec", 2)),
                    "start_at": start_at,
                    "end_at": None,
                    "status": "ACTIVE",
                    "record_version": "v1.0.6-migrated-active",
                    "created_at": now_iso(),
                    "updated_at": now_iso(),
                }
            )
            for shift in shifts:
                shift["round_id"] = round_id

        for round_item in data.get("shift_rounds", []):
            round_item.setdefault("mode", "single")
            round_item.setdefault("minimum_staff", 1)
            round_item.setdefault("first_arrival_wait_sec", 600)
            round_item.setdefault("grace_sec", 5)
            round_item.setdefault("away_threshold_sec", 180)
            round_item.setdefault("return_confirm_sec", 2)
            round_item.setdefault("record_version", "v1.0.6")
            round_item.setdefault("created_at", round_item.get("start_at", now_iso()))
            round_item.setdefault("updated_at", now_iso())

        # 旧 runtime_state 使用纯 shift_id 键，升级为 shift:<id>。
        runtime = data.get("runtime_state", {})
        migrated_runtime: Dict[str, Dict[str, Any]] = {}
        for key, value in runtime.items():
            text_key = str(key)
            new_key = text_key if ":" in text_key else f"shift:{text_key}"
            item = copy.deepcopy(value)
            item.setdefault("scope_key", new_key)
            item.setdefault("last_tick_at", item.get("updated_at"))
            migrated_runtime[new_key] = item
        data["runtime_state"] = migrated_runtime

        for event in data.get("absence_events", []):
            shift_id = event.get("shift_id")
            shift = self._find(data.get("shifts", []), int(shift_id)) if shift_id else None
            event.setdefault("record_version", "legacy")
            event.setdefault("event_scope", "PERSONAL")
            event.setdefault("event_type", "ABSENCE")
            event.setdefault("scope_key", f"shift:{shift_id}" if shift_id else "legacy")
            event.setdefault("incident_id", None)
            event.setdefault("round_id", shift.get("round_id") if shift else None)
            event.setdefault("employee_id", None)
            event.setdefault("present_count", None)
            event.setdefault("required_count", None)
            event.setdefault("closed_reason", None)
            event.setdefault("leave_status", "NONE")
            event.setdefault("leave_note", "")
            event.setdefault("leave_applied_at", None)
            event.setdefault("leave_reviewed_at", None)
            event.setdefault("leave_audit", [])
            event.setdefault("archived", 0)
            event.setdefault("metadata", {})
            event.setdefault("updated_at", event.get("created_at", now_iso()))

        data["format_version"] = self.FORMAT_VERSION
        return data

    def _atomic_write(self, data: Optional[Dict[str, Any]] = None) -> None:
        payload = self._data if data is None else data
        temporary = self.path.with_suffix(self.path.suffix + ".tmp")
        serialized = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        with temporary.open("w", encoding="utf-8") as file:
            file.write(serialized)
            file.flush()
            os.fsync(file.fileno())
        os.replace(temporary, self.path)

    def _next_id(self, table: str) -> int:
        self._data["counters"][table] = int(self._data["counters"].get(table, 0)) + 1
        return int(self._data["counters"][table])

    @staticmethod
    def _find(items: Iterable[Dict[str, Any]], item_id: int) -> Optional[Dict[str, Any]]:
        return next((item for item in items if int(item["id"]) == int(item_id)), None)

    def _active_shift_for_employee(self, employee_id: int) -> Optional[Dict[str, Any]]:
        return next(
            (
                item
                for item in self._data["shifts"]
                if item.get("status") == "ACTIVE"
                and int(item["employee_id"]) == int(employee_id)
            ),
            None,
        )

    def employee_has_active_shift(self, employee_id: int) -> bool:
        with self._lock:
            return self._active_shift_for_employee(employee_id) is not None

    def workstation_has_active_round(self, workstation_id: int) -> bool:
        with self._lock:
            return self._active_round_raw(workstation_id) is not None

    # ---------- Employees ----------
    def create_employee(self, employee_code: str, name: str, department: str = "", note: str = "") -> int:
        employee_code, name = employee_code.strip(), name.strip()
        if not employee_code or not name:
            raise ValueError("员工ID和姓名不能为空")
        with self._lock:
            if any(item["employee_code"] == employee_code for item in self._data["employees"]):
                raise ValueError(f"员工ID已存在：{employee_code}")
            timestamp = now_iso()
            employee_id = self._next_id("employees")
            self._data["employees"].append(
                {
                    "id": employee_id,
                    "employee_code": employee_code,
                    "name": name,
                    "department": department.strip(),
                    "note": note.strip(),
                    "enabled": 1,
                    "enrolled": 0,
                    "created_at": timestamp,
                    "updated_at": timestamp,
                }
            )
            self._atomic_write()
            return employee_id

    def update_employee(self, employee_id: int, *, employee_code: str, name: str, department: str, note: str) -> None:
        employee_code, name = employee_code.strip(), name.strip()
        if not employee_code or not name:
            raise ValueError("员工ID和姓名不能为空")
        with self._lock:
            employee = self._find(self._data["employees"], employee_id)
            if employee is None:
                raise ValueError("员工不存在")
            if self._active_shift_for_employee(employee_id) and employee_code != employee["employee_code"]:
                raise ValueError("员工正在上班，不能修改员工ID；请先让所在工作台全部下班")
            if any(
                item["employee_code"] == employee_code and int(item["id"]) != int(employee_id)
                for item in self._data["employees"]
            ):
                raise ValueError(f"员工ID已存在：{employee_code}")
            employee.update(
                {
                    "employee_code": employee_code,
                    "name": name,
                    "department": department.strip(),
                    "note": note.strip(),
                    "updated_at": now_iso(),
                }
            )
            self._atomic_write()

    def delete_employee(self, employee_id: int) -> Dict[str, Any]:
        with self._lock:
            employee = self._find(self._data["employees"], employee_id)
            if employee is None:
                raise ValueError("员工不存在")
            if self._active_shift_for_employee(employee_id):
                raise ValueError("员工正在上班，不能删除；请先让所在工作台全部下班")
            samples = [copy.deepcopy(x) for x in self._data["face_samples"] if int(x["employee_id"]) == int(employee_id)]
            shifts = [copy.deepcopy(x) for x in self._data["shifts"] if int(x["employee_id"]) == int(employee_id)]
            shift_ids = {int(x["id"]) for x in shifts}
            events = [
                copy.deepcopy(x)
                for x in self._data["absence_events"]
                if (x.get("employee_id") is not None and int(x["employee_id"]) == int(employee_id))
                or (x.get("shift_id") is not None and int(x["shift_id"]) in shift_ids)
            ]
            self._data["employees"] = [x for x in self._data["employees"] if int(x["id"]) != int(employee_id)]
            self._data["face_samples"] = [x for x in self._data["face_samples"] if int(x["employee_id"]) != int(employee_id)]
            self._data["face_profiles"].pop(str(employee_id), None)
            self._data["shifts"] = [x for x in self._data["shifts"] if int(x["employee_id"]) != int(employee_id)]
            self._data["absence_events"] = [
                x
                for x in self._data["absence_events"]
                if not (
                    (x.get("employee_id") is not None and int(x["employee_id"]) == int(employee_id))
                    or (x.get("shift_id") is not None and int(x["shift_id"]) in shift_ids)
                )
            ]
            for shift_id in shift_ids:
                self._data["runtime_state"].pop(f"shift:{shift_id}", None)
            self._atomic_write()
            return {"employee": copy.deepcopy(employee), "samples": samples, "shifts": shifts, "events": events}

    def set_employee_enabled(self, employee_id: int, enabled: bool) -> None:
        with self._lock:
            employee = self._find(self._data["employees"], employee_id)
            if employee is None:
                raise ValueError("员工不存在")
            if not enabled and self._active_shift_for_employee(employee_id):
                raise ValueError("员工正在上班，不能停用；请先让所在工作台全部下班")
            employee["enabled"] = 1 if enabled else 0
            employee["updated_at"] = now_iso()
            self._atomic_write()

    def set_employee_enrolled(self, employee_id: int, enrolled: bool) -> None:
        with self._lock:
            employee = self._find(self._data["employees"], employee_id)
            if employee is None:
                raise ValueError("员工不存在")
            if not enrolled and self._active_shift_for_employee(employee_id):
                raise ValueError("员工正在上班，不能清空或重新录入人脸；请先全部下班")
            employee["enrolled"] = 1 if enrolled else 0
            employee["updated_at"] = now_iso()
            self._atomic_write()

    def get_employee(self, employee_id: int) -> Optional[Dict[str, Any]]:
        with self._lock:
            item = self._find(self._data["employees"], employee_id)
            return copy.deepcopy(item) if item else None

    def list_employees(self, include_disabled: bool = True) -> List[Dict[str, Any]]:
        with self._lock:
            result = []
            for employee in self._data["employees"]:
                if not include_disabled and not employee["enabled"]:
                    continue
                item = copy.deepcopy(employee)
                profile = self._data["face_profiles"].get(str(employee["id"]))
                item["profile_sample_count"] = int(profile["sample_count"]) if profile else 0
                item["profile_quality_score"] = float(profile["quality_score"]) if profile else 0.0
                item["profile_updated_at"] = profile["updated_at"] if profile else None
                active = self._active_shift_for_employee(int(employee["id"]))
                item["active_shift_id"] = int(active["id"]) if active else None
                item["active_workstation_id"] = int(active["workstation_id"]) if active else None
                result.append(item)
            return sorted(result, key=lambda x: x["employee_code"])

    # ---------- Face samples / profiles ----------
    def add_face_sample(
        self,
        *,
        employee_id: int,
        slot_label: str,
        source_type: str,
        image_path: str,
        aligned_image_path: str,
        embedding: np.ndarray,
        quality: Dict[str, Any],
        replace_slot: bool = True,
    ) -> int:
        vector = normalize_embedding(embedding)
        with self._lock:
            if self._find(self._data["employees"], employee_id) is None:
                raise ValueError("员工不存在")
            if self._active_shift_for_employee(employee_id):
                raise ValueError("员工正在上班，不能修改人脸数据；请先全部下班")
            if replace_slot:
                self._data["face_samples"] = [
                    item
                    for item in self._data["face_samples"]
                    if not (int(item["employee_id"]) == int(employee_id) and item["slot_label"] == slot_label)
                ]
            sample_id = self._next_id("face_samples")
            self._data["face_samples"].append(
                {
                    "id": sample_id,
                    "employee_id": int(employee_id),
                    "slot_label": slot_label,
                    "source_type": source_type,
                    "image_path": image_path,
                    "aligned_image_path": aligned_image_path,
                    "embedding": vector.astype(float).tolist(),
                    "embedding_dim": int(vector.size),
                    "quality": copy.deepcopy(quality),
                    "created_at": now_iso(),
                }
            )
            self._atomic_write()
            return sample_id

    def list_face_samples(self, employee_id: int, include_embedding: bool = False) -> List[Dict[str, Any]]:
        with self._lock:
            result = []
            for sample in sorted(self._data["face_samples"], key=lambda x: int(x["id"])):
                if int(sample["employee_id"]) != int(employee_id):
                    continue
                item = copy.deepcopy(sample)
                embedding = item.pop("embedding")
                if include_embedding:
                    item["embedding_array"] = normalize_embedding(embedding)
                result.append(item)
            return result

    def delete_face_sample(self, sample_id: int) -> Optional[Dict[str, Any]]:
        with self._lock:
            selected = self._find(self._data["face_samples"], sample_id)
            if selected is None:
                return None
            if self._active_shift_for_employee(int(selected["employee_id"])):
                raise ValueError("员工正在上班，不能删除人脸照片；请先全部下班")
            self._data["face_samples"] = [x for x in self._data["face_samples"] if int(x["id"]) != int(sample_id)]
            self._atomic_write()
            result = copy.deepcopy(selected)
            result.pop("embedding", None)
            return result

    def save_face_profile(self, employee_id: int, embedding: np.ndarray, sample_count: int, quality_score: float) -> None:
        vector = normalize_embedding(embedding)
        with self._lock:
            if self._find(self._data["employees"], employee_id) is None:
                raise ValueError("员工不存在")
            if self._active_shift_for_employee(employee_id):
                raise ValueError("员工正在上班，不能重新生成人脸特征；请先全部下班")
            self._data["face_profiles"][str(employee_id)] = {
                "employee_id": int(employee_id),
                "embedding": vector.astype(float).tolist(),
                "embedding_dim": int(vector.size),
                "sample_count": int(sample_count),
                "quality_score": float(quality_score),
                "updated_at": now_iso(),
            }
            employee = self._find(self._data["employees"], employee_id)
            employee["enrolled"] = 1
            employee["updated_at"] = now_iso()
            self._atomic_write()

    def load_face_profiles(self) -> List[Dict[str, Any]]:
        with self._lock:
            result = []
            for key, profile in self._data["face_profiles"].items():
                employee = self._find(self._data["employees"], int(key))
                if employee is None or not employee["enabled"] or not employee["enrolled"]:
                    continue
                item = copy.deepcopy(profile)
                item["employee_code"] = employee["employee_code"]
                item["name"] = employee["name"]
                item["embedding_array"] = normalize_embedding(item.pop("embedding"))
                result.append(item)
            return result

    # ---------- Workstations ----------
    def create_workstation(
        self,
        *,
        name: str,
        camera_device: str,
        away_threshold_sec: int,
        grace_sec: int,
        return_confirm_sec: int,
    ) -> int:
        name = name.strip()
        if not name:
            raise ValueError("工作台名称不能为空")
        with self._lock:
            if any(item["name"] == name for item in self._data["workstations"]):
                raise ValueError(f"工作台名称已存在：{name}")
            timestamp = now_iso()
            workstation_id = self._next_id("workstations")
            self._data["workstations"].append(
                {
                    "id": workstation_id,
                    "name": name,
                    "camera_device": str(camera_device),
                    "roi": [],
                    "away_threshold_sec": int(away_threshold_sec),
                    "grace_sec": int(grace_sec),
                    "return_confirm_sec": int(return_confirm_sec),
                    "enabled": 1,
                    "created_at": timestamp,
                    "updated_at": timestamp,
                }
            )
            self._atomic_write()
            return workstation_id

    def _require_workstation_editable(self, workstation_id: int) -> Dict[str, Any]:
        workstation = self._find(self._data["workstations"], workstation_id)
        if workstation is None:
            raise ValueError("工作台不存在")
        if self._active_round_raw(workstation_id):
            raise ValueError("工作台存在活动排班，名称、摄像头、ROI和参数均已锁定；请先全部下班")
        return workstation

    def clear_workstation_roi(self, workstation_id: int) -> None:
        with self._lock:
            workstation = self._require_workstation_editable(workstation_id)
            workstation["roi"] = []
            workstation["updated_at"] = now_iso()
            self._atomic_write()

    def delete_workstation(self, workstation_id: int) -> Dict[str, Any]:
        with self._lock:
            workstation = self._require_workstation_editable(workstation_id)
            shifts = [copy.deepcopy(x) for x in self._data["shifts"] if int(x["workstation_id"]) == int(workstation_id)]
            shift_ids = {int(x["id"]) for x in shifts}
            round_ids = {int(x["round_id"]) for x in shifts if x.get("round_id") is not None}
            events = [
                copy.deepcopy(x)
                for x in self._data["absence_events"]
                if int(x["workstation_id"]) == int(workstation_id)
                or (x.get("shift_id") is not None and int(x["shift_id"]) in shift_ids)
            ]
            self._data["workstations"] = [x for x in self._data["workstations"] if int(x["id"]) != int(workstation_id)]
            self._data["shifts"] = [x for x in self._data["shifts"] if int(x["workstation_id"]) != int(workstation_id)]
            self._data["shift_rounds"] = [x for x in self._data["shift_rounds"] if int(x["workstation_id"]) != int(workstation_id)]
            self._data["absence_events"] = [x for x in self._data["absence_events"] if int(x["workstation_id"]) != int(workstation_id)]
            for shift_id in shift_ids:
                self._data["runtime_state"].pop(f"shift:{shift_id}", None)
            for round_id in round_ids:
                self._data["runtime_state"].pop(f"round:{round_id}", None)
            self._atomic_write()
            return {"workstation": copy.deepcopy(workstation), "shifts": shifts, "events": events}

    def update_workstation(
        self,
        workstation_id: int,
        *,
        name: str,
        camera_device: str,
        away_threshold_sec: int,
        grace_sec: int,
        return_confirm_sec: int,
        enabled: bool,
    ) -> None:
        name = name.strip()
        if not name:
            raise ValueError("工作台名称不能为空")
        with self._lock:
            workstation = self._require_workstation_editable(workstation_id)
            if any(x["name"] == name and int(x["id"]) != int(workstation_id) for x in self._data["workstations"]):
                raise ValueError(f"工作台名称已存在：{name}")
            workstation.update(
                {
                    "name": name,
                    "camera_device": str(camera_device),
                    "away_threshold_sec": int(away_threshold_sec),
                    "grace_sec": int(grace_sec),
                    "return_confirm_sec": int(return_confirm_sec),
                    "enabled": 1 if enabled else 0,
                    "updated_at": now_iso(),
                }
            )
            self._atomic_write()

    def update_workstation_roi(self, workstation_id: int, roi: Sequence[Sequence[float]]) -> None:
        with self._lock:
            workstation = self._require_workstation_editable(workstation_id)
            workstation["roi"] = [[float(x), float(y)] for x, y in roi]
            workstation["updated_at"] = now_iso()
            self._atomic_write()

    def get_workstation(self, workstation_id: int) -> Optional[Dict[str, Any]]:
        with self._lock:
            item = self._find(self._data["workstations"], workstation_id)
            return copy.deepcopy(item) if item else None

    def list_workstations(self, include_disabled: bool = True) -> List[Dict[str, Any]]:
        with self._lock:
            result = []
            for item in self._data["workstations"]:
                if not include_disabled and not item["enabled"]:
                    continue
                row = copy.deepcopy(item)
                active_round = self._active_round_raw(int(item["id"]))
                row["active_round_id"] = int(active_round["id"]) if active_round else None
                result.append(row)
            return sorted(result, key=lambda x: int(x["id"]))

    # ---------- Shift rounds / shifts ----------
    def _active_round_raw(self, workstation_id: int) -> Optional[Dict[str, Any]]:
        return next(
            (
                item
                for item in self._data["shift_rounds"]
                if item.get("status") == "ACTIVE"
                and int(item["workstation_id"]) == int(workstation_id)
            ),
            None,
        )

    @staticmethod
    def _validate_round_params(
        mode: str,
        minimum_staff: int,
        first_arrival_wait_sec: int,
        grace_sec: int,
        away_threshold_sec: int,
        return_confirm_sec: int,
    ) -> Dict[str, Any]:
        mode = str(mode).strip().lower()
        if mode not in VALID_MODES:
            raise ValueError("排班模式必须为 single、per_employee 或 minimum_staff")
        minimum_staff = int(minimum_staff)
        first_arrival_wait_sec = int(first_arrival_wait_sec)
        grace_sec = int(grace_sec)
        away_threshold_sec = int(away_threshold_sec)
        return_confirm_sec = int(return_confirm_sec)
        if not 1 <= minimum_staff <= 20:
            raise ValueError("最低在岗人数必须为 1~20")
        if not 1 <= first_arrival_wait_sec <= 86400:
            raise ValueError("首次到岗等待时间必须为 1~86400 秒")
        if not 0 <= grace_sec <= 300:
            raise ValueError("GRACE 必须为 0~300 秒")
        if not max(1, grace_sec) <= away_threshold_sec <= 86400:
            raise ValueError("ALERT 时间必须大于等于 GRACE，且不超过 86400 秒")
        if not 0 <= return_confirm_sec <= 60:
            raise ValueError("RETURN 必须为 0~60 秒")
        return {
            "mode": mode,
            "minimum_staff": minimum_staff,
            "first_arrival_wait_sec": first_arrival_wait_sec,
            "grace_sec": grace_sec,
            "away_threshold_sec": away_threshold_sec,
            "return_confirm_sec": return_confirm_sec,
        }

    def start_shift_batch(
        self,
        *,
        employee_ids: Sequence[int],
        workstation_id: int,
        mode: str,
        minimum_staff: int,
        first_arrival_wait_sec: int,
        grace_sec: int,
        away_threshold_sec: int,
        return_confirm_sec: int,
    ) -> Dict[str, Any]:
        ids = [int(x) for x in employee_ids]
        if not ids:
            raise ValueError("至少选择一名员工")
        if len(set(ids)) != len(ids):
            raise ValueError("员工列表中存在重复项")
        params = self._validate_round_params(
            mode,
            minimum_staff,
            first_arrival_wait_sec,
            grace_sec,
            away_threshold_sec,
            return_confirm_sec,
        )
        with self._lock:
            workstation = self._find(self._data["workstations"], workstation_id)
            if workstation is None or not workstation.get("enabled"):
                raise ValueError("工作台不存在或已停用")
            if len(workstation.get("roi", [])) < 3:
                raise ValueError("工作台尚未配置有效 ROI")

            active_round = self._active_round_raw(workstation_id)
            if active_round is None:
                if params["mode"] == "single" and len(ids) != 1:
                    raise ValueError("single 模式必须且只能选择 1 名员工")
            else:
                immutable = (
                    str(active_round["mode"]) != params["mode"]
                    or int(active_round["minimum_staff"]) != params["minimum_staff"]
                    or int(active_round["first_arrival_wait_sec"]) != params["first_arrival_wait_sec"]
                    or int(active_round["grace_sec"]) != params["grace_sec"]
                    or int(active_round["away_threshold_sec"]) != params["away_threshold_sec"]
                    or int(active_round["return_confirm_sec"]) != params["return_confirm_sec"]
                )
                if immutable:
                    raise ValueError("本轮排班参数已经锁定，追加员工必须使用相同参数")
                if active_round["mode"] == "single":
                    raise ValueError("single 模式本轮不能追加员工")

            errors: List[str] = []
            employees: List[Dict[str, Any]] = []
            for employee_id in ids:
                employee = self._find(self._data["employees"], employee_id)
                if employee is None:
                    errors.append(f"员工#{employee_id}不存在")
                    continue
                label = f"{employee['employee_code']} {employee['name']}"
                if not employee.get("enabled"):
                    errors.append(f"{label}已停用")
                elif not employee.get("enrolled"):
                    errors.append(f"{label}尚未完成人脸录入")
                else:
                    conflict = self._active_shift_for_employee(employee_id)
                    if conflict:
                        if int(conflict["workstation_id"]) == int(workstation_id):
                            errors.append(f"{label}已在当前本轮排班中")
                        else:
                            other_ws = self._find(self._data["workstations"], int(conflict["workstation_id"]))
                            errors.append(f"{label}已在工作台 {other_ws['name'] if other_ws else conflict['workstation_id']} 上班")
                employees.append(employee)
            if errors:
                raise ValueError("整批排班失败：" + "；".join(errors))

            timestamp = now_iso()
            if active_round is None:
                round_id = self._next_id("shift_rounds")
                active_round = {
                    "id": round_id,
                    "workstation_id": int(workstation_id),
                    **params,
                    "start_at": timestamp,
                    "end_at": None,
                    "status": "ACTIVE",
                    "record_version": "v1.0.6",
                    "created_at": timestamp,
                    "updated_at": timestamp,
                }
                self._data["shift_rounds"].append(active_round)
            else:
                round_id = int(active_round["id"])
                active_round["updated_at"] = timestamp

            shift_ids = []
            for employee_id in ids:
                shift_id = self._next_id("shifts")
                self._data["shifts"].append(
                    {
                        "id": shift_id,
                        "round_id": round_id,
                        "employee_id": int(employee_id),
                        "workstation_id": int(workstation_id),
                        "start_at": timestamp,
                        "joined_at": timestamp,
                        "end_at": None,
                        "status": "ACTIVE",
                    }
                )
                shift_ids.append(shift_id)
            self._atomic_write()
            return {"round_id": round_id, "shift_ids": shift_ids, "added_count": len(shift_ids)}

    def start_shift(self, employee_id: int, workstation_id: int) -> int:
        workstation = self.get_workstation(workstation_id)
        if workstation is None:
            raise ValueError("工作台不存在")
        result = self.start_shift_batch(
            employee_ids=[employee_id],
            workstation_id=workstation_id,
            mode="single",
            minimum_staff=1,
            first_arrival_wait_sec=600,
            grace_sec=int(workstation.get("grace_sec", 5)),
            away_threshold_sec=int(workstation.get("away_threshold_sec", 180)),
            return_confirm_sec=int(workstation.get("return_confirm_sec", 2)),
        )
        return int(result["shift_ids"][0])

    def get_round(self, round_id: int) -> Optional[Dict[str, Any]]:
        with self._lock:
            item = self._find(self._data["shift_rounds"], round_id)
            return self._round_join(item) if item else None

    def get_active_round(self, workstation_id: int) -> Optional[Dict[str, Any]]:
        with self._lock:
            item = self._active_round_raw(workstation_id)
            return self._round_join(item) if item else None

    def _round_join(self, round_item: Dict[str, Any]) -> Dict[str, Any]:
        row = copy.deepcopy(round_item)
        workstation = self._find(self._data["workstations"], int(round_item["workstation_id"]))
        row["workstation_name"] = workstation["name"] if workstation else "已删除工作台"
        shifts = [
            self._shift_join(x, include_runtime_fields=True)
            for x in self._data["shifts"]
            if x.get("round_id") is not None and int(x["round_id"]) == int(round_item["id"])
        ]
        row["shifts"] = [x for x in shifts if x is not None]
        row["active_count"] = sum(1 for x in row["shifts"] if x["status"] == "ACTIVE")
        return row

    def active_rounds(self) -> List[Dict[str, Any]]:
        with self._lock:
            return [
                self._round_join(item)
                for item in sorted(self._data["shift_rounds"], key=lambda x: int(x["id"]))
                if item.get("status") == "ACTIVE"
            ]

    def stop_workstation_round(self, workstation_id: int) -> Dict[str, Any]:
        with self._lock:
            round_item = self._active_round_raw(workstation_id)
            if round_item is None:
                raise ValueError("该工作台当前没有活动排班")
            timestamp = now_iso()
            round_id = int(round_item["id"])
            shifts = [
                item
                for item in self._data["shifts"]
                if item.get("status") == "ACTIVE"
                and item.get("round_id") is not None
                and int(item["round_id"]) == round_id
            ]

            # 整轮结束前，从未首次到岗的员工仍生成 NO_SHOW 记录。
            region_runtime = self._data["runtime_state"].get(f"round:{round_id}", {})
            shared_incident = region_runtime.get("incident_id") or uuid.uuid4().hex
            for shift in shifts:
                scope_key = f"shift:{int(shift['id'])}"
                runtime = self._data["runtime_state"].get(scope_key, {})
                first_present_at = runtime.get("first_present_at")
                existing_no_show = next(
                    (
                        event
                        for event in self._data["absence_events"]
                        if event.get("shift_id") is not None
                        and int(event["shift_id"]) == int(shift["id"])
                        and event.get("event_type") == "NO_SHOW"
                    ),
                    None,
                )
                if first_present_at is None and existing_no_show is None:
                    event_id = self._next_id("absence_events")
                    self._data["absence_events"].append(
                        self._new_event(
                            event_id=event_id,
                            event_scope="PERSONAL",
                            event_type="NO_SHOW",
                            scope_key=scope_key,
                            incident_id=shared_incident,
                            round_id=round_id,
                            shift_id=int(shift["id"]),
                            employee_id=int(shift["employee_id"]),
                            workstation_id=int(workstation_id),
                            leave_at=str(shift.get("joined_at") or shift.get("start_at")),
                            alert_at=timestamp,
                            return_at=timestamp,
                            duration_sec=duration_seconds(str(shift.get("joined_at") or shift.get("start_at")), timestamp),
                            status="CLOSED",
                            closed_reason="SHIFT_ENDED",
                        )
                    )

            for event in self._data["absence_events"]:
                if event.get("status") != "OPEN" or event.get("round_id") is None or int(event["round_id"]) != round_id:
                    continue
                effective_duration = None
                if event.get("event_scope") == "REGION":
                    effective_duration = region_runtime.get("shortage_elapsed_sec")
                elif event.get("shift_id") is not None:
                    shift_runtime = self._data["runtime_state"].get(f"shift:{int(event['shift_id'])}", {})
                    effective_duration = (
                        shift_runtime.get("arrival_elapsed_sec")
                        if event.get("event_type") == "NO_SHOW"
                        else shift_runtime.get("absence_elapsed_sec")
                    )
                event["return_at"] = timestamp
                event["duration_sec"] = int(round(float(effective_duration))) if effective_duration is not None else duration_seconds(event.get("leave_at"), timestamp)
                event["status"] = "CLOSED"
                event["closed_reason"] = "SHIFT_ENDED"
                event["updated_at"] = timestamp

            for shift in shifts:
                shift["status"] = "CLOSED"
                shift["end_at"] = timestamp
                self._data["runtime_state"].pop(f"shift:{int(shift['id'])}", None)
            self._data["runtime_state"].pop(f"round:{round_id}", None)
            round_item["status"] = "CLOSED"
            round_item["end_at"] = timestamp
            round_item["updated_at"] = timestamp
            self._atomic_write()
            return {"round_id": round_id, "workstation_id": workstation_id, "closed_shift_count": len(shifts)}

    def stop_shift(self, shift_id: int) -> None:
        with self._lock:
            shift = self._find(self._data["shifts"], shift_id)
            if shift is None:
                raise ValueError("班次不存在")
            if shift.get("status") != "ACTIVE":
                raise ValueError("班次已经结束")
            raise ValueError("不允许单独结束员工班次，请使用该工作台的“全部下班”")

    def _shift_join(self, shift: Dict[str, Any], include_runtime_fields: bool) -> Optional[Dict[str, Any]]:
        employee = self._find(self._data["employees"], int(shift["employee_id"]))
        workstation = self._find(self._data["workstations"], int(shift["workstation_id"]))
        if employee is None or workstation is None:
            return None
        row = copy.deepcopy(shift)
        row.update(
            {
                "employee_code": employee["employee_code"],
                "employee_name": employee["name"],
                "workstation_name": workstation["name"],
            }
        )
        if include_runtime_fields:
            round_item = self._find(self._data["shift_rounds"], int(shift["round_id"])) if shift.get("round_id") else None
            row.update(
                {
                    "camera_device": workstation["camera_device"],
                    "roi": copy.deepcopy(workstation["roi"]),
                    "mode": round_item.get("mode", "single") if round_item else "single",
                    "minimum_staff": int(round_item.get("minimum_staff", 1)) if round_item else 1,
                    "first_arrival_wait_sec": int(round_item.get("first_arrival_wait_sec", 600)) if round_item else 600,
                    "away_threshold_sec": int(round_item.get("away_threshold_sec", workstation.get("away_threshold_sec", 180))) if round_item else int(workstation.get("away_threshold_sec", 180)),
                    "grace_sec": int(round_item.get("grace_sec", workstation.get("grace_sec", 5))) if round_item else int(workstation.get("grace_sec", 5)),
                    "return_confirm_sec": int(round_item.get("return_confirm_sec", workstation.get("return_confirm_sec", 2))) if round_item else int(workstation.get("return_confirm_sec", 2)),
                }
            )
        return row

    def active_shifts(self) -> List[Dict[str, Any]]:
        with self._lock:
            rows = []
            for shift in self._data["shifts"]:
                if shift.get("status") != "ACTIVE":
                    continue
                row = self._shift_join(shift, True)
                if row:
                    rows.append(row)
            return sorted(rows, key=lambda x: int(x["id"]))

    def list_shifts(self, limit: int = 200) -> List[Dict[str, Any]]:
        with self._lock:
            rows = []
            for shift in sorted(self._data["shifts"], key=lambda x: int(x["id"]), reverse=True):
                row = self._shift_join(shift, False)
                if row:
                    round_item = self._find(self._data["shift_rounds"], int(shift["round_id"])) if shift.get("round_id") else None
                    row["mode"] = round_item.get("mode") if round_item else "legacy"
                    rows.append(row)
                if len(rows) >= int(limit):
                    break
            return rows

    # ---------- Runtime state ----------
    def save_runtime_state(self, scope_key: Optional[str] = None, **fields: Any) -> None:
        if scope_key is None:
            if "shift_id" not in fields:
                raise ValueError("缺少 scope_key 或 shift_id")
            scope_key = f"shift:{int(fields['shift_id'])}"
        key = str(scope_key)
        with self._lock:
            previous = self._data["runtime_state"].get(key)
            current = copy.deepcopy(fields)
            current["scope_key"] = key
            current["updated_at"] = now_iso()
            state_changed = previous is None or previous.get("state") != current.get("state")
            self._data["runtime_state"][key] = current
            monotonic_now = time.monotonic()
            if state_changed or monotonic_now - self._last_runtime_flush >= self.RUNTIME_FLUSH_INTERVAL_SEC:
                self._atomic_write()
                self._last_runtime_flush = monotonic_now

    def get_runtime_state(self, scope_key: str | int) -> Optional[Dict[str, Any]]:
        key = str(scope_key)
        if ":" not in key:
            key = f"shift:{key}"
        with self._lock:
            item = self._data["runtime_state"].get(key)
            return copy.deepcopy(item) if item else None

    def delete_runtime_state(self, scope_key: str) -> None:
        with self._lock:
            self._data["runtime_state"].pop(str(scope_key), None)
            self._atomic_write()

    # ---------- Events ----------
    @staticmethod
    def new_incident_id() -> str:
        return uuid.uuid4().hex

    @staticmethod
    def _new_event(
        *,
        event_id: int,
        event_scope: str,
        event_type: str,
        scope_key: str,
        incident_id: Optional[str],
        round_id: Optional[int],
        shift_id: Optional[int],
        employee_id: Optional[int],
        workstation_id: int,
        leave_at: str,
        alert_at: Optional[str] = None,
        return_at: Optional[str] = None,
        duration_sec: Optional[int] = None,
        status: str = "OPEN",
        leave_snapshot: Optional[str] = None,
        alert_snapshot: Optional[str] = None,
        return_snapshot: Optional[str] = None,
        present_count: Optional[int] = None,
        required_count: Optional[int] = None,
        closed_reason: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        timestamp = now_iso()
        return {
            "id": int(event_id),
            "record_version": "v1.0.7",
            "event_scope": str(event_scope),
            "event_type": str(event_type),
            "scope_key": str(scope_key),
            "incident_id": incident_id,
            "round_id": int(round_id) if round_id is not None else None,
            "shift_id": int(shift_id) if shift_id is not None else None,
            "employee_id": int(employee_id) if employee_id is not None else None,
            "workstation_id": int(workstation_id),
            "leave_at": leave_at,
            "alert_at": alert_at,
            "return_at": return_at,
            "duration_sec": duration_sec,
            "status": status,
            "leave_snapshot": leave_snapshot,
            "alert_snapshot": alert_snapshot,
            "return_snapshot": return_snapshot,
            "present_count": present_count,
            "required_count": required_count,
            "closed_reason": closed_reason,
            "metadata": copy.deepcopy(metadata or {}),
            "leave_status": "NONE",
            "leave_note": "",
            "leave_applied_at": None,
            "leave_reviewed_at": None,
            "leave_audit": [],
            "archived": 0,
            "created_at": timestamp,
            "updated_at": timestamp,
        }

    def get_open_event(self, shift_id: Optional[int] = None, *, scope_key: Optional[str] = None, event_type: Optional[str] = None) -> Optional[Dict[str, Any]]:
        with self._lock:
            matches = []
            for item in self._data["absence_events"]:
                if item.get("status") != "OPEN":
                    continue
                if scope_key is not None and item.get("scope_key") != scope_key:
                    continue
                if shift_id is not None and (item.get("shift_id") is None or int(item["shift_id"]) != int(shift_id)):
                    continue
                if event_type is not None and item.get("event_type") != event_type:
                    continue
                matches.append(item)
            if not matches:
                return None
            return copy.deepcopy(max(matches, key=lambda x: int(x["id"])))

    def open_event(
        self,
        *,
        event_scope: str,
        event_type: str,
        scope_key: str,
        incident_id: Optional[str],
        round_id: Optional[int],
        shift_id: Optional[int],
        employee_id: Optional[int],
        workstation_id: int,
        leave_at: str,
        leave_snapshot: Optional[str],
        present_count: Optional[int] = None,
        required_count: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> int:
        existing = self.get_open_event(scope_key=scope_key, event_type=event_type)
        if existing:
            return int(existing["id"])
        with self._lock:
            event_id = self._next_id("absence_events")
            self._data["absence_events"].append(
                self._new_event(
                    event_id=event_id,
                    event_scope=event_scope,
                    event_type=event_type,
                    scope_key=scope_key,
                    incident_id=incident_id,
                    round_id=round_id,
                    shift_id=shift_id,
                    employee_id=employee_id,
                    workstation_id=workstation_id,
                    leave_at=leave_at,
                    leave_snapshot=leave_snapshot,
                    present_count=present_count,
                    required_count=required_count,
                    metadata=metadata,
                )
            )
            self._atomic_write()
            return event_id

    def open_absence_event(self, *, shift_id: int, employee_id: int, workstation_id: int, leave_at: str, leave_snapshot: Optional[str]) -> int:
        shift = self._find(self._data["shifts"], shift_id)
        return self.open_event(
            event_scope="PERSONAL",
            event_type="ABSENCE",
            scope_key=f"shift:{shift_id}",
            incident_id=self.new_incident_id(),
            round_id=shift.get("round_id") if shift else None,
            shift_id=shift_id,
            employee_id=employee_id,
            workstation_id=workstation_id,
            leave_at=leave_at,
            leave_snapshot=leave_snapshot,
        )

    def mark_event_alert(self, event_id: int, alert_at: str, alert_snapshot: Optional[str]) -> None:
        with self._lock:
            event = self._find(self._data["absence_events"], event_id)
            if event is None:
                raise ValueError("事件不存在")
            if not event.get("alert_at"):
                event["alert_at"] = alert_at
                event["alert_snapshot"] = alert_snapshot
            event["updated_at"] = now_iso()
            self._atomic_write()

    def update_event_identity(
        self,
        event_id: int,
        *,
        employee_id: Optional[int],
        metadata_updates: Optional[Dict[str, Any]] = None,
    ) -> None:
        """为已经创建的安全事件补充后续识别到的员工身份。"""
        with self._lock:
            event = self._find(self._data["absence_events"], event_id)
            if event is None:
                raise ValueError("事件不存在")
            event["employee_id"] = int(employee_id) if employee_id is not None else None
            metadata = event.setdefault("metadata", {})
            if metadata_updates:
                metadata.update(copy.deepcopy(metadata_updates))
            event["updated_at"] = now_iso()
            self._atomic_write()

    def count_open_events(self) -> int:
        with self._lock:
            return sum(
                1 for event in self._data["absence_events"]
                if str(event.get("status", "")).upper() == "OPEN"
            )

    def close_event(self, event_id: int, *, return_at: str, duration_sec: int, return_snapshot: Optional[str], closed_reason: str = "RETURNED") -> None:
        with self._lock:
            event = self._find(self._data["absence_events"], event_id)
            if event is None:
                raise ValueError("事件不存在")
            if event.get("status") != "OPEN":
                return
            event.update(
                {
                    "return_at": return_at,
                    "duration_sec": int(duration_sec),
                    "status": "CLOSED",
                    "return_snapshot": return_snapshot,
                    "closed_reason": closed_reason,
                    "updated_at": now_iso(),
                }
            )
            self._atomic_write()

    def close_absence_event(self, event_id: int, *, return_at: str, duration_sec: int, return_snapshot: Optional[str]) -> None:
        self.close_event(event_id, return_at=return_at, duration_sec=duration_sec, return_snapshot=return_snapshot)

    def apply_leave(self, event_id: int, note: str) -> Dict[str, Any]:
        note = str(note).strip()
        if not note:
            raise ValueError("请填写请假备注")
        with self._lock:
            event = self._find(self._data["absence_events"], event_id)
            if event is None:
                raise ValueError("缺勤记录不存在")
            if event.get("event_scope") != "PERSONAL":
                raise ValueError("区域缺员记录不能申请请假")
            if event.get("status") != "CLOSED":
                raise ValueError("缺勤尚未结束，必须全部下班后才能申请请假")
            if event.get("round_id") is not None:
                round_item = self._find(self._data["shift_rounds"], int(event["round_id"]))
                if round_item and round_item.get("status") == "ACTIVE":
                    raise ValueError("本轮排班尚未结束，不能申请请假")
            if event.get("leave_status") not in {"NONE", "REJECTED"}:
                raise ValueError("当前记录不能重复申请")
            timestamp = now_iso()
            event["leave_status"] = "PENDING"
            event["leave_note"] = note
            event["leave_applied_at"] = timestamp
            event["leave_reviewed_at"] = None
            event["archived"] = 0
            event.setdefault("leave_audit", []).append({"action": "APPLY", "note": note, "at": timestamp})
            event["updated_at"] = timestamp
            self._atomic_write()
            return copy.deepcopy(event)

    def review_leave(self, event_id: int, approved: bool) -> Dict[str, Any]:
        with self._lock:
            event = self._find(self._data["absence_events"], event_id)
            if event is None:
                raise ValueError("缺勤记录不存在")
            if event.get("leave_status") != "PENDING":
                raise ValueError("该记录不是待审核状态")
            timestamp = now_iso()
            new_status = "APPROVED" if approved else "REJECTED"
            event["leave_status"] = new_status
            event["leave_reviewed_at"] = timestamp
            event["archived"] = 1 if approved else 0
            event.setdefault("leave_audit", []).append({"action": new_status, "note": event.get("leave_note", ""), "at": timestamp})
            event["updated_at"] = timestamp
            self._atomic_write()
            return copy.deepcopy(event)

    def _event_join(self, event: Dict[str, Any]) -> Dict[str, Any]:
        row = copy.deepcopy(event)
        employee = self._find(self._data["employees"], int(event["employee_id"])) if event.get("employee_id") is not None else None
        workstation = self._find(self._data["workstations"], int(event["workstation_id"]))
        metadata = event.get("metadata") or {}
        row["employee_code"] = employee["employee_code"] if employee else "—"
        if employee:
            row["employee_name"] = employee["name"]
        elif event.get("event_scope") in {"SAFETY", "SECURITY"}:
            track_id = metadata.get("track_id")
            if event.get("event_type") == "SHOPLIFTING":
                row["employee_name"] = f"未知人员 T{track_id}" if track_id is not None else "未知人员"
            else:
                row["employee_name"] = f"未知人员 T{track_id}" if track_id is not None else "未知人员"
        else:
            row["employee_name"] = "区域缺员"
        if workstation:
            row["workstation_name"] = workstation["name"]
            row["camera_device"] = workstation.get("camera_device")
        elif event.get("event_scope") in {"SAFETY", "SECURITY"}:
            row["workstation_name"] = "摄像头全画面"
            row["camera_device"] = metadata.get("camera_device")
        else:
            row["workstation_name"] = "已删除工作台"
            row["camera_device"] = metadata.get("camera_device")
        leave_status = str(event.get("leave_status", "NONE"))
        if event.get("event_type") == "FALL":
            category = "FALL"
        elif event.get("event_type") == "SHOPLIFTING":
            category = "THEFT"
        elif leave_status == "APPROVED":
            category = "LEAVE_APPROVED"
        elif leave_status == "PENDING":
            category = "LEAVE_PENDING"
        elif leave_status == "REJECTED":
            category = "LEAVE_REJECTED"
        elif event.get("event_scope") == "REGION":
            category = "REGION"
        else:
            category = "ABSENCE"
        row["history_category"] = category
        row["event_name"] = {
            "NO_SHOW": "未到岗/迟到",
            "ABSENCE": "个人缺勤",
            "REGION_SHORTAGE": "区域缺员",
            "FALL": "摔倒告警",
            "SHOPLIFTING": "盗窃告警",
        }.get(str(event.get("event_type")), str(event.get("event_type", "缺勤")))
        row["can_apply_leave"] = (
            event.get("record_version") != "legacy"
            and event.get("event_scope") == "PERSONAL"
            and event.get("event_type") in {"ABSENCE", "NO_SHOW"}
            and event.get("status") == "CLOSED"
            and leave_status in {"NONE", "REJECTED"}
            and (
                event.get("round_id") is None
                or (
                    (self._find(self._data["shift_rounds"], int(event["round_id"])) or {}).get("status") != "ACTIVE"
                )
            )
        )
        row["can_review_leave"] = leave_status == "PENDING"
        if event.get("event_scope") == "REGION" and event.get("incident_id"):
            row["linked_leave_approved"] = any(
                x.get("event_scope") == "PERSONAL"
                and x.get("incident_id") == event.get("incident_id")
                and x.get("leave_status") == "APPROVED"
                for x in self._data["absence_events"]
            )
        else:
            row["linked_leave_approved"] = False
        return row

    def query_events(
        self,
        *,
        employee_id: Optional[int] = None,
        workstation_id: Optional[int] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        category: Optional[str] = None,
        limit: int = 1000,
    ) -> List[Dict[str, Any]]:
        normalized_category = str(category or "all").lower()
        category_map = {
            "absence": "ABSENCE",
            "region": "REGION",
            "fall": "FALL",
            "theft": "THEFT",
            "leave_pending": "LEAVE_PENDING",
            "leave_approved": "LEAVE_APPROVED",
            "leave_rejected": "LEAVE_REJECTED",
        }
        wanted = category_map.get(normalized_category)
        with self._lock:
            rows = []
            for event in sorted(self._data["absence_events"], key=lambda x: int(x["id"]), reverse=True):
                if employee_id is not None:
                    if event.get("employee_id") is None or int(event["employee_id"]) != int(employee_id):
                        continue
                if workstation_id is not None and int(event["workstation_id"]) != int(workstation_id):
                    continue
                leave_date = str(event.get("leave_at", ""))[:10]
                if start_date and leave_date < start_date:
                    continue
                if end_date and leave_date > end_date:
                    continue
                row = self._event_join(event)
                if wanted and row["history_category"] != wanted:
                    continue
                rows.append(row)
                if len(rows) >= int(limit):
                    break
            return rows

    def delete_event(self, event_id: int) -> Dict[str, Any]:
        """删除一条已结束的历史事件；活动中的OPEN事件禁止删除。"""
        with self._lock:
            event = self._find(self._data["absence_events"], event_id)
            if event is None:
                raise ValueError("历史记录不存在")
            if str(event.get("status", "")).upper() == "OPEN":
                raise ValueError("活动中的告警记录不能删除，请先让人员返回或结束本轮排班")
            deleted = copy.deepcopy(event)
            self._data["absence_events"] = [
                item for item in self._data["absence_events"]
                if int(item["id"]) != int(event_id)
            ]
            self._atomic_write()
            return deleted

    def delete_events(
        self,
        *,
        employee_id: Optional[int] = None,
        workstation_id: Optional[int] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        category: Optional[str] = None,
    ) -> Dict[str, Any]:
        """删除符合筛选条件的已结束事件，保留所有OPEN活动事件。"""
        normalized_category = str(category or "all").lower()
        category_map = {
            "absence": "ABSENCE",
            "region": "REGION",
            "fall": "FALL",
            "theft": "THEFT",
            "leave_pending": "LEAVE_PENDING",
            "leave_approved": "LEAVE_APPROVED",
            "leave_rejected": "LEAVE_REJECTED",
        }
        wanted = category_map.get(normalized_category)

        with self._lock:
            deleted: List[Dict[str, Any]] = []
            keep: List[Dict[str, Any]] = []
            skipped_open = 0

            for event in self._data["absence_events"]:
                matches = True
                if employee_id is not None:
                    matches = event.get("employee_id") is not None and int(event["employee_id"]) == int(employee_id)
                if matches and workstation_id is not None:
                    matches = int(event["workstation_id"]) == int(workstation_id)
                leave_date = str(event.get("leave_at", ""))[:10]
                if matches and start_date:
                    matches = leave_date >= str(start_date)
                if matches and end_date:
                    matches = leave_date <= str(end_date)
                if matches and wanted:
                    matches = self._event_join(event)["history_category"] == wanted

                if not matches:
                    keep.append(event)
                    continue
                if str(event.get("status", "")).upper() == "OPEN":
                    keep.append(event)
                    skipped_open += 1
                    continue
                deleted.append(copy.deepcopy(event))

            if deleted:
                self._data["absence_events"] = keep
                self._atomic_write()

            return {
                "events": deleted,
                "deleted_count": len(deleted),
                "skipped_open": skipped_open,
            }

    # ---------- Settings ----------
    def set_setting(self, key: str, value: str) -> None:
        with self._lock:
            self._data["settings"][key] = {"value": value, "updated_at": now_iso()}
            self._atomic_write()

    def get_setting(self, key: str, default: Optional[str] = None) -> Optional[str]:
        with self._lock:
            item = self._data["settings"].get(key)
            return str(item["value"]) if item else default
