from __future__ import annotations

import time
import uuid
from collections import deque
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Deque, Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np

from .database import Database
from .identity import IdentityBinding
from .models import TheftDetection
from .tracker import Track


@dataclass
class TheftStatus:
    state: str
    active: bool
    score: float
    maximum_score: float
    hits_in_window: int
    required_hits: int
    window_seconds: float
    clear_elapsed_sec: float
    event_id: Optional[int]
    track_id: Optional[int]
    employee_id: Optional[int]
    employee_code: Optional[str]
    employee_name: Optional[str]
    bbox: Optional[List[float]]
    message: str


class TheftEventManager:
    """YOLO11 Shoplifting时序确认与事件管理。

    模型输出只负责单帧视觉判定；本类负责把单帧结果变成稳定业务事件：
    IDLE -> SUSPECTED -> ALERT -> COOLDOWN -> IDLE。
    """

    VALID_STATES = {"IDLE", "SUSPECTED", "ALERT", "COOLDOWN"}

    def __init__(
        self,
        *,
        database: Database,
        event_dir: str | Path,
        config: Dict[str, Any],
        camera_id: str,
        camera_name: str,
        alert_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> None:
        self.database = database
        self.event_dir = Path(event_dir)
        self.event_dir.mkdir(parents=True, exist_ok=True)
        self.config = dict(config or {})
        self.enabled = bool(self.config.get("enabled", True))
        self.alarm_class_id = int(self.config.get("alarm_class_id", 0))
        self.alarm_confidence = float(self.config.get("alarm_confidence", 0.35))
        self.window_seconds = float(self.config.get("window_seconds", 2.0))
        self.minimum_hits = int(self.config.get("minimum_hits", 5))
        self.clear_seconds = float(self.config.get("clear_seconds", 2.0))
        self.cooldown_seconds = float(self.config.get("cooldown_seconds", 8.0))
        self.snapshot_enabled = bool(self.config.get("snapshot_enabled", True))
        self.association_iou = float(self.config.get("association_iou", 0.10))
        self.camera_id = str(camera_id)
        self.camera_name = str(camera_name)
        self.alert_callback = alert_callback

        self.state = "IDLE"
        self._hits: Deque[Tuple[float, float]] = deque()
        self._last_hit_at: Optional[float] = None
        self._cooldown_until = 0.0
        self._event_id: Optional[int] = None
        self._event_started_monotonic: Optional[float] = None
        self._maximum_score = 0.0
        self._latest_status: Optional[TheftStatus] = None
        self._session_id = uuid.uuid4().hex[:10]

    @staticmethod
    def _bbox_iou(first: Sequence[float], second: Sequence[float]) -> float:
        a = np.asarray(first, dtype=np.float32)
        b = np.asarray(second, dtype=np.float32)
        x1 = max(float(a[0]), float(b[0]))
        y1 = max(float(a[1]), float(b[1]))
        x2 = min(float(a[2]), float(b[2]))
        y2 = min(float(a[3]), float(b[3]))
        inter = max(0.0, x2 - x1) * max(0.0, y2 - y1)
        area_a = max(0.0, float(a[2] - a[0])) * max(0.0, float(a[3] - a[1]))
        area_b = max(0.0, float(b[2] - b[0])) * max(0.0, float(b[3] - b[1]))
        return inter / max(area_a + area_b - inter, 1e-9)

    def _associate_identity(
        self,
        detection: TheftDetection,
        tracks: Sequence[Track],
        bindings: Dict[int, IdentityBinding],
    ) -> Tuple[Optional[int], Optional[IdentityBinding]]:
        best_track: Optional[Track] = None
        best_iou = 0.0
        for track in tracks:
            value = self._bbox_iou(detection.bbox, track.bbox)
            if value > best_iou:
                best_iou = value
                best_track = track
        if best_track is None or best_iou < self.association_iou:
            return None, None
        return int(best_track.track_id), bindings.get(int(best_track.track_id))

    def _snapshot(
        self,
        frame: Optional[np.ndarray],
        detection: Optional[TheftDetection],
        suffix: str,
    ) -> Optional[str]:
        if not self.snapshot_enabled or frame is None:
            return None
        image = frame.copy()
        if detection is not None:
            x1, y1, x2, y2 = [int(round(v)) for v in detection.bbox]
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 0, 255), 4)
            cv2.putText(
                image,
                f"SHOPLIFTING {detection.score:.2f}",
                (x1, max(28, y1 - 10)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 0, 255),
                2,
                cv2.LINE_AA,
            )
        folder = self.event_dir / datetime.now().strftime("%Y-%m-%d")
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / f"theft_{self.camera_id}_{datetime.now().strftime('%H%M%S_%f')}_{suffix}.jpg"
        return str(path) if cv2.imwrite(str(path), image) else None

    def _open_event(
        self,
        *,
        frame: np.ndarray,
        detection: TheftDetection,
        camera_device: str,
        track_id: Optional[int],
        binding: Optional[IdentityBinding],
        now_monotonic: float,
        now_wall: datetime,
    ) -> None:
        first_hit = self._hits[0][0] if self._hits else now_monotonic
        started_wall = datetime.fromtimestamp(
            now_wall.timestamp() - max(0.0, now_monotonic - first_hit)
        ).astimezone()
        employee_id = int(binding.employee_id) if binding is not None else None
        metadata = {
            "camera_id": self.camera_id,
            "camera_name": self.camera_name,
            "camera_device": str(camera_device),
            "track_id": track_id,
            "maximum_score": round(float(self._maximum_score), 4),
            "trigger_score": round(float(detection.score), 4),
            "hits_in_window": len(self._hits),
            "window_seconds": self.window_seconds,
            "required_hits": self.minimum_hits,
            "bbox": [round(float(v), 2) for v in detection.bbox],
            "class_name": detection.class_name,
        }
        leave_snapshot = self._snapshot(frame, detection, "first")
        alert_snapshot = self._snapshot(frame, detection, "alert")
        event_id = self.database.open_event(
            event_scope="SECURITY",
            event_type="SHOPLIFTING",
            scope_key=f"theft:{self._session_id}:{self.camera_id}",
            incident_id=self.database.new_incident_id(),
            round_id=None,
            shift_id=None,
            employee_id=employee_id,
            workstation_id=0,
            leave_at=started_wall.isoformat(timespec="seconds"),
            leave_snapshot=leave_snapshot,
            metadata=metadata,
        )
        self.database.mark_event_alert(
            event_id,
            now_wall.astimezone().isoformat(timespec="seconds"),
            alert_snapshot,
        )
        self._event_id = event_id
        self._event_started_monotonic = first_hit
        self.state = "ALERT"

        if self.alert_callback:
            self.alert_callback(
                {
                    "type": "shoplifting",
                    "event_type": "SHOPLIFTING",
                    "event_id": event_id,
                    "camera_id": self.camera_id,
                    "camera_name": self.camera_name,
                    "track_id": track_id,
                    "employee_id": employee_id,
                    "employee_code": binding.employee_code if binding else None,
                    "employee_name": binding.employee_name if binding else None,
                    "score": round(float(detection.score), 4),
                    "message": (
                        f"盗窃行为告警：{binding.employee_code} {binding.employee_name}"
                        if binding is not None
                        else f"盗窃行为告警：{self.camera_name}"
                    ),
                    "at": now_wall.astimezone().isoformat(timespec="seconds"),
                }
            )

    def _close_event(
        self,
        *,
        frame: Optional[np.ndarray],
        detection: Optional[TheftDetection],
        now_monotonic: float,
        now_wall: datetime,
    ) -> None:
        if self._event_id is not None:
            started = self._event_started_monotonic or now_monotonic
            self.database.close_event(
                self._event_id,
                return_at=now_wall.astimezone().isoformat(timespec="seconds"),
                duration_sec=max(0, int(round(now_monotonic - started))),
                return_snapshot=self._snapshot(frame, detection, "end"),
                closed_reason="SHOPLIFTING_CLEARED",
            )
        self._event_id = None
        self._event_started_monotonic = None
        self.state = "COOLDOWN"
        self._cooldown_until = now_monotonic + self.cooldown_seconds
        self._hits.clear()

    def update(
        self,
        *,
        frame: np.ndarray,
        detections: Sequence[TheftDetection],
        tracks: Sequence[Track],
        bindings: Dict[int, IdentityBinding],
        camera_device: str,
        now_monotonic: Optional[float] = None,
    ) -> TheftStatus:
        now = float(now_monotonic if now_monotonic is not None else time.monotonic())
        now_wall = datetime.now().astimezone()

        if not self.enabled:
            self._latest_status = TheftStatus(
                state="DISABLED",
                active=False,
                score=0.0,
                maximum_score=0.0,
                hits_in_window=0,
                required_hits=self.minimum_hits,
                window_seconds=self.window_seconds,
                clear_elapsed_sec=0.0,
                event_id=None,
                track_id=None,
                employee_id=None,
                employee_code=None,
                employee_name=None,
                bbox=None,
                message="盗窃检测已关闭",
            )
            return self._latest_status

        best = None
        for item in detections:
            if int(item.class_id) != self.alarm_class_id:
                continue
            if float(item.score) < self.alarm_confidence:
                continue
            if best is None or float(item.score) > float(best.score):
                best = item

        # 冷却期内只显示状态，不重新累计命中，避免一次长行为被重复拆成多个告警事件。
        if self.state == "COOLDOWN" and now < self._cooldown_until:
            best = None
            self._hits.clear()
        elif self.state == "COOLDOWN" and now >= self._cooldown_until:
            self.state = "IDLE"
            self._maximum_score = 0.0
            self._last_hit_at = None

        while self._hits and now - self._hits[0][0] > self.window_seconds:
            self._hits.popleft()

        track_id: Optional[int] = None
        binding: Optional[IdentityBinding] = None
        score = 0.0
        bbox: Optional[List[float]] = None

        if best is not None:
            score = float(best.score)
            bbox = [round(float(v), 2) for v in best.bbox]
            self._maximum_score = max(self._maximum_score, score)
            self._last_hit_at = now
            self._hits.append((now, score))
            track_id, binding = self._associate_identity(best, tracks, bindings)

            if self.state == "IDLE":
                self.state = "SUSPECTED"
            if self.state in {"SUSPECTED", "IDLE"} and len(self._hits) >= self.minimum_hits:
                self._open_event(
                    frame=frame,
                    detection=best,
                    camera_device=camera_device,
                    track_id=track_id,
                    binding=binding,
                    now_monotonic=now,
                    now_wall=now_wall,
                )
            elif self.state == "ALERT" and self._event_id is not None and binding is not None:
                self.database.update_event_identity(
                    self._event_id,
                    employee_id=int(binding.employee_id),
                    metadata_updates={
                        "track_id": track_id,
                        "employee_code": binding.employee_code,
                        "employee_name": binding.employee_name,
                        "maximum_score": round(float(self._maximum_score), 4),
                    },
                )
        else:
            if self.state == "SUSPECTED":
                if self._last_hit_at is None or now - self._last_hit_at > self.window_seconds:
                    self.state = "IDLE"
                    self._hits.clear()
                    self._maximum_score = 0.0
            elif self.state == "ALERT":
                if self._last_hit_at is None or now - self._last_hit_at >= self.clear_seconds:
                    self._close_event(
                        frame=frame,
                        detection=None,
                        now_monotonic=now,
                        now_wall=now_wall,
                    )
            elif self.state == "COOLDOWN" and now >= self._cooldown_until:
                self.state = "IDLE"
                self._maximum_score = 0.0

        clear_elapsed = 0.0
        if self._last_hit_at is not None and best is None:
            clear_elapsed = max(0.0, now - self._last_hit_at)

        employee_id = int(binding.employee_id) if binding is not None else None
        employee_code = binding.employee_code if binding is not None else None
        employee_name = binding.employee_name if binding is not None else None
        message = {
            "IDLE": "当前未发现盗窃行为",
            "SUSPECTED": f"疑似盗窃 {len(self._hits)}/{self.minimum_hits}，继续确认",
            "ALERT": f"盗窃告警中，最高置信度 {self._maximum_score:.2f}",
            "COOLDOWN": "盗窃事件已结束，处于防抖冷却期",
        }.get(self.state, self.state)

        self._latest_status = TheftStatus(
            state=self.state,
            active=self.state == "ALERT",
            score=round(score, 4),
            maximum_score=round(float(self._maximum_score), 4),
            hits_in_window=len(self._hits),
            required_hits=self.minimum_hits,
            window_seconds=round(self.window_seconds, 3),
            clear_elapsed_sec=round(clear_elapsed, 3),
            event_id=self._event_id,
            track_id=track_id,
            employee_id=employee_id,
            employee_code=employee_code,
            employee_name=employee_name,
            bbox=bbox,
            message=message,
        )
        return self._latest_status

    def latest(self) -> TheftStatus:
        if self._latest_status is not None:
            return self._latest_status
        return TheftStatus(
            state="IDLE" if self.enabled else "DISABLED",
            active=False,
            score=0.0,
            maximum_score=0.0,
            hits_in_window=0,
            required_hits=self.minimum_hits,
            window_seconds=self.window_seconds,
            clear_elapsed_sec=0.0,
            event_id=self._event_id,
            track_id=None,
            employee_id=None,
            employee_code=None,
            employee_name=None,
            bbox=None,
            message="等待盗窃模型首次推理" if self.enabled else "盗窃检测已关闭",
        )

    def serialize(self) -> Dict[str, Any]:
        return asdict(self.latest())

    def close_open_event(self, reason: str = "SERVICE_STOPPED") -> None:
        if self._event_id is None:
            return
        now = time.monotonic()
        now_wall = datetime.now().astimezone()
        started = self._event_started_monotonic or now
        self.database.close_event(
            self._event_id,
            return_at=now_wall.isoformat(timespec="seconds"),
            duration_sec=max(0, int(round(now - started))),
            return_snapshot=None,
            closed_reason=reason,
        )
        self._event_id = None
        self._event_started_monotonic = None
        self.state = "IDLE"
        self._hits.clear()
