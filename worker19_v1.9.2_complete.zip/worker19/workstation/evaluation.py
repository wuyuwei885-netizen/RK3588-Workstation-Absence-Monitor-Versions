from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, Optional


def _load_json(path: Path) -> Optional[Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _pct(value: Any) -> Optional[float]:
    if not isinstance(value, (int, float)):
        return None
    number = float(value)
    if 0.0 <= number <= 1.5:
        number *= 100.0
    return round(number, 4)


def _calibration_images(model_name: str) -> Optional[int]:
    match = re.search(r"calib(\d+)", model_name, re.IGNORECASE)
    return int(match.group(1)) if match else None


def evaluation_candidates(model_path: str | Path) -> Iterable[Path]:
    model = Path(model_path).expanduser().resolve()
    stem = model.stem
    root = model.parent.parent
    yield root / "quant_eval_fast" / f"{stem}.json"
    yield root / "quant_eval" / f"{stem}.json"
    yield model.parent / f"{stem}.json"


def load_model_evaluation(model_path: str | Path) -> Dict[str, Any]:
    model = Path(model_path).expanduser().resolve()
    for candidate in evaluation_candidates(model):
        payload = _load_json(candidate)
        if not isinstance(payload, dict):
            continue
        classes = payload.get("classes") if isinstance(payload.get("classes"), dict) else {}
        shoplifting = classes.get("Shoplifting") if isinstance(classes.get("Shoplifting"), dict) else {}
        stat = candidate.stat()
        return {
            "available": True,
            "source_path": str(candidate),
            "source_mtime": datetime.fromtimestamp(stat.st_mtime).astimezone().isoformat(timespec="seconds"),
            "model_name": str(payload.get("model_name") or model.name),
            "model_size_mb": round(float(payload.get("model_size_mb") or 0.0), 3),
            "calibration_images": _calibration_images(model.name),
            "evaluation_images": int(payload.get("images") or 0),
            "readable_images": int(payload.get("readable_images") or 0),
            "eval_conf_floor": payload.get("eval_conf_floor"),
            "report_conf": payload.get("report_conf"),
            "nms_thresh": payload.get("nms_thresh"),
            "max_det": payload.get("max_det"),
            "map50_pct": _pct(payload.get("mAP50")),
            "map50_95_pct": _pct(payload.get("mAP50_95")),
            "precision_pct": _pct(shoplifting.get("P_at_conf")),
            "recall_pct": _pct(shoplifting.get("R_at_conf")),
            "f1_pct": _pct(shoplifting.get("F1_at_conf")),
            "tp": shoplifting.get("TP"),
            "fp": shoplifting.get("FP"),
            "fn": shoplifting.get("FN"),
            "gt": shoplifting.get("GT"),
            "metric_definition": payload.get("metric_definition"),
        }

    # 如果单模型 JSON 不在板端，尝试同目录汇总文件；仍然只读取真实文件，不补假数据。
    root = model.parent.parent
    for summary_path in (root / "quant_eval_fast" / "quant_summary.json", root / "quant_summary.json"):
        payload = _load_json(summary_path)
        if not isinstance(payload, list):
            continue
        item = next((row for row in payload if isinstance(row, dict) and row.get("model") == model.name), None)
        if item is None:
            continue
        stat = summary_path.stat()
        return {
            "available": True,
            "source_path": str(summary_path),
            "source_mtime": datetime.fromtimestamp(stat.st_mtime).astimezone().isoformat(timespec="seconds"),
            "model_name": model.name,
            "model_size_mb": round(float(item.get("size_mb") or 0.0), 3),
            "calibration_images": _calibration_images(model.name),
            "evaluation_images": None,
            "map50_pct": _pct(item.get("mAP50")),
            "map50_95_pct": _pct(item.get("mAP50_95")),
            "precision_pct": None,
            "recall_pct": None,
            "f1_pct": None,
            "metric_definition": "来自 quant_summary.json；详细类别 P/R/F1 需要单模型评测 JSON。",
        }

    return {
        "available": False,
        "model_name": model.name,
        "calibration_images": _calibration_images(model.name),
        "source_path": None,
        "expected_paths": [str(path) for path in evaluation_candidates(model)],
        "message": "板端未找到该模型的离线评测 JSON；页面不会填入任何估算或写死精度。",
    }
