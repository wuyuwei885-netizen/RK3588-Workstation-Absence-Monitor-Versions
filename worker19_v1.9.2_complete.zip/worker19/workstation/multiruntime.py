from __future__ import annotations

import threading
from statistics import mean
from typing import Any, Dict, Iterable, List

from .database import Database
from .models import ModelHub
from .multicamera import MultiCameraManager
from .runtime import JPEGStore, RuntimeService


class _IdentityFacade:
    def __init__(self, runtimes: Iterable[RuntimeService]) -> None:
        self._runtimes = list(runtimes)

    def reload_profiles(self) -> None:
        for runtime in self._runtimes:
            runtime.identity.reload_profiles()

    @property
    def profile_count(self) -> int:
        if not self._runtimes:
            return 0
        return max(runtime.identity.profile_count for runtime in self._runtimes)


class MultiCameraRuntime:
    """多路Runtime统一门面。

    每路摄像头拥有独立：ByteTrack、Identity绑定缓存、Presence状态视图、FallDetector、JPEGStore。
    RKNN ModelHub由所有Runtime共享，并通过ModelHub内部锁保证同一模型不会被并发调用。
    """

    def __init__(
        self,
        *,
        camera_pool: MultiCameraManager,
        models: ModelHub,
        database: Database,
        runtimes: Dict[str, RuntimeService],
    ) -> None:
        self.camera_pool = camera_pool
        self.models = models
        self.database = database
        self._runtimes = dict(runtimes)
        self.identity = _IdentityFacade(self._runtimes.values())
        self._lock = threading.RLock()

    @property
    def camera_ids(self) -> List[str]:
        return list(self._runtimes.keys())

    def runtime_for_id(self, camera_id: str) -> RuntimeService:
        try:
            return self._runtimes[str(camera_id)]
        except KeyError as exc:
            raise KeyError(f"未知摄像头ID：{camera_id}") from exc

    def runtime_for_device(self, device: str) -> RuntimeService:
        return self.runtime_for_id(self.camera_pool.id_for_device(device))

    @property
    def primary_runtime(self) -> RuntimeService:
        return self.runtime_for_id(self.camera_pool.primary_id)

    @property
    def annotated_store(self) -> JPEGStore:
        return self.primary_runtime.annotated_store

    @property
    def raw_store(self) -> JPEGStore:
        return self.primary_runtime.raw_store

    def store(self, camera_id: str, kind: str = "annotated") -> JPEGStore:
        runtime = self.runtime_for_id(camera_id)
        if kind == "raw":
            return runtime.raw_store
        return runtime.annotated_store

    def start(self) -> None:
        for runtime in self._runtimes.values():
            if not runtime.is_alive():
                runtime.start()

    def pause(self) -> None:
        for runtime in self._runtimes.values():
            runtime.pause()

    def resume(self) -> None:
        for runtime in self._runtimes.values():
            runtime.resume()

    def stop(self) -> None:
        for runtime in self._runtimes.values():
            runtime.stop()

    def join(self, timeout: float | None = None) -> None:
        for runtime in self._runtimes.values():
            runtime.join(timeout=timeout)

    def is_alive(self) -> bool:
        return any(runtime.is_alive() for runtime in self._runtimes.values())

    def test_workstation(self, workstation_id: int, roi_override=None) -> Dict[str, Any]:
        workstation = self.database.get_workstation(workstation_id)
        if workstation is None:
            raise ValueError("工作台不存在")
        runtime = self.runtime_for_device(str(workstation.get("camera_device")))
        return runtime.test_workstation(workstation_id, roi_override=roi_override)

    @staticmethod
    def _mean_performance(camera_statuses: List[Dict[str, Any]]) -> Dict[str, Any]:
        keys = {
            "pose_ms",
            "retinaface_ms",
            "recognition_ms",
            "fall_rule_ms",
            "theft_pre_ms",
            "theft_npu_ms",
            "theft_post_ms",
            "theft_pipeline_ms",
            "camera_loop_fps",
            "pose_actual_fps",
            "face_actual_fps",
            "theft_actual_fps",
            "preview_actual_fps",
            "preview_encode_ms",
            "preview_frame_age_ms",
            "preview_dropped",
            "pose_queue_frame_age_ms",
            "pose_lock_wait_ms",
            "pose_dropped",
            "theft_queue_frame_age_ms",
            "theft_lock_wait_ms",
            "theft_dropped",
            "runtime_uptime_sec",
        }
        result: Dict[str, Any] = {}
        for key in keys:
            values = []
            for status in camera_statuses:
                value = (status.get("performance") or {}).get(key)
                if isinstance(value, (int, float)):
                    values.append(float(value))
            if values:
                # FPS为总吞吐，其余延迟/时间使用平均值。
                if key.endswith("_fps") or key.endswith("_dropped"):
                    result[key] = round(sum(values), 3)
                elif key == "runtime_uptime_sec":
                    result[key] = round(max(values), 1)
                else:
                    result[key] = round(mean(values), 3)
        return result

    def status(self) -> Dict[str, Any]:
        camera_statuses: List[Dict[str, Any]] = []
        tracks: List[Dict[str, Any]] = []
        shifts: List[Dict[str, Any]] = []
        regions: List[Dict[str, Any]] = []
        falls: List[Dict[str, Any]] = []
        theft_items: List[Dict[str, Any]] = []
        profile_count = 0
        binding_count = 0
        similarity_threshold = None

        for camera_id in self.camera_ids:
            status = self.runtime_for_id(camera_id).status()
            if not status:
                status = {"state": "starting", "camera_id": camera_id}
            spec = self.camera_pool.spec_for_id(camera_id)
            status.setdefault("camera_id", camera_id)
            status.setdefault("camera_name", str(spec.get("name", camera_id)))
            status.setdefault("camera_location", str(spec.get("location", "")))
            camera_statuses.append(status)

            for track in status.get("tracks", []) or []:
                item = dict(track)
                item.setdefault("camera_id", camera_id)
                item.setdefault("camera_name", status.get("camera_name"))
                item.setdefault("camera_location", status.get("camera_location"))
                tracks.append(item)
            for shift in status.get("shifts", []) or []:
                item = dict(shift)
                item["camera_id"] = camera_id
                item["camera_name"] = status.get("camera_name")
                item["camera_location"] = status.get("camera_location")
                shifts.append(item)
            for region in status.get("regions", []) or []:
                item = dict(region)
                item["camera_id"] = camera_id
                item["camera_name"] = status.get("camera_name")
                item["camera_location"] = status.get("camera_location")
                regions.append(item)
            for fall in status.get("falls", []) or []:
                item = dict(fall)
                item["camera_id"] = camera_id
                item["camera_name"] = status.get("camera_name")
                item["camera_location"] = status.get("camera_location")
                falls.append(item)

            theft = status.get("theft")
            if isinstance(theft, dict):
                item = dict(theft)
                item["camera_id"] = camera_id
                item["camera_name"] = status.get("camera_name")
                item["camera_location"] = status.get("camera_location")
                theft_items.append(item)

            identity = status.get("identity") or {}
            profile_count = max(profile_count, int(identity.get("profile_count") or 0))
            binding_count += int(identity.get("binding_count") or 0)
            if similarity_threshold is None and identity.get("similarity_threshold") is not None:
                similarity_threshold = identity.get("similarity_threshold")

        states = [str(item.get("state", "starting")) for item in camera_statuses]
        if states and all(state == "running" for state in states):
            state = "running"
        elif states and all(state == "paused" for state in states):
            state = "paused"
        elif any(state == "error" for state in states):
            state = "degraded"
        elif any(state in {"running", "paused"} for state in states):
            state = "degraded"
        else:
            state = "starting"

        fall_summary = {
            "enabled": any((item.get("fall_summary") or {}).get("enabled", False) for item in camera_statuses),
            "suspected": sum(int((item.get("fall_summary") or {}).get("suspected") or 0) for item in camera_statuses),
            "fallen": sum(int((item.get("fall_summary") or {}).get("fallen") or 0) for item in camera_statuses),
            "recovering": sum(int((item.get("fall_summary") or {}).get("recovering") or 0) for item in camera_statuses),
        }
        theft_summary = {
            "enabled": any((item.get("theft_summary") or {}).get("enabled", False) for item in camera_statuses),
            "suspected": sum(int((item.get("theft_summary") or {}).get("suspected") or 0) for item in camera_statuses),
            "alerts": sum(int((item.get("theft_summary") or {}).get("alerts") or 0) for item in camera_statuses),
        }

        npu_metrics = self.models.metrics()
        model_paths = {
            key: item.get("model_path")
            for key, item in (npu_metrics.get("models") or {}).items()
            if isinstance(item, dict) and item.get("model_path")
        }

        return {
            "state": state,
            "time": next((item.get("time") for item in reversed(camera_statuses) if item.get("time")), None),
            "camera": self.camera_pool.status(),
            "cameras": camera_statuses,
            "performance": self._mean_performance(camera_statuses),
            "npu": npu_metrics,
            "model_paths": model_paths,
            "identity": {
                "profile_count": profile_count,
                "binding_count": binding_count,
                "similarity_threshold": similarity_threshold,
            },
            "tracks": tracks,
            "falls": falls,
            "fall_summary": fall_summary,
            "theft": theft_items,
            "theft_summary": theft_summary,
            "shifts": shifts,
            "regions": regions,
        }
