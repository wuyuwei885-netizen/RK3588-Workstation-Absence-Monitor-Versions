from __future__ import annotations

import json
import threading
import time
from collections import deque
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

import cv2
import numpy as np

from .camera import CameraManager
from .database import Database
from .fall_detection import FallDetector, FallStatus
from .theft_detection import TheftEventManager, TheftStatus
from .geometry import denormalize_polygon, point_in_polygon
from .identity import IdentityBinding, IdentityService
from .models import FaceDetection, ModelHub
from .presence import PresenceManager, RegionStatus, ShiftStatus
from .tracker import ByteTrackLite, Track


SKELETON = (
    (15, 13),
    (13, 11),
    (16, 14),
    (14, 12),
    (11, 12),
    (5, 11),
    (6, 12),
    (5, 6),
    (5, 7),
    (7, 9),
    (6, 8),
    (8, 10),
)


class JPEGStore:
    def __init__(self) -> None:
        self.condition = threading.Condition()
        self.jpeg: Optional[bytes] = None
        self.version = -1

    def update(self, jpeg: bytes) -> None:
        with self.condition:
            self.jpeg = jpeg
            self.version += 1
            self.condition.notify_all()

    def wait(self, previous_version: int, timeout: float = 2.0):
        with self.condition:
            self.condition.wait_for(
                lambda: self.version != previous_version, timeout=timeout
            )
            return self.jpeg, self.version


class LatestJPEGEncoder(threading.Thread):
    """只编码最新预览帧；编码来不及时覆盖旧任务，绝不形成JPEG队列。"""

    def __init__(
        self,
        annotated_store: JPEGStore,
        raw_store: JPEGStore,
        quality: int,
        raw_fps: float = 6.0,
    ) -> None:
        super().__init__(name="preview-jpeg-encoder", daemon=True)
        self.annotated_store = annotated_store
        self.raw_store = raw_store
        self.quality = int(quality)
        self.raw_interval = 1.0 / max(float(raw_fps), 0.1)
        self._next_raw_encode = 0.0
        self._condition = threading.Condition()
        self._pending: Optional[Tuple[np.ndarray, np.ndarray, float]] = None
        self._stop_event = threading.Event()
        self._dropped = 0
        self._submitted = 0
        self._completed = 0
        self._errors = 0
        self._latencies = deque(maxlen=240)
        self._annotated_latencies = deque(maxlen=240)
        self._raw_latencies = deque(maxlen=240)
        self._frame_ages = deque(maxlen=240)
        self._timestamps = deque(maxlen=240)
        self._last_error: Optional[str] = None

    @staticmethod
    def _encode(frame: np.ndarray, quality: int) -> bytes:
        success, encoded = cv2.imencode(
            ".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, int(quality)]
        )
        if not success:
            raise RuntimeError("JPEG编码失败")
        return encoded.tobytes()

    def submit(self, annotated: np.ndarray, raw: np.ndarray, capture_ts: float) -> None:
        with self._condition:
            self._submitted += 1
            if self._pending is not None:
                self._dropped += 1
            self._pending = (annotated, raw, float(capture_ts))
            self._condition.notify()

    def stop(self) -> None:
        self._stop_event.set()
        with self._condition:
            self._condition.notify_all()

    def run(self) -> None:
        while not self._stop_event.is_set():
            with self._condition:
                self._condition.wait_for(
                    lambda: self._pending is not None or self._stop_event.is_set(),
                    timeout=0.5,
                )
                if self._stop_event.is_set():
                    break
                task = self._pending
                self._pending = None
            if task is None:
                continue
            annotated, raw, capture_ts = task
            task_started = time.perf_counter()
            try:
                # 监控画面优先。帧龄在 annotated JPEG 真正发布时立即记账，
                # 不把后续较低优先级 raw JPEG 的耗时错误算到网页显示延迟里。
                annotated_started = time.perf_counter()
                annotated_jpeg = self._encode(annotated, self.quality)
                annotated_ms = (time.perf_counter() - annotated_started) * 1000.0
                self.annotated_store.update(annotated_jpeg)
                annotated_completed = time.monotonic()
                self._completed += 1
                self._annotated_latencies.append(annotated_ms)
                self._frame_ages.append(max(0.0, annotated_completed - capture_ts) * 1000.0)
                self._timestamps.append(annotated_completed)

                if annotated_completed >= self._next_raw_encode:
                    raw_started = time.perf_counter()
                    self.raw_store.update(self._encode(raw, self.quality))
                    self._raw_latencies.append((time.perf_counter() - raw_started) * 1000.0)
                    self._next_raw_encode = annotated_completed + self.raw_interval

                self._latencies.append((time.perf_counter() - task_started) * 1000.0)
            except Exception as exc:
                self._errors += 1
                self._last_error = f"{type(exc).__name__}: {exc}"

    @staticmethod
    def _rate(values) -> float:
        items = list(values)
        if len(items) < 2 or items[-1] <= items[0]:
            return 0.0
        return (len(items) - 1) / (items[-1] - items[0])

    def metrics(self) -> Dict[str, Any]:
        latencies = list(self._latencies)
        annotated_latencies = list(self._annotated_latencies)
        raw_latencies = list(self._raw_latencies)
        ages = list(self._frame_ages)
        return {
            "submitted": self._submitted,
            "completed": self._completed,
            "dropped": self._dropped,
            "errors": self._errors,
            "encode_avg_ms": round(float(np.mean(latencies)), 3) if latencies else 0.0,
            "encode_p95_ms": round(float(np.percentile(latencies, 95)), 3) if latencies else 0.0,
            "annotated_encode_avg_ms": round(float(np.mean(annotated_latencies)), 3) if annotated_latencies else 0.0,
            "annotated_encode_p95_ms": round(float(np.percentile(annotated_latencies, 95)), 3) if annotated_latencies else 0.0,
            "raw_encode_avg_ms": round(float(np.mean(raw_latencies)), 3) if raw_latencies else 0.0,
            "raw_encode_p95_ms": round(float(np.percentile(raw_latencies, 95)), 3) if raw_latencies else 0.0,
            "frame_age_avg_ms": round(float(np.mean(ages)), 3) if ages else 0.0,
            "frame_age_p95_ms": round(float(np.percentile(ages, 95)), 3) if ages else 0.0,
            "actual_fps": round(self._rate(self._timestamps), 3),
            "last_error": self._last_error,
        }


class LatestPoseInferenceWorker(threading.Thread):
    """Core0 Pose latest-only 异步推理。

    Runtime主循环只提交最新帧，不等待Pose inference。两路摄像头共享ModelHub.pose_lock，
    如果Core0忙，新任务覆盖旧任务，因此网页预览不会因NPU推理排队而越看越旧。
    """

    def __init__(self, model, model_lock: threading.RLock, callback: Callable[[Dict[str, Any]], None], name: str) -> None:
        super().__init__(name=name, daemon=True)
        self.model = model
        self.model_lock = model_lock
        self.callback = callback
        self._condition = threading.Condition()
        self._pending: Optional[Dict[str, Any]] = None
        self._stop_event = threading.Event()
        self._submitted = 0
        self._completed = 0
        self._dropped = 0
        self._errors = 0
        self._lock_wait_ms = deque(maxlen=240)
        self._frame_age_ms = deque(maxlen=240)
        self._timestamps = deque(maxlen=240)
        self._last_error: Optional[str] = None

    def submit(self, task: Dict[str, Any]) -> None:
        with self._condition:
            self._submitted += 1
            if self._pending is not None:
                self._dropped += 1
            self._pending = task
            self._condition.notify()

    def stop(self) -> None:
        self._stop_event.set()
        with self._condition:
            self._condition.notify_all()

    def run(self) -> None:
        while not self._stop_event.is_set():
            with self._condition:
                self._condition.wait_for(
                    lambda: self._pending is not None or self._stop_event.is_set(),
                    timeout=0.5,
                )
                if self._stop_event.is_set():
                    break
                task = self._pending
                self._pending = None
            if task is None:
                continue
            try:
                wait_started = time.perf_counter()
                with self.model_lock:
                    lock_wait_ms = (time.perf_counter() - wait_started) * 1000.0
                    detections, inference_ms = self.model.infer(task["frame"])
                completed_at = time.monotonic()
                result = dict(task)
                result.update(
                    {
                        "detections": detections,
                        "inference_ms": float(inference_ms),
                        "completed_at": completed_at,
                        "lock_wait_ms": lock_wait_ms,
                    }
                )
                self.callback(result)
                self._completed += 1
                self._lock_wait_ms.append(lock_wait_ms)
                self._frame_age_ms.append(
                    max(0.0, completed_at - float(task["capture_ts"])) * 1000.0
                )
                self._timestamps.append(completed_at)
            except Exception as exc:
                self._errors += 1
                self._last_error = f"{type(exc).__name__}: {exc}"

    @staticmethod
    def _rate(values) -> float:
        items = list(values)
        if len(items) < 2 or items[-1] <= items[0]:
            return 0.0
        return (len(items) - 1) / (items[-1] - items[0])

    def metrics(self) -> Dict[str, Any]:
        waits = list(self._lock_wait_ms)
        ages = list(self._frame_age_ms)
        return {
            "submitted": self._submitted,
            "completed": self._completed,
            "dropped": self._dropped,
            "errors": self._errors,
            "lock_wait_avg_ms": round(float(np.mean(waits)), 3) if waits else 0.0,
            "lock_wait_p95_ms": round(float(np.percentile(waits, 95)), 3) if waits else 0.0,
            "frame_age_avg_ms": round(float(np.mean(ages)), 3) if ages else 0.0,
            "frame_age_p95_ms": round(float(np.percentile(ages, 95)), 3) if ages else 0.0,
            "actual_fps": round(self._rate(self._timestamps), 3),
            "last_error": self._last_error,
        }


class LatestTheftInferenceWorker(threading.Thread):
    """YOLO11 Core1 异步推理。主Pose/网页线程不等待盗窃模型。

    每个摄像头最多保留1个待处理任务，新任务覆盖旧任务，因此不会因为NPU/后处理
    暂时变慢而让实时监控不断积压旧视频帧。
    """

    def __init__(self, model, model_lock: threading.RLock, callback: Callable[[Dict[str, Any]], None], name: str) -> None:
        super().__init__(name=name, daemon=True)
        self.model = model
        self.model_lock = model_lock
        self.callback = callback
        self._condition = threading.Condition()
        self._pending: Optional[Dict[str, Any]] = None
        self._stop_event = threading.Event()
        self._submitted = 0
        self._completed = 0
        self._dropped = 0
        self._errors = 0
        self._lock_wait_ms = deque(maxlen=240)
        self._frame_age_ms = deque(maxlen=240)
        self._timestamps = deque(maxlen=240)
        self._last_error: Optional[str] = None

    def submit(self, task: Dict[str, Any]) -> None:
        with self._condition:
            self._submitted += 1
            if self._pending is not None:
                self._dropped += 1
            self._pending = task
            self._condition.notify()

    def stop(self) -> None:
        self._stop_event.set()
        with self._condition:
            self._condition.notify_all()

    def run(self) -> None:
        while not self._stop_event.is_set():
            with self._condition:
                self._condition.wait_for(
                    lambda: self._pending is not None or self._stop_event.is_set(),
                    timeout=0.5,
                )
                if self._stop_event.is_set():
                    break
                task = self._pending
                self._pending = None
            if task is None:
                continue
            try:
                wait_started = time.perf_counter()
                with self.model_lock:
                    lock_wait_ms = (time.perf_counter() - wait_started) * 1000.0
                    detections, timing = self.model.infer(task["frame"])
                completed_at = time.monotonic()
                result = dict(task)
                result.update({
                    "detections": detections,
                    "timing": timing,
                    "completed_at": completed_at,
                    "lock_wait_ms": lock_wait_ms,
                })
                self.callback(result)
                self._completed += 1
                self._lock_wait_ms.append(lock_wait_ms)
                self._frame_age_ms.append(max(0.0, completed_at - float(task["capture_ts"])) * 1000.0)
                self._timestamps.append(completed_at)
            except Exception as exc:
                self._errors += 1
                self._last_error = f"{type(exc).__name__}: {exc}"

    @staticmethod
    def _rate(values) -> float:
        items = list(values)
        if len(items) < 2 or items[-1] <= items[0]:
            return 0.0
        return (len(items) - 1) / (items[-1] - items[0])

    def metrics(self) -> Dict[str, Any]:
        waits = list(self._lock_wait_ms)
        ages = list(self._frame_age_ms)
        return {
            "submitted": self._submitted,
            "completed": self._completed,
            "dropped": self._dropped,
            "errors": self._errors,
            "lock_wait_avg_ms": round(float(np.mean(waits)), 3) if waits else 0.0,
            "lock_wait_p95_ms": round(float(np.percentile(waits, 95)), 3) if waits else 0.0,
            "frame_age_avg_ms": round(float(np.mean(ages)), 3) if ages else 0.0,
            "frame_age_p95_ms": round(float(np.percentile(ages, 95)), 3) if ages else 0.0,
            "actual_fps": round(self._rate(self._timestamps), 3),
            "last_error": self._last_error,
        }


class RuntimeService(threading.Thread):
    def __init__(
        self,
        *,
        camera: CameraManager,
        models: ModelHub,
        database: Database,
        runtime_config: Dict[str, Any],
        presence_config: Dict[str, Any],
        fall_config: Dict[str, Any],
        theft_config: Dict[str, Any],
        event_dir: str | Path,
        alert_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
        camera_id: Optional[str] = None,
        camera_name: Optional[str] = None,
        camera_location: Optional[str] = None,
    ) -> None:
        super().__init__(name=f"runtime-{camera_id or Path(camera.active_device).name}", daemon=True)
        self.camera = camera
        self.camera_id = str(camera_id or Path(camera.active_device).name)
        self.camera_name = str(camera_name or self.camera_id)
        self.camera_location = str(camera_location or "")
        self.models = models
        self.database = database
        self.runtime_config = runtime_config
        self.stop_event = threading.Event()
        self.pause_event = threading.Event()
        self.error: Optional[str] = None
        self.annotated_store = JPEGStore()
        self.raw_store = JPEGStore()
        self._status_lock = threading.RLock()
        self._async_lock = threading.RLock()
        self._status: Dict[str, Any] = {"state": "starting"}
        self._pending_pose_result: Optional[Dict[str, Any]] = None
        self._pending_theft_result: Optional[Dict[str, Any]] = None

        self.tracker = ByteTrackLite(
            track_thresh=float(runtime_config.get("track_thresh", 0.45)),
            low_thresh=float(runtime_config.get("track_low_thresh", 0.10)),
            new_track_thresh=float(runtime_config.get("new_track_thresh", 0.55)),
            match_thresh=float(runtime_config.get("match_thresh", 0.75)),
            track_buffer=int(runtime_config.get("track_buffer", 30)),
        )
        recognition_config = (
            models.face_recognizer.config if models.face_recognizer else {}
        )
        self.identity = IdentityService(
            database=database,
            models=models,
            similarity_threshold=float(
                recognition_config.get("similarity_threshold", 0.55)
            ),
            recognition_cooldown_sec=float(
                runtime_config.get("face_recognition_cooldown_sec", 1.5)
            ),
            binding_ttl_sec=float(runtime_config.get("binding_ttl_sec", 5.0)),
        )
        self.presence = PresenceManager(
            database=database,
            event_dir=event_dir,
            hip_confidence=float(presence_config.get("hip_keypoint_confidence", 0.30)),
            binding_hold_sec=float(runtime_config.get("binding_ttl_sec", 5.0)),
            alert_callback=alert_callback,
        )
        self.fall_detector = FallDetector(
            database=database,
            event_dir=event_dir,
            config=fall_config,
            alert_callback=alert_callback,
        )
        theft_runtime_config = dict(theft_config or {})
        theft_runtime_config["enabled"] = bool(
            theft_runtime_config.get("enabled", True) and self.models.theft is not None
        )
        self.theft_manager = TheftEventManager(
            database=database,
            event_dir=event_dir,
            config=theft_runtime_config,
            camera_id=self.camera_id,
            camera_name=self.camera_name,
            alert_callback=alert_callback,
        )
        self.latest_tracks: List[Track] = []
        self.latest_faces: List[FaceDetection] = []
        self.latest_bindings: Dict[int, IdentityBinding] = {}
        self.latest_shift_status: List[ShiftStatus] = []
        self.latest_region_status: List[RegionStatus] = []
        self.latest_fall_status: List[FallStatus] = []
        self.latest_theft_detections = []
        self.latest_theft_status: TheftStatus = self.theft_manager.latest()
        self._latest_frame_shape = (0, 0)
        self._runtime_started = time.monotonic()
        self._frame_times = deque(maxlen=240)
        self._pose_times = deque(maxlen=240)
        self._face_times = deque(maxlen=240)
        self._theft_times = deque(maxlen=240)
        self._preview_times = deque(maxlen=240)
        self.preview_width = int(runtime_config.get("preview_width", 960))
        self.preview_encoder = LatestJPEGEncoder(
            self.annotated_store,
            self.raw_store,
            int(runtime_config.get("jpeg_quality", 68)),
            raw_fps=float(runtime_config.get("raw_preview_fps", 6.0)),
        )
        self.pose_worker: Optional[LatestPoseInferenceWorker] = None
        if self.models.pose is not None:
            self.pose_worker = LatestPoseInferenceWorker(
                self.models.pose,
                self.models.pose_lock,
                self._accept_pose_result,
                name=f"pose-{self.camera_id}",
            )
        self.theft_worker: Optional[LatestTheftInferenceWorker] = None
        if self.models.theft is not None:
            self.theft_worker = LatestTheftInferenceWorker(
                self.models.theft,
                self.models.theft_lock,
                self._accept_theft_result,
                name=f"theft-{self.camera_id}",
            )

    def _accept_pose_result(self, result: Dict[str, Any]) -> None:
        with self._async_lock:
            self._pending_pose_result = result

    def _pop_pose_result(self) -> Optional[Dict[str, Any]]:
        with self._async_lock:
            result = self._pending_pose_result
            self._pending_pose_result = None
            return result

    def _accept_theft_result(self, result: Dict[str, Any]) -> None:
        with self._async_lock:
            # 只保留最新完成结果，业务线程下一轮立即消费；不积压旧推理结果。
            self._pending_theft_result = result

    def _pop_theft_result(self) -> Optional[Dict[str, Any]]:
        with self._async_lock:
            result = self._pending_theft_result
            self._pending_theft_result = None
            return result

    @staticmethod
    def _clone_tracks(tracks: Sequence[Track]) -> List[Track]:
        return [
            Track(
                track_id=int(track.track_id),
                bbox=track.bbox.copy(),
                score=float(track.score),
                keypoints=track.keypoints.copy(),
                velocity=track.velocity.copy(),
                age=int(track.age),
                hits=int(track.hits),
                missed=int(track.missed),
                active=bool(track.active),
            )
            for track in tracks
        ]

    def pause(self) -> None:
        self.pause_event.set()

    def resume(self) -> None:
        self.pause_event.clear()

    @property
    def paused(self) -> bool:
        return self.pause_event.is_set()

    def stop(self) -> None:
        self.stop_event.set()
        self.preview_encoder.stop()
        if self.pose_worker is not None:
            self.pose_worker.stop()
        if self.theft_worker is not None:
            self.theft_worker.stop()

    def status(self) -> Dict[str, Any]:
        with self._status_lock:
            return json.loads(json.dumps(self._status, ensure_ascii=False))

    def _set_status(self, value: Dict[str, Any]) -> None:
        with self._status_lock:
            self._status = value

    def test_workstation(
        self,
        workstation_id: int,
        roi_override: Optional[Sequence[Sequence[float]]] = None,
    ) -> Dict[str, Any]:
        """
        测试工作台区域。

        roi_override用于网页当前尚未保存的Canvas草稿，因此“测试区域判断”
        不再依赖数据库中已经保存的ROI。
        """
        workstation = self.database.get_workstation(workstation_id)
        if workstation is None:
            raise ValueError("工作台不存在")
        if str(workstation.get("camera_device")) != str(self.camera.active_device):
            raise ValueError(
                f"工作台绑定{workstation.get('camera_device')}，当前运行时为{self.camera.active_device}"
            )

        roi_source = roi_override if roi_override is not None else workstation["roi"]
        roi: List[List[float]] = []
        for point in roi_source or []:
            if not isinstance(point, (list, tuple)) or len(point) != 2:
                raise ValueError("ROI点格式错误")
            x = float(point[0])
            y = float(point[1])
            if not 0.0 <= x <= 1.0 or not 0.0 <= y <= 1.0:
                raise ValueError("ROI坐标必须位于0~1")
            roi.append([x, y])

        height, width = self._latest_frame_shape
        if height <= 0 or width <= 0:
            return {
                "ready": False,
                "message": "尚无摄像头画面",
                "people": [],
                "frame_size": [0, 0],
                "roi": roi,
            }

        if len(roi) < 3:
            return {
                "ready": False,
                "message": "当前ROI草稿至少需要3个点",
                "people": [],
                "frame_size": [width, height],
                "roi": roi,
            }

        people = []
        for track in self.latest_tracks:
            anchor = self.presence.anchor(track)
            binding = self.latest_bindings.get(track.track_id)
            people.append(
                {
                    "track_id": track.track_id,
                    "anchor": [round(anchor[0], 1), round(anchor[1], 1)],
                    "inside": point_in_polygon(anchor, roi, width, height),
                    "employee_code": binding.employee_code if binding else None,
                    "employee_name": binding.employee_name if binding else None,
                    "score": round(float(track.score), 4),
                }
            )

        if people:
            inside_count = sum(1 for person in people if person["inside"])
            message = f"检测到{len(people)}个人体，ROI内{inside_count}人"
        else:
            message = "ROI有效，但当前画面没有检测到人体"

        tested_workstation = dict(workstation)
        tested_workstation["roi"] = roi
        return {
            "ready": True,
            "message": message,
            "workstation": tested_workstation,
            "frame_size": [width, height],
            "people": people,
            "roi": roi,
        }

    @staticmethod
    def _draw_track(
        image: np.ndarray,
        track: Track,
        binding: Optional[IdentityBinding],
        keypoint_confidence: float,
        fall_status: Optional[FallStatus] = None,
    ) -> None:
        x1, y1, x2, y2 = np.round(track.bbox).astype(int)
        fall_colors = {
            "SUSPECTED": (0, 220, 255),
            "FALLEN": (0, 0, 255),
            "RECOVERING": (255, 120, 0),
        }
        color = fall_colors.get(
            fall_status.state if fall_status else "",
            (0, 220, 0) if binding else (0, 180, 255),
        )
        thickness = 5 if fall_status and fall_status.state == "FALLEN" else 3
        cv2.rectangle(image, (x1, y1), (x2, y2), color, thickness)
        identity_label = (
            f"{binding.employee_code} {binding.employee_name} T{track.track_id} {binding.similarity:.2f}"
            if binding
            else f"UNKNOWN T{track.track_id} {track.score:.2f}"
        )
        if fall_status and fall_status.state != "NORMAL":
            label = f"{fall_status.state} {fall_status.score}/5 | {identity_label}"
        else:
            label = identity_label
        cv2.putText(
            image,
            label,
            (x1, max(28, y1 - 8)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.72,
            color,
            2,
            cv2.LINE_AA,
        )
        keypoints = np.asarray(track.keypoints)
        if keypoints.shape == (17, 3):
            for x, y, confidence in keypoints:
                if confidence >= keypoint_confidence:
                    cv2.circle(image, (int(x), int(y)), 4, (255, 0, 255), -1)
            for start, end in SKELETON:
                first = keypoints[start]
                second = keypoints[end]
                if first[2] >= keypoint_confidence and second[2] >= keypoint_confidence:
                    cv2.line(
                        image,
                        (int(first[0]), int(first[1])),
                        (int(second[0]), int(second[1])),
                        (255, 80, 0),
                        2,
                    )

    def _draw_overlay(self, frame: np.ndarray) -> np.ndarray:
        result = frame.copy()
        height, width = result.shape[:2]
        status_by_workstation = {
            status.workstation_id: status for status in self.latest_region_status
        }
        colors = {
            "PRESENT": (0, 210, 0),
            "WAITING": (0, 220, 255),
            "GRACE": (0, 220, 255),
            "AWAY": (0, 150, 255),
            "ALERT": (0, 0, 255),
            "CAMERA_OFFLINE": (100, 100, 100),
            "UNCONFIGURED": (180, 180, 180),
        }
        for workstation in self.database.list_workstations(include_disabled=False):
            if str(workstation.get("camera_device")) != str(self.camera.active_device):
                continue
            roi = workstation["roi"]
            if len(roi) < 3:
                continue
            contour = denormalize_polygon(roi, width, height).reshape(-1, 1, 2)
            status = status_by_workstation.get(int(workstation["id"]))
            state = status.state if status else "UNASSIGNED"
            color = colors.get(state, (170, 170, 170))
            cv2.polylines(result, [contour], True, color, 4)
            x, y = contour[0, 0]
            text = f"{workstation['name']} {state}"
            if status and status.elapsed_shortage_sec:
                text += f" shortage={status.elapsed_shortage_sec}s {status.present_count}/{status.required_count}"
            cv2.putText(
                result,
                text,
                (int(x), max(35, int(y) - 10)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                color,
                3,
                cv2.LINE_AA,
            )

        keypoint_confidence = (
            self.models.pose.keypoint_confidence if self.models.pose else 0.35
        )
        fall_by_track = {item.track_id: item for item in self.latest_fall_status}
        for track in self.latest_tracks:
            self._draw_track(
                result,
                track,
                self.latest_bindings.get(track.track_id),
                keypoint_confidence,
                fall_by_track.get(track.track_id),
            )
            anchor = self.presence.anchor(track)
            cv2.circle(result, (int(anchor[0]), int(anchor[1])), 7, (255, 255, 0), -1)

        for face in self.latest_faces:
            x1, y1, x2, y2 = np.round(face.bbox).astype(int)
            cv2.rectangle(result, (x1, y1), (x2, y2), (0, 0, 255), 2)
            for x, y in face.landmarks:
                cv2.circle(result, (int(x), int(y)), 3, (255, 255, 0), -1)

        # 盗窃模块默认只绘制 Shoplifting 类，避免 normal 框覆盖画面。
        alarm_conf = float(self.theft_manager.alarm_confidence)
        for detection in self.latest_theft_detections:
            if int(detection.class_id) != int(self.theft_manager.alarm_class_id):
                continue
            if float(detection.score) < alarm_conf:
                continue
            x1, y1, x2, y2 = np.round(detection.bbox).astype(int)
            theft_color = (0, 0, 255) if self.latest_theft_status.state == "ALERT" else (0, 165, 255)
            cv2.rectangle(result, (x1, y1), (x2, y2), theft_color, 4)
            cv2.putText(
                result,
                f"SHOPLIFTING {float(detection.score):.2f} {self.latest_theft_status.state}",
                (x1, max(30, y1 - 10)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.78,
                theft_color,
                2,
                cv2.LINE_AA,
            )
        return result

    @staticmethod
    def _resize_preview(frame: np.ndarray, maximum_width: int = 1280) -> np.ndarray:
        if frame.shape[1] <= maximum_width:
            return frame
        height = int(frame.shape[0] * maximum_width / frame.shape[1])
        return cv2.resize(frame, (maximum_width, height), interpolation=cv2.INTER_AREA)

    @staticmethod
    def _encode(frame: np.ndarray, quality: int) -> bytes:
        success, encoded = cv2.imencode(
            ".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, int(quality)]
        )
        if not success:
            raise RuntimeError("JPEG编码失败")
        return encoded.tobytes()

    @staticmethod
    def _event_rate(values) -> float:
        items = list(values)
        if len(items) < 2 or items[-1] <= items[0]:
            return 0.0
        return round((len(items) - 1) / (items[-1] - items[0]), 3)

    def run(self) -> None:
        pose_interval = 1.0 / max(float(self.runtime_config.get("pose_fps", 10)), 0.1)
        face_interval = 1.0 / max(float(self.runtime_config.get("face_fps", 3)), 0.1)
        theft_interval = 1.0 / max(float(self.runtime_config.get("theft_fps", 4)), 0.1)
        preview_interval = 1.0 / max(
            float(self.runtime_config.get("preview_fps", 10)), 0.1
        )
        business_interval = 1.0 / max(
            float(self.runtime_config.get("business_fps", 10)), 0.1
        )
        status_interval = 1.0 / max(
            float(self.runtime_config.get("status_fps", 5)), 0.1
        )
        max_faces = int(self.runtime_config.get("max_faces_per_cycle", 4))
        next_pose = next_face = next_theft = next_preview = next_business = next_status = 0.0
        last_sequence = -1
        last_device = None
        pose_ms = face_detector_ms = recognition_ms = fall_ms = 0.0
        theft_pre_ms = theft_npu_ms = theft_post_ms = theft_pipeline_ms = 0.0

        if not self.preview_encoder.is_alive():
            self.preview_encoder.start()
        if self.pose_worker is not None and not self.pose_worker.is_alive():
            self.pose_worker.start()
        if self.theft_worker is not None and not self.theft_worker.is_alive():
            self.theft_worker.start()

        try:
            while not self.stop_event.is_set():
                active_device = self.camera.active_device
                if active_device != last_device:
                    last_sequence = -1
                    last_device = active_device
                    self.latest_tracks = []
                    self.latest_faces = []
                    self.latest_bindings = {}
                    self.latest_fall_status = []
                    self.latest_theft_detections = []
                    self.latest_theft_status = self.theft_manager.latest()
                    self.tracker.tracks.clear()

                frame, sequence, frame_timestamp = self.camera.frames.latest(copy=False)
                if frame is None:
                    # 即使该路摄像头掉线，也持续刷新绑定到本摄像头的业务状态；
                    # PresenceManager在不可观测时会暂停计时，不会误报离岗。
                    width = int(self.camera.config.get("width", 1920))
                    height = int(self.camera.config.get("height", 1080))
                    self.latest_shift_status, self.latest_region_status = self.presence.evaluate(
                        frame=None,
                        frame_width=width,
                        frame_height=height,
                        tracks=[],
                        bindings={},
                        camera_online=False,
                        active_camera_device=self.camera.active_device,
                    )
                    self._set_status(
                        {
                            "state": "waiting_camera",
                            "camera_id": self.camera_id,
                            "camera_name": self.camera_name,
                            "camera_location": self.camera_location,
                            "camera": self.camera.status(),
                            "models": {"error": self.error},
                            "performance": {
                                "pose_ms": round(pose_ms, 2),
                                "retinaface_ms": round(face_detector_ms, 2),
                                "recognition_ms": round(recognition_ms, 2),
                                "fall_rule_ms": round(fall_ms, 3),
                                "theft_pre_ms": round(theft_pre_ms, 3),
                                "theft_npu_ms": round(theft_npu_ms, 3),
                                "theft_post_ms": round(theft_post_ms, 3),
                                "theft_pipeline_ms": round(theft_pipeline_ms, 3),
                                "camera_loop_fps": self._event_rate(self._frame_times),
                                "pose_actual_fps": self._event_rate(self._pose_times),
                                "face_actual_fps": self._event_rate(self._face_times),
                                "theft_actual_fps": self._event_rate(self._theft_times),
                                "preview_actual_fps": self.preview_encoder.metrics().get("actual_fps", 0.0),
                                "preview_encode_ms": self.preview_encoder.metrics().get("annotated_encode_avg_ms", 0.0),
                                "preview_frame_age_ms": self.preview_encoder.metrics().get("frame_age_avg_ms", 0.0),
                                "preview_dropped": self.preview_encoder.metrics().get("dropped", 0),
                                "pose_queue_frame_age_ms": self.pose_worker.metrics().get("frame_age_avg_ms", 0.0) if self.pose_worker else 0.0,
                                "pose_lock_wait_ms": self.pose_worker.metrics().get("lock_wait_avg_ms", 0.0) if self.pose_worker else 0.0,
                                "pose_dropped": self.pose_worker.metrics().get("dropped", 0) if self.pose_worker else 0,
                                "theft_queue_frame_age_ms": self.theft_worker.metrics().get("frame_age_avg_ms", 0.0) if self.theft_worker else 0.0,
                                "theft_lock_wait_ms": self.theft_worker.metrics().get("lock_wait_avg_ms", 0.0) if self.theft_worker else 0.0,
                                "theft_dropped": self.theft_worker.metrics().get("dropped", 0) if self.theft_worker else 0,
                                "runtime_uptime_sec": round(time.monotonic() - self._runtime_started, 1),
                                "preview_encoder": self.preview_encoder.metrics(),
                                "pose_worker": self.pose_worker.metrics() if self.pose_worker else {},
                                "theft_worker": self.theft_worker.metrics() if self.theft_worker else {},
                            },
                            "identity": {
                                "profile_count": self.identity.profile_count,
                                "binding_count": len(self.latest_bindings),
                                "similarity_threshold": self.identity.similarity_threshold,
                            },
                            "tracks": [],
                            "shifts": [asdict(item) for item in self.latest_shift_status],
                            "regions": [asdict(item) for item in self.latest_region_status],
                            "falls": self.fall_detector.serialize(self.latest_fall_status),
                            "fall_summary": {
                                "enabled": self.fall_detector.enabled,
                                "suspected": 0,
                                "fallen": 0,
                                "recovering": 0,
                            },
                            "theft": self.theft_manager.serialize(),
                            "theft_summary": {
                                "enabled": self.theft_manager.enabled,
                                "suspected": 1 if self.latest_theft_status.state == "SUSPECTED" else 0,
                                "alerts": 1 if self.latest_theft_status.state == "ALERT" else 0,
                            },
                        }
                    )
                    time.sleep(0.05)
                    continue
                if sequence == last_sequence:
                    time.sleep(0.003)
                    continue
                last_sequence = sequence
                now = time.monotonic()
                self._frame_times.append(now)
                self._latest_frame_shape = frame.shape[:2]
                pose_updated = False

                if self.pause_event.is_set():
                    if now >= next_preview:
                        raw = self._resize_preview(frame, self.preview_width)
                        # 暂停检测时仍保持同端口实时画面在线，不运行NPU。
                        self.preview_encoder.submit(raw.copy(), raw, float(frame_timestamp))
                        next_preview = now + preview_interval
                    paused_status = self.status()
                    paused_status.update({
                        "state": "paused",
                        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "camera": self.camera.status(),
                    })
                    self._set_status(paused_status)
                    time.sleep(0.005)
                    continue

                # 预览优先：先把当前最新帧交给JPEG线程，再调度AI。
                # 这样即使NPU/人脸推理有抖动，网页也不会排队等待旧帧。
                if now >= next_preview:
                    annotated = self._resize_preview(self._draw_overlay(frame), self.preview_width)
                    raw = self._resize_preview(frame, self.preview_width)
                    self.preview_encoder.submit(annotated, raw, float(frame_timestamp))
                    next_preview = now + preview_interval

                if self.pose_worker is not None and now >= next_pose:
                    self.pose_worker.submit({"frame": frame, "capture_ts": float(frame_timestamp)})
                    next_pose = now + pose_interval

                pose_result = self._pop_pose_result()
                pose_frame = frame
                pose_timestamp = now
                if pose_result is not None:
                    self.latest_tracks = self.tracker.update(pose_result.get("detections") or [])
                    pose_ms = float(pose_result.get("inference_ms", 0.0))
                    pose_updated = True
                    pose_frame = pose_result.get("frame") if pose_result.get("frame") is not None else frame
                    pose_timestamp = float(pose_result.get("capture_ts") or now)
                    self._pose_times.append(float(pose_result.get("completed_at") or now))

                if self.models.face_detector is not None and now >= next_face:
                    with self.models.face_lock:
                        self.latest_faces, face_detector_ms = (
                            self.models.face_detector.infer(frame)
                        )
                        self.latest_bindings, recognition_ms = self.identity.update(
                            frame,
                            self.latest_faces,
                            self.latest_tracks,
                            max_faces=max_faces,
                        )
                    self._face_times.append(now)
                    next_face = now + face_interval

                if self.theft_worker is not None and now >= next_theft:
                    self.theft_worker.submit(
                        {
                            "frame": frame,
                            "capture_ts": float(frame_timestamp),
                            "tracks": self._clone_tracks(self.latest_tracks),
                            "bindings": dict(self.latest_bindings),
                            "camera_device": str(self.camera.active_device),
                        }
                    )
                    next_theft = now + theft_interval

                # Core1 推理在后台线程执行；这里只消费已经完成的最新结果，绝不等待NPU。
                theft_result = self._pop_theft_result()
                if theft_result is not None:
                    self.latest_theft_detections = theft_result.get("detections") or []
                    theft_timing = theft_result.get("timing") or {}
                    theft_pre_ms = float(theft_timing.get("pre_ms", 0.0))
                    theft_npu_ms = float(theft_timing.get("npu_ms", 0.0))
                    theft_post_ms = float(theft_timing.get("post_ms", 0.0))
                    theft_pipeline_ms = float(theft_timing.get("pipeline_ms", 0.0))
                    self.latest_theft_status = self.theft_manager.update(
                        frame=theft_result["frame"],
                        detections=self.latest_theft_detections,
                        tracks=theft_result.get("tracks") or [],
                        bindings=theft_result.get("bindings") or {},
                        camera_device=str(theft_result.get("camera_device") or self.camera.active_device),
                        now_monotonic=float(theft_result.get("capture_ts") or now),
                    )
                    self._theft_times.append(time.monotonic())

                height, width = frame.shape[:2]
                if pose_updated:
                    fall_started = time.perf_counter()
                    pose_height = int(pose_frame.shape[0])
                    self.latest_fall_status = self.fall_detector.update(
                        frame=pose_frame,
                        tracks=self.latest_tracks,
                        bindings=self.latest_bindings,
                        frame_height=pose_height,
                        camera_device=str(self.camera.active_device),
                        now_monotonic=pose_timestamp,
                    )
                    fall_ms = (time.perf_counter() - fall_started) * 1000.0

                if pose_updated or now >= next_business:
                    self.latest_shift_status, self.latest_region_status = self.presence.evaluate(
                        frame=frame,
                        frame_width=width,
                        frame_height=height,
                        tracks=self.latest_tracks,
                        bindings=self.latest_bindings,
                        camera_online=self.camera.online,
                        active_camera_device=self.camera.active_device,
                    )
                    next_business = now + business_interval

                if now >= next_status:
                    self._set_status(
                        {
                            "state": "running",
                            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "camera_id": self.camera_id,
                            "camera_name": self.camera_name,
                            "camera_location": self.camera_location,
                            "camera": self.camera.status(),
                            "performance": {
                                "pose_ms": round(pose_ms, 2),
                                "retinaface_ms": round(face_detector_ms, 2),
                                "recognition_ms": round(recognition_ms, 2),
                                "fall_rule_ms": round(fall_ms, 3),
                                "theft_pre_ms": round(theft_pre_ms, 3),
                                "theft_npu_ms": round(theft_npu_ms, 3),
                                "theft_post_ms": round(theft_post_ms, 3),
                                "theft_pipeline_ms": round(theft_pipeline_ms, 3),
                                "camera_loop_fps": self._event_rate(self._frame_times),
                                "pose_actual_fps": self._event_rate(self._pose_times),
                                "face_actual_fps": self._event_rate(self._face_times),
                                "theft_actual_fps": self._event_rate(self._theft_times),
                                "preview_actual_fps": self.preview_encoder.metrics().get("actual_fps", 0.0),
                                "preview_encode_ms": self.preview_encoder.metrics().get("annotated_encode_avg_ms", 0.0),
                                "preview_frame_age_ms": self.preview_encoder.metrics().get("frame_age_avg_ms", 0.0),
                                "preview_dropped": self.preview_encoder.metrics().get("dropped", 0),
                                "pose_queue_frame_age_ms": self.pose_worker.metrics().get("frame_age_avg_ms", 0.0) if self.pose_worker else 0.0,
                                "pose_lock_wait_ms": self.pose_worker.metrics().get("lock_wait_avg_ms", 0.0) if self.pose_worker else 0.0,
                                "pose_dropped": self.pose_worker.metrics().get("dropped", 0) if self.pose_worker else 0,
                                "theft_queue_frame_age_ms": self.theft_worker.metrics().get("frame_age_avg_ms", 0.0) if self.theft_worker else 0.0,
                                "theft_lock_wait_ms": self.theft_worker.metrics().get("lock_wait_avg_ms", 0.0) if self.theft_worker else 0.0,
                                "theft_dropped": self.theft_worker.metrics().get("dropped", 0) if self.theft_worker else 0,
                                "runtime_uptime_sec": round(now - self._runtime_started, 1),
                                "preview_encoder": self.preview_encoder.metrics(),
                                "pose_worker": self.pose_worker.metrics() if self.pose_worker else {},
                                "theft_worker": self.theft_worker.metrics() if self.theft_worker else {},
                            },
                            "npu": self.models.metrics(),
                            "model_paths": {
                                "pose": str(self.models.pose.backend.path)
                                if self.models.pose
                                else None,
                                "theft": str(self.models.theft.backend.path)
                                if self.models.theft
                                else None,
                                "retinaface": str(self.models.face_detector.backend.path)
                                if self.models.face_detector
                                else None,
                                "recognition": str(self.models.face_recognizer.backend.path)
                                if self.models.face_recognizer
                                else None,
                            },
                            "identity": {
                                "profile_count": self.identity.profile_count,
                                "binding_count": len(self.latest_bindings),
                                "similarity_threshold": self.identity.similarity_threshold,
                            },
                            "tracks": [
                                {
                                    "track_id": track.track_id,
                                    "camera_id": self.camera_id,
                                    "camera_device": self.camera.active_device,
                                    "camera_name": self.camera_name,
                                    "camera_location": self.camera_location,
                                    "bbox": [round(float(value), 1) for value in track.bbox],
                                    "score": round(track.score, 3),
                                    "anchor": [
                                        round(value, 1) for value in self.presence.anchor(track)
                                    ],
                                    "fall": (
                                        asdict(next(
                                            item for item in self.latest_fall_status
                                            if item.track_id == track.track_id
                                        ))
                                        if any(
                                            item.track_id == track.track_id
                                            for item in self.latest_fall_status
                                        )
                                        else None
                                    ),
                                    "identity": (
                                        {
                                            "employee_id": self.latest_bindings[
                                                track.track_id
                                            ].employee_id,
                                            "employee_code": self.latest_bindings[
                                                track.track_id
                                            ].employee_code,
                                            "employee_name": self.latest_bindings[
                                                track.track_id
                                            ].employee_name,
                                            "similarity": round(
                                                self.latest_bindings[
                                                    track.track_id
                                                ].similarity,
                                                4,
                                            ),
                                            "last_recognized_at": self.latest_bindings[
                                                track.track_id
                                            ].last_recognized_at,
                                        }
                                        if track.track_id in self.latest_bindings
                                        else None
                                    ),
                                }
                                for track in self.latest_tracks
                            ],
                            "falls": self.fall_detector.serialize(self.latest_fall_status),
                            "fall_summary": {
                                "enabled": self.fall_detector.enabled,
                                "suspected": sum(1 for item in self.latest_fall_status if item.state == "SUSPECTED"),
                                "fallen": sum(1 for item in self.latest_fall_status if item.state == "FALLEN"),
                                "recovering": sum(1 for item in self.latest_fall_status if item.state == "RECOVERING"),
                            },
                            "theft": self.theft_manager.serialize(),
                            "theft_summary": {
                                "enabled": self.theft_manager.enabled,
                                "suspected": 1 if self.latest_theft_status.state == "SUSPECTED" else 0,
                                "alerts": 1 if self.latest_theft_status.state == "ALERT" else 0,
                            },
                            "shifts": [asdict(item) for item in self.latest_shift_status],
                            "regions": [asdict(item) for item in self.latest_region_status],
                        }
                    )
                    next_status = now + status_interval
        except Exception as exc:
            self.error = f"RuntimeService失败：{type(exc).__name__}: {exc}"
            self._set_status({
                "state": "error",
                "camera_id": self.camera_id,
                "camera_name": self.camera_name,
                "camera_location": self.camera_location,
                "camera": self.camera.status(),
                "error": self.error,
            })
            print(self.error)
            self.stop_event.set()
        finally:
            self.preview_encoder.stop()
            if self.pose_worker is not None:
                self.pose_worker.stop()
            if self.theft_worker is not None:
                self.theft_worker.stop()
            if self.preview_encoder.is_alive():
                self.preview_encoder.join(timeout=2.0)
            if self.pose_worker is not None and self.pose_worker.is_alive():
                self.pose_worker.join(timeout=2.0)
            if self.theft_worker is not None and self.theft_worker.is_alive():
                self.theft_worker.join(timeout=2.0)
            try:
                self.fall_detector.close_all(reason="SERVICE_STOPPED")
            except Exception as close_exc:
                print(f"关闭摔倒事件失败：{type(close_exc).__name__}: {close_exc}")
            try:
                self.theft_manager.close_open_event(reason="SERVICE_STOPPED")
            except Exception as close_exc:
                print(f"关闭盗窃事件失败：{type(close_exc).__name__}: {close_exc}")
