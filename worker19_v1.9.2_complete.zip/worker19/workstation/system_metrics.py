from __future__ import annotations

import importlib
import importlib.metadata
import re
import shutil
import subprocess
import threading
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


_VERSION_PATTERN = re.compile(r"librknnrt\s+version:\s*([^\r\n]+)", re.IGNORECASE)
_DRIVER_PATTERN = re.compile(r"(?:driver\s*)?(?:version|ver|v)\s*[:=]?\s*v?([0-9]+(?:\.[0-9A-Za-z_-]+)+)", re.IGNORECASE)


def _read_first(paths: Iterable[Path]) -> Optional[str]:
    for path in paths:
        try:
            if path.is_file():
                value = path.read_text(encoding="utf-8", errors="ignore").strip()
                if value:
                    return value
        except OSError:
            continue
    return None


def detect_toolkit_lite_version() -> Optional[str]:
    """读取当前 Python 环境中实际安装的 RKNN Lite 包版本。"""
    for distribution in (
        "rknn-toolkit-lite2",
        "rknn_toolkit_lite2",
        "rknnlite",
    ):
        try:
            value = importlib.metadata.version(distribution)
            if value:
                return str(value)
        except importlib.metadata.PackageNotFoundError:
            pass
        except Exception:
            pass
    try:
        module = importlib.import_module("rknnlite")
        value = getattr(module, "__version__", None)
        return str(value) if value else None
    except Exception:
        return None


def loaded_runtime_libraries() -> List[str]:
    """只报告当前进程真实 mmap 的 librknnrt.so 路径。"""
    paths = set()
    try:
        for line in Path("/proc/self/maps").read_text(encoding="utf-8", errors="ignore").splitlines():
            if "librknnrt.so" not in line:
                continue
            candidate = line.rsplit(None, 1)[-1]
            if candidate.startswith("/"):
                paths.add(candidate.replace(" (deleted)", ""))
    except OSError:
        pass
    return sorted(paths)


def _strings(path: str) -> str:
    executable = shutil.which("strings")
    if executable:
        try:
            result = subprocess.run(
                [executable, path],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                timeout=3,
                check=False,
            )
            if result.stdout:
                return result.stdout
        except Exception:
            pass
    # Buildroot 极简系统可能没有 strings；直接按二进制中的可打印区域匹配。
    try:
        raw = Path(path).read_bytes()
    except OSError:
        return ""
    match = re.search(rb"librknnrt version:[^\x00\r\n]{1,200}", raw, re.IGNORECASE)
    return match.group(0).decode("utf-8", errors="ignore") if match else ""


def detect_loaded_runtime_version(paths: Optional[Iterable[str]] = None) -> Dict[str, Any]:
    libraries = list(paths if paths is not None else loaded_runtime_libraries())
    for library in libraries:
        text = _strings(library)
        match = _VERSION_PATTERN.search(text)
        if not match:
            continue
        detail = match.group(1).strip()
        version_match = re.match(r"([0-9]+(?:\.[0-9A-Za-z_-]+)+)", detail)
        version = version_match.group(1) if version_match else detail
        return {
            "version": version,
            "detail": detail,
            "library": library,
            "source": "loaded_librknnrt",
        }
    return {
        "version": None,
        "detail": None,
        "library": libraries[0] if libraries else None,
        "source": "unavailable",
    }


def detect_driver_version() -> Dict[str, Any]:
    candidates = [
        Path("/sys/kernel/debug/rknpu/version"),
        Path("/sys/kernel/debug/rknpu/driver_version"),
        Path("/sys/module/rknpu/version"),
        Path("/sys/module/rknpu/parameters/version"),
    ]
    for path in candidates:
        try:
            if not path.is_file():
                continue
            raw = path.read_text(encoding="utf-8", errors="ignore").strip()
            if not raw:
                continue
            match = _DRIVER_PATTERN.search(raw)
            version = match.group(1) if match else raw
            return {"version": version, "raw": raw, "source": str(path)}
        except OSError:
            continue
    return {"version": None, "raw": None, "source": "unavailable"}


class RKNNSystemProbe:
    """采集 RK3588 当前进程/内核真实状态，不使用配置文件伪造版本号。"""

    def __init__(self, static_cache_sec: float = 5.0) -> None:
        self.static_cache_sec = max(0.5, float(static_cache_sec))
        self._lock = threading.RLock()
        self._cached_at = 0.0
        self._static: Dict[str, Any] = {}

    def _static_info(self) -> Dict[str, Any]:
        now = time.monotonic()
        with self._lock:
            if self._static and now - self._cached_at < self.static_cache_sec:
                return dict(self._static)
        libraries = loaded_runtime_libraries()
        runtime = detect_loaded_runtime_version(libraries)
        driver = detect_driver_version()
        value = {
            "toolkit_lite_version": detect_toolkit_lite_version(),
            "runtime_version": runtime.get("version"),
            "runtime_version_detail": runtime.get("detail"),
            "runtime_library": runtime.get("library"),
            "runtime_libraries": libraries,
            "runtime_version_source": runtime.get("source"),
            "driver_version": driver.get("version"),
            "driver_version_raw": driver.get("raw"),
            "driver_version_source": driver.get("source"),
        }
        with self._lock:
            self._static = dict(value)
            self._cached_at = now
        return value

    def probe(self) -> Dict[str, Any]:
        value = self._static_info()
        load_text = _read_first(
            [Path("/sys/kernel/debug/rknpu/load"), Path("/sys/kernel/debug/rknpu/load_info")]
        )
        freq_paths = sorted(Path("/sys/class/devfreq").glob("*npu*/cur_freq"))
        freq_text = _read_first(freq_paths)
        governor_paths = sorted(Path("/sys/class/devfreq").glob("*npu*/governor"))
        governor = _read_first(governor_paths)
        value.update(
            {
                "npu_load_raw": load_text,
                "npu_frequency_hz": int(freq_text) if freq_text and freq_text.isdigit() else None,
                "npu_frequency_source": str(freq_paths[0]) if freq_paths and freq_text else None,
                "npu_governor": governor,
            }
        )
        return value
