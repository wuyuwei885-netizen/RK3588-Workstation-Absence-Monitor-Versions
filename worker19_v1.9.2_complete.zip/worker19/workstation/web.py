from __future__ import annotations

import asyncio
import csv
import io
import shutil
import threading
import time
from pathlib import Path
from urllib.parse import urlencode
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile, WebSocket
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from .multicamera import MultiCameraManager
from .config import AppConfig
from .database import Database
from .enrollment import EnrollmentService, SLOT_LABELS
from .models import ModelHub
from .control import DeviceInspector
from .evaluation import load_model_evaluation
from .runtime import JPEGStore
from .multiruntime import MultiCameraRuntime


class AlertBus:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._revision = 0
        self._latest: Optional[Dict[str, Any]] = None

    def publish(self, event: Dict[str, Any]) -> None:
        with self._lock:
            self._revision += 1
            self._latest = dict(event)

    def latest(self) -> tuple[int, Optional[Dict[str, Any]]]:
        with self._lock:
            return self._revision, dict(self._latest) if self._latest else None


def mjpeg_response(store: JPEGStore) -> StreamingResponse:
    def generator():
        version = -1
        while True:
            jpeg, current_version = store.wait(version, timeout=2.0)
            if jpeg is None or current_version == version:
                continue
            version = current_version
            yield (
                b"--frame\r\n"
                b"Content-Type: image/jpeg\r\n"
                + f"Content-Length: {len(jpeg)}\r\n\r\n".encode("ascii")
                + jpeg
                + b"\r\n"
            )

    return StreamingResponse(
        generator(),
        media_type="multipart/x-mixed-replace; boundary=frame",
        headers={"Cache-Control": "no-store, no-cache, must-revalidate, max-age=0", "Pragma": "no-cache", "Expires": "0", "X-Accel-Buffering": "no"},
    )


def _safe_unlink(path_value: Optional[str], allowed_root: Path) -> bool:
    """只删除allowed_root目录内的普通文件。"""
    if not path_value:
        return False
    try:
        path = Path(path_value).resolve()
        root = allowed_root.resolve()
        path.relative_to(root)
    except Exception:
        return False
    try:
        if path.is_file():
            path.unlink()
            return True
    except OSError:
        return False
    return False


def _event_media_url(path: Optional[str], event_dir: Path) -> Optional[str]:
    if not path:
        return None
    try:
        relative = Path(path).resolve().relative_to(event_dir.resolve())
    except Exception:
        return None
    return "/media/events/" + "/".join(relative.parts)


def _optional_query_int(value: Optional[str], field_label: str) -> Optional[int]:
    """把查询参数中的空字符串转换为None，并校验非空ID。

    HTML <select> 的“全部”选项会提交 employee_id= 或 workstation_id=。
    如果路由参数直接声明为 Optional[int]，FastAPI 会在进入路由前返回422。
    """
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = int(text)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=f"{field_label}必须是整数") from exc
    if parsed <= 0:
        raise HTTPException(status_code=400, detail=f"{field_label}必须大于0")
    return parsed


def _clean_query_text(value: Optional[str]) -> Optional[str]:
    text = str(value or "").strip()
    return text or None


def _template_response(
    templates: Jinja2Templates,
    request: Request,
    name: str,
    context: Optional[Dict[str, Any]] = None,
):
    """
    同时兼容新旧 Starlette/Jinja2Templates.TemplateResponse 参数签名。

    新版：
        TemplateResponse(request=request, name=name, context=context)

    旧版：
        TemplateResponse(name, context)
    """
    template_context: Dict[str, Any] = dict(context or {})
    template_context["request"] = request

    try:
        return templates.TemplateResponse(
            request=request,
            name=name,
            context=template_context,
        )
    except TypeError as exc:
        message = str(exc)
        if (
            "unexpected keyword argument" not in message
            and "multiple values" not in message
        ):
            raise
        return templates.TemplateResponse(
            name,
            template_context,
        )


def create_app(
    *,
    config: AppConfig,
    camera: MultiCameraManager,
    models: ModelHub,
    database: Database,
    enrollment: EnrollmentService,
    runtime: MultiCameraRuntime,
    alerts: AlertBus,
) -> FastAPI:
    root = Path(__file__).resolve().parent.parent
    templates = Jinja2Templates(directory=str(root / "templates"))
    app = FastAPI(title="RK3588工作台人员异常检测系统 v1.9.1")
    app.mount("/static", StaticFiles(directory=str(root / "static")), name="static")
    app.mount(
        "/media/enrollment",
        StaticFiles(directory=config.app["enrollment_dir"]),
        name="enrollment-media",
    )
    app.mount(
        "/media/events",
        StaticFiles(directory=config.app["event_dir"]),
        name="event-media",
    )
    control_inspector = DeviceInspector(
        database_path=config.app["database"],
        main_port=int(config.app["port"]),
        control_port=int(config.app["port"]),
        main_service=str(config.control.get("main_service", "workstation-absence.service")),
        camera_device=str(config.camera["device"]),
        status_timeout_sec=float(config.control.get("status_timeout_sec", 1.2)),
    )

    @app.on_event("startup")
    async def startup() -> None:
        saved_device = database.get_setting("active_camera_device")
        if saved_device:
            try:
                camera.switch(saved_device)
            except Exception:
                pass
        camera.start()
        if not runtime.is_alive():
            runtime.start()

    @app.on_event("shutdown")
    async def shutdown() -> None:
        runtime.stop()
        camera.stop()
        runtime.join(timeout=5)
        models.close()

    @app.get("/", include_in_schema=False)
    async def root_redirect():
        return RedirectResponse("/monitor", status_code=302)

    @app.get("/control", response_class=HTMLResponse)
    async def control_page(request: Request):
        status = control_inspector.collect(main_status_override=runtime.status())
        return _template_response(
            templates, request, "control_dashboard.html",
            {"status": status, "main_port": int(config.app["port"]), "same_port": True},
        )

    @app.get("/api/control/status")
    async def control_status():
        return JSONResponse(control_inspector.collect(main_status_override=runtime.status()))

    @app.post("/api/control/action/{action}")
    async def control_action(action: str):
        normalized = action.strip().lower()
        try:
            if normalized == "start":
                runtime.resume()
                return JSONResponse({"ok": True, "action": "resume", "detail": f"检测已继续；端口{config.app['port']}保持在线"})
            if normalized == "stop":
                runtime.pause()
                return JSONResponse({"ok": True, "action": "pause", "detail": f"检测已暂停；端口{config.app['port']}保持在线"})
            if normalized == "restart":
                def delayed_restart() -> None:
                    time.sleep(0.8)
                    control_inspector.controller.service_action("restart")
                threading.Thread(target=delayed_restart, daemon=True).start()
                return JSONResponse({"ok": True, "action": "restart", "scheduled": True})
            if normalized in {"reboot", "poweroff"}:
                def delayed_device_action() -> None:
                    time.sleep(0.8)
                    control_inspector.controller.device_action(normalized)
                threading.Thread(target=delayed_device_action, daemon=True).start()
                return JSONResponse({"ok": True, "action": normalized, "scheduled": True})
            raise ValueError("未知控制操作")
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    @app.get("/employees", response_class=HTMLResponse)
    async def employees_page(request: Request):
        return _template_response(
            templates,
            request,
            "employees.html",
            {"employees": database.list_employees()},
        )

    @app.get("/employees/{employee_id}/enroll", response_class=HTMLResponse)
    async def enrollment_page(request: Request, employee_id: int):
        employee = database.get_employee(employee_id)
        if employee is None:
            raise HTTPException(status_code=404, detail="员工不存在")
        status = enrollment.enrollment_status(employee_id)
        samples = status["samples"]
        for sample in samples:
            filename = Path(sample["aligned_image_path"]).name
            sample["aligned_url"] = (
                f"/media/enrollment/{employee['employee_code']}/{filename}"
            )
        return _template_response(
            templates,
            request,
            "enrollment.html",
            {
                "employee": employee,
                "enrollment": status,
                "samples": samples,
                "slot_labels": SLOT_LABELS,
                "cameras": camera.configured(),
                "active_camera": camera.active_device,
            },
        )

    @app.get("/workstations", response_class=HTMLResponse)
    async def workstations_page(request: Request):
        return _template_response(
            templates,
            request,
            "workstations.html",
            {
                "workstations": database.list_workstations(),
                "cameras": camera.configured(),
                "active_camera": camera.active_device,
            },
        )

    @app.get("/schedule", response_class=HTMLResponse)
    async def schedule_page(request: Request):
        return _template_response(
            templates,
            request,
            "schedule.html",
            {
                "employees": database.list_employees(include_disabled=True),
                "workstations": database.list_workstations(include_disabled=False),
                "active_rounds": database.active_rounds(),
                "active_shifts": database.active_shifts(),
                "shift_history": database.list_shifts(100),
                "defaults": {
                    "mode": "single",
                    "minimum_staff": 1,
                    "first_arrival_wait_sec": 600,
                    "grace_sec": 5,
                    "away_threshold_sec": 180,
                    "return_confirm_sec": 2,
                },
            },
        )

    @app.get("/monitor", response_class=HTMLResponse)
    async def monitor_page(request: Request):
        return _template_response(
            templates,
            request,
            "monitor.html",
            {
                "active_shifts": database.active_shifts(),
                "cameras": camera.configured(),
            },
        )

    def _evaluation_payload() -> Dict[str, Any]:
        # 精度数据只从真实离线评测文件读取；文件不存在就返回 unavailable，不再网页手填/写死。
        return {
            "theft": load_model_evaluation(models.theft.backend.path)
            if models.theft
            else {"available": False, "message": "盗窃模型未启用"}
        }

    @app.get("/npu", response_class=HTMLResponse)
    async def npu_metrics_page(request: Request):
        return _template_response(
            templates, request, "npu_metrics.html", {"evaluations": _evaluation_payload()}
        )

    @app.get("/api/npu-metrics")
    async def api_npu_metrics():
        status = runtime.status()
        return JSONResponse(
            {
                "state": status.get("state"),
                "time": status.get("time"),
                "camera": status.get("camera", {}),
                "performance": status.get("performance", {}),
                "npu": status.get("npu", models.metrics()),
                "track_count": len(status.get("tracks", [])),
                "fall_summary": status.get("fall_summary", {}),
                "theft_summary": status.get("theft_summary", {}),
                "evaluations": _evaluation_payload(),
            }
        )

    @app.get("/history", response_class=HTMLResponse)
    async def history_page(
        request: Request,
        employee_id: Optional[str] = None,
        workstation_id: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        category: Optional[str] = None,
    ):
        # “全部员工/全部工作台”会提交空字符串；先按字符串接收，再统一转换。
        parsed_employee_id = _optional_query_int(employee_id, "员工ID")
        parsed_workstation_id = _optional_query_int(workstation_id, "工作台ID")
        cleaned_start_date = _clean_query_text(start_date)
        cleaned_end_date = _clean_query_text(end_date)
        cleaned_category = _clean_query_text(category) or "all"

        events = database.query_events(
            employee_id=parsed_employee_id,
            workstation_id=parsed_workstation_id,
            start_date=cleaned_start_date,
            end_date=cleaned_end_date,
            category=cleaned_category,
        )
        event_dir = Path(config.app["event_dir"])
        camera_by_device = {item["device"]: item for item in camera.configured()}
        for event in events:
            for field in ("leave_snapshot", "alert_snapshot", "return_snapshot"):
                event[field + "_url"] = _event_media_url(event.get(field), event_dir)
            source_camera = camera_by_device.get(str(event.get("camera_device")))
            event["camera_name"] = source_camera.get("name") if source_camera else None
            event["camera_location"] = source_camera.get("location") if source_camera else None

        export_params: Dict[str, str] = {"category": cleaned_category}
        if parsed_employee_id is not None:
            export_params["employee_id"] = str(parsed_employee_id)
        if parsed_workstation_id is not None:
            export_params["workstation_id"] = str(parsed_workstation_id)
        if cleaned_start_date:
            export_params["start_date"] = cleaned_start_date
        if cleaned_end_date:
            export_params["end_date"] = cleaned_end_date

        return _template_response(
            templates,
            request,
            "history.html",
            {
                "events": events,
                "employees": database.list_employees(),
                "workstations": database.list_workstations(),
                "export_url": "/api/events.csv?" + urlencode(export_params),
                "filters": {
                    "employee_id": parsed_employee_id,
                    "workstation_id": parsed_workstation_id,
                    "start_date": cleaned_start_date or "",
                    "end_date": cleaned_end_date or "",
                    "category": cleaned_category,
                },
            },
        )

    # Employee APIs
    @app.post("/api/employees")
    async def create_employee(request: Request):
        payload = await request.json()
        try:
            employee_id = database.create_employee(
                payload.get("employee_code", ""),
                payload.get("name", ""),
                payload.get("department", ""),
                payload.get("note", ""),
            )
            return {"ok": True, "employee_id": employee_id}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.put("/api/employees/{employee_id}")
    async def update_employee(employee_id: int, request: Request):
        payload = await request.json()
        try:
            database.update_employee(
                employee_id,
                employee_code=payload.get("employee_code", ""),
                name=payload.get("name", ""),
                department=payload.get("department", ""),
                note=payload.get("note", ""),
            )
            runtime.identity.reload_profiles()
            return {"ok": True}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.delete("/api/employees/{employee_id}")
    async def delete_employee(employee_id: int):
        employee = database.get_employee(employee_id)
        if employee is None:
            raise HTTPException(status_code=404, detail="员工不存在")

        try:
            deleted = database.delete_employee(employee_id)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        enrollment_root = Path(config.app["enrollment_dir"]).resolve()
        employee_dir = enrollment_root / str(employee["employee_code"])
        try:
            employee_dir.resolve().relative_to(enrollment_root)
            if employee_dir.is_dir():
                shutil.rmtree(employee_dir)
        except Exception:
            pass

        event_root = Path(config.app["event_dir"])
        removed_event_files = 0
        for event in deleted.get("events", []):
            for field in ("leave_snapshot", "alert_snapshot", "return_snapshot"):
                if _safe_unlink(event.get(field), event_root):
                    removed_event_files += 1

        runtime.identity.remove_employee(employee_id)
        runtime.latest_bindings = {
            track_id: binding
            for track_id, binding in runtime.latest_bindings.items()
            if int(binding.employee_id) != int(employee_id)
        }

        return {
            "ok": True,
            "employee_id": employee_id,
            "employee_code": employee["employee_code"],
            "deleted_samples": len(deleted.get("samples", [])),
            "deleted_shifts": len(deleted.get("shifts", [])),
            "deleted_events": len(deleted.get("events", [])),
            "deleted_event_files": removed_event_files,
        }

    @app.post("/api/employees/{employee_id}/enabled")
    async def toggle_employee(employee_id: int, request: Request):
        payload = await request.json()
        try:
            database.set_employee_enabled(employee_id, bool(payload.get("enabled")))
            runtime.identity.reload_profiles()
            return {"ok": True}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/employees/{employee_id}/capture")
    async def capture_employee(employee_id: int, request: Request):
        payload = await request.json()
        try:
            return enrollment.capture(employee_id, str(payload.get("slot_label", "")))
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/employees/{employee_id}/upload")
    async def upload_employee_photo(
        employee_id: int,
        slot_label: str = Form(...),
        file: UploadFile = File(...),
    ):
        try:
            return enrollment.upload(employee_id, slot_label, await file.read())
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.delete("/api/face-samples/{sample_id}")
    async def delete_face_sample(sample_id: int):
        try:
            sample = database.delete_face_sample(sample_id)
            if sample is None:
                raise HTTPException(status_code=404, detail="照片不存在")
            database.set_employee_enrolled(int(sample["employee_id"]), False)
            runtime.identity.reload_profiles()
            return {"ok": True}
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/employees/{employee_id}/regenerate")
    async def regenerate_profile(employee_id: int):
        try:
            result = enrollment.regenerate_profile(employee_id)
            runtime.identity.reload_profiles()
            return result
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/api/employees/{employee_id}/quality")
    async def employee_quality(employee_id: int):
        return enrollment.enrollment_status(employee_id)

    # Camera and workstation APIs
    @app.get("/api/cameras")
    async def list_cameras():
        return {
            "active": camera.active_device,
            "selected_id": camera.selected_id,
            "devices": camera.configured(),
        }

    @app.post("/api/cameras/select")
    async def select_camera(request: Request):
        payload = await request.json()
        device = str(payload.get("device", ""))
        try:
            camera.switch(device)
            database.set_setting("active_camera_device", device)
            return {"ok": True, "device": device}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/workstations")
    async def create_workstation(request: Request):
        payload = await request.json()
        try:
            workstation_id = database.create_workstation(
                name=payload.get("name", ""),
                camera_device=payload.get("camera_device", camera.active_device),
                away_threshold_sec=int(payload.get("away_threshold_sec", 180)),
                grace_sec=int(payload.get("grace_sec", 5)),
                return_confirm_sec=int(payload.get("return_confirm_sec", 2)),
            )
            return {"ok": True, "workstation_id": workstation_id}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.delete("/api/workstations/{workstation_id}/roi")
    async def clear_workstation_roi(workstation_id: int):
        try:
            database.clear_workstation_roi(workstation_id)
            return {"ok": True, "workstation_id": workstation_id, "roi": []}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.delete("/api/workstations/{workstation_id}")
    async def delete_workstation(workstation_id: int):
        try:
            deleted = database.delete_workstation(workstation_id)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        event_root = Path(config.app["event_dir"])
        removed_event_files = 0
        for event in deleted.get("events", []):
            for field in ("leave_snapshot", "alert_snapshot", "return_snapshot"):
                if _safe_unlink(event.get(field), event_root):
                    removed_event_files += 1

        return {
            "ok": True,
            "workstation_id": workstation_id,
            "workstation_name": deleted["workstation"]["name"],
            "deleted_shifts": len(deleted.get("shifts", [])),
            "deleted_events": len(deleted.get("events", [])),
            "deleted_event_files": removed_event_files,
        }

    @app.put("/api/workstations/{workstation_id}")
    async def update_workstation(workstation_id: int, request: Request):
        payload = await request.json()
        try:
            database.update_workstation(
                workstation_id,
                name=payload.get("name", ""),
                camera_device=payload.get("camera_device", camera.active_device),
                away_threshold_sec=int(payload.get("away_threshold_sec", 180)),
                grace_sec=int(payload.get("grace_sec", 5)),
                return_confirm_sec=int(payload.get("return_confirm_sec", 2)),
                enabled=bool(payload.get("enabled", True)),
            )
            return {"ok": True}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/workstations/{workstation_id}/roi")
    async def save_roi(workstation_id: int, request: Request):
        payload = await request.json()
        roi = payload.get("roi")
        if not isinstance(roi, list) or len(roi) < 3:
            raise HTTPException(status_code=400, detail="ROI至少需要3个点")
        for point in roi:
            if (
                not isinstance(point, list)
                or len(point) != 2
                or not 0 <= float(point[0]) <= 1
                or not 0 <= float(point[1]) <= 1
            ):
                raise HTTPException(status_code=400, detail="ROI必须为0~1归一化坐标")
        database.update_workstation_roi(workstation_id, roi)
        return {"ok": True, "roi": roi}

    @app.post("/api/workstations/{workstation_id}/test")
    async def test_workstation_draft(workstation_id: int, request: Request):
        payload = await request.json()
        roi = payload.get("roi")
        try:
            return runtime.test_workstation(workstation_id, roi_override=roi)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/api/workstations/{workstation_id}/test")
    async def test_workstation_saved(workstation_id: int):
        """兼容旧网页：测试数据库中已保存的ROI。"""
        try:
            return runtime.test_workstation(workstation_id)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    # Shift APIs
    @app.post("/api/shifts/start")
    async def start_shift(request: Request):
        payload = await request.json()
        try:
            employee_ids = payload.get("employee_ids")
            if employee_ids is None:
                legacy_employee = payload.get("employee_id")
                employee_ids = [legacy_employee] if legacy_employee is not None else []
            result = database.start_shift_batch(
                employee_ids=[int(value) for value in employee_ids],
                workstation_id=int(payload.get("workstation_id")),
                mode=str(payload.get("mode", "single")),
                minimum_staff=int(payload.get("minimum_staff", 1)),
                first_arrival_wait_sec=int(payload.get("first_arrival_wait_sec", 600)),
                grace_sec=int(payload.get("grace_sec", 5)),
                away_threshold_sec=int(payload.get("away_threshold_sec", 180)),
                return_confirm_sec=int(payload.get("return_confirm_sec", 2)),
            )
            return {"ok": True, **result}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/workstations/{workstation_id}/shifts/stop-all")
    async def stop_all_shifts(workstation_id: int):
        try:
            return {"ok": True, **database.stop_workstation_round(workstation_id)}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/shifts/{shift_id}/stop")
    async def stop_shift(shift_id: int):
        try:
            database.stop_shift(shift_id)
            return {"ok": True}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    # History deletion APIs. OPEN活动事件禁止删除，避免破坏正在运行的状态机。
    @app.delete("/api/events/{event_id}")
    async def delete_history_event(event_id: int):
        try:
            event = database.delete_event(event_id)
        except ValueError as exc:
            message = str(exc)
            status_code = 404 if "不存在" in message else 400
            raise HTTPException(status_code=status_code, detail=message) from exc
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        event_root = Path(config.app["event_dir"])
        removed_files = 0
        for field in ("leave_snapshot", "alert_snapshot", "return_snapshot"):
            if _safe_unlink(event.get(field), event_root):
                removed_files += 1
        return {"ok": True, "deleted_count": 1, "removed_files": removed_files}

    @app.delete("/api/events")
    async def delete_history_events(
        employee_id: Optional[str] = None,
        workstation_id: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        category: Optional[str] = None,
        confirm: Optional[str] = None,
    ):
        if str(confirm or "").strip().upper() != "DELETE":
            raise HTTPException(status_code=400, detail="批量删除必须提供 confirm=DELETE")

        parsed_employee_id = _optional_query_int(employee_id, "员工ID")
        parsed_workstation_id = _optional_query_int(workstation_id, "工作台ID")
        cleaned_start_date = _clean_query_text(start_date)
        cleaned_end_date = _clean_query_text(end_date)
        cleaned_category = _clean_query_text(category) or "all"

        try:
            result = database.delete_events(
                employee_id=parsed_employee_id,
                workstation_id=parsed_workstation_id,
                start_date=cleaned_start_date,
                end_date=cleaned_end_date,
                category=cleaned_category,
            )
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        event_root = Path(config.app["event_dir"])
        removed_files = 0
        for event in result.get("events", []):
            for field in ("leave_snapshot", "alert_snapshot", "return_snapshot"):
                if _safe_unlink(event.get(field), event_root):
                    removed_files += 1

        return {
            "ok": True,
            "deleted_count": int(result.get("deleted_count", 0)),
            "skipped_open": int(result.get("skipped_open", 0)),
            "removed_files": removed_files,
        }

    # Leave application / approval APIs. Only closed PERSONAL events are eligible.
    @app.post("/api/events/{event_id}/leave/apply")
    async def apply_leave(event_id: int, request: Request):
        payload = await request.json()
        try:
            event = database.apply_leave(event_id, str(payload.get("note", "")))
            return {"ok": True, "event": event}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.post("/api/events/{event_id}/leave/review")
    async def review_leave(event_id: int, request: Request):
        payload = await request.json()
        action = str(payload.get("action", "")).lower()
        if action not in {"approve", "reject"}:
            raise HTTPException(status_code=400, detail="action 必须为 approve 或 reject")
        try:
            event = database.review_leave(event_id, approved=action == "approve")
            return {"ok": True, "event": event}
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    # Runtime, media and export
    @app.get("/api/status")
    async def status():
        return JSONResponse(runtime.status())

    @app.get("/stream/monitor.mjpg")
    async def monitor_stream():
        # 兼容1.7旧地址：默认第一路摄像头。
        return mjpeg_response(runtime.annotated_store)

    @app.get("/stream/raw.mjpg")
    async def raw_stream():
        # 兼容1.7旧地址：默认第一路摄像头。
        return mjpeg_response(runtime.raw_store)

    @app.get("/stream/camera/{camera_id}/monitor.mjpg")
    async def camera_monitor_stream(camera_id: str):
        try:
            return mjpeg_response(runtime.store(camera_id, "annotated"))
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.get("/stream/camera/{camera_id}/raw.mjpg")
    async def camera_raw_stream(camera_id: str):
        try:
            return mjpeg_response(runtime.store(camera_id, "raw"))
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.get("/snapshot.jpg")
    async def snapshot(camera_id: Optional[str] = None):
        try:
            store = runtime.store(camera_id, "annotated") if camera_id else runtime.annotated_store
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        jpeg, _ = store.wait(-1, timeout=2.0)
        if jpeg is None:
            raise HTTPException(status_code=503, detail="尚无画面")
        return Response(jpeg, media_type="image/jpeg")

    @app.get("/api/events.csv")
    async def events_csv(
        employee_id: Optional[str] = None,
        workstation_id: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        category: Optional[str] = None,
    ):
        parsed_employee_id = _optional_query_int(employee_id, "员工ID")
        parsed_workstation_id = _optional_query_int(workstation_id, "工作台ID")
        cleaned_start_date = _clean_query_text(start_date)
        cleaned_end_date = _clean_query_text(end_date)
        cleaned_category = _clean_query_text(category) or "all"

        events = database.query_events(
            employee_id=parsed_employee_id,
            workstation_id=parsed_workstation_id,
            start_date=cleaned_start_date,
            end_date=cleaned_end_date,
            category=cleaned_category,
            limit=10000,
        )
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(
            [
                "事件ID",
                "记录分类",
                "事件类型",
                "关联事件ID",
                "员工ID",
                "员工姓名",
                "工作台",
                "Track ID",
                "摔倒最高评分",
                "摄像头",
                "离开/未到岗/疑似摔倒时间",
                "告警时间",
                "返回/结束时间",
                "持续时长(秒)",
                "事件状态",
                "请假状态",
                "请假备注",
                "离开截图",
                "告警截图",
                "返回截图",
            ]
        )
        for event in events:
            writer.writerow(
                [
                    event.get("id"),
                    event.get("history_category"),
                    event.get("event_name"),
                    event.get("incident_id"),
                    event.get("employee_code"),
                    event.get("employee_name"),
                    event.get("workstation_name"),
                    (event.get("metadata") or {}).get("track_id"),
                    (event.get("metadata") or {}).get("maximum_score"),
                    event.get("camera_device") or (event.get("metadata") or {}).get("camera_device"),
                    event.get("leave_at"),
                    event.get("alert_at"),
                    event.get("return_at"),
                    event.get("duration_sec"),
                    event.get("status"),
                    event.get("leave_status"),
                    event.get("leave_note"),
                    event.get("leave_snapshot"),
                    event.get("alert_snapshot"),
                    event.get("return_snapshot"),
                ]
            )
        return Response(
            output.getvalue().encode("utf-8-sig"),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=absence_events.csv"},
        )

    @app.websocket("/ws/live")
    async def live_websocket(websocket: WebSocket):
        await websocket.accept()
        # 连接建立时只订阅“之后产生”的告警，不重放进程内缓存的旧告警。
        # 否则刷新页面/手机重新连接会再次弹出上一次盗窃或空岗事件。
        last_alert_revision, _ = alerts.latest()
        while True:
            revision, alert = alerts.latest()
            payload = {"status": runtime.status(), "alert": None}
            if revision != last_alert_revision:
                payload["alert"] = alert
                last_alert_revision = revision
            try:
                await websocket.send_json(payload)
                await asyncio.sleep(0.5)
            except Exception:
                break

    return app
