(() => {
  const preview = document.getElementById('live-preview');
  const offline = document.getElementById('preview-offline');
  const monitorLink = document.getElementById('open-monitor');
  const topMonitorLink = document.getElementById('top-monitor-link');
  const topNpuLink = document.getElementById('top-npu-link');
  if (monitorLink) monitorLink.href = '/monitor';
  if (topMonitorLink) topMonitorLink.href = '/monitor';
  if (topNpuLink) topNpuLink.href = '/npu';

  function setPreview(running) {
    if (!preview) return;
    if (running) {
      const expected = '/stream/monitor.mjpg';
      if (!preview.src || !preview.src.includes('/stream/monitor.mjpg')) {
        preview.src = `${expected}?ts=${Date.now()}`;
      }
      preview.classList.remove('hidden');
      offline?.classList.add('hidden');
    } else {
      preview.removeAttribute('src');
      preview.classList.add('hidden');
      offline?.classList.remove('hidden');
    }
  }

  function text(id, value) {
    const element = document.getElementById(id);
    if (element) element.textContent = value ?? '-';
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
  }

  function renderIps(items) {
    const root = document.getElementById('ip-list');
    if (!root) return;
    root.innerHTML = items?.length ? items.map(item => `
      <article><div><b>${escapeHtml(item.kind)}</b><code>${escapeHtml(item.interface)} · ${escapeHtml(item.address)}</code></div>
      <div><a href="${escapeHtml(item.monitor_url)}">实时监控</a><a href="${escapeHtml(item.history_url)}">后台数据</a></div></article>
    `).join('') : '<div class="empty-state">没有读取到全局 IPv4 地址。</div>';
  }

  function render(status) {
    const running = Boolean(status.service?.running);
    const paused = status.runtime_state === 'paused';
    text('service-state', paused ? '检测已暂停' : (running ? '运行中' : '已停止'));
    text('service-backend', status.service?.backend || 'sysv');
    text('primary-ip', status.primary_ip || '未获取');
    text('uptime', status.uptime?.text);
    text('temperature', status.temperature?.text);
    text('memory', status.memory?.text);
    text('memory-percent', `${status.memory?.percent ?? 0}%`);
    text('disk', `${status.disk?.percent ?? 0}%`);
    text('disk-text', status.disk?.text);
    text('camera-state', status.camera?.text);
    text('active-shifts', status.counts?.active_shifts ?? 0);
    text('open-alerts', status.counts?.open_alerts ?? 0);
    text('open-falls', `摔倒 ${status.counts?.open_falls ?? 0} · 盗窃 ${status.counts?.open_theft ?? 0}`);
    text('pose-model', status.models?.pose?.state);
    text('theft-model', status.models?.theft?.state);
    text('face-detector-model', status.models?.retinaface?.state);
    text('face-recognition-model', status.models?.recognition?.state);
    text('fall-model', status.models?.fall?.state);
    text('theft-rule', status.models?.theft_rule?.state);
    text('updated-at', status.timestamp);
    renderIps(status.access_urls || []);
    setPreview(running);
  }

  async function refresh() {
    try {
      const response = await fetch('/api/control/status', {cache: 'no-store'});
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      render(await response.json());
    } catch (error) {
      showToast(`状态刷新失败：${error.message}`, true);
    }
  }

  function showToast(message, error = false) {
    const toast = document.getElementById('control-toast');
    if (!toast) return;
    toast.textContent = message;
    toast.className = `control-toast ${error ? 'error' : 'success'}`;
    window.setTimeout(() => toast.classList.add('hidden'), 4000);
  }

  async function action(actionName, dangerous) {
    const labels = {start:'继续检测', stop:'暂停检测', restart:'重启检测服务', reboot:'重启RK3588设备', poweroff:'关闭RK3588设备'};
    if (!window.confirm(`确认${labels[actionName] || actionName}？`)) return;
    if (dangerous && !window.confirm('设备网络连接将中断，再次确认继续。')) return;
    document.querySelectorAll('[data-action]').forEach(button => button.disabled = true);
    try {
      const response = await fetch(`/api/control/action/${actionName}`, {method:'POST'});
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.detail || `HTTP ${response.status}`);
      showToast(`${labels[actionName] || actionName}命令已提交`);
      if (actionName === 'reboot' || actionName === 'poweroff') {
        offline?.classList.remove('hidden');
        offline.textContent = actionName === 'reboot' ? '设备正在重启，约30～90秒后重新访问本页面。' : '设备正在安全关机。';
      } else {
        window.setTimeout(refresh, actionName === 'start' || actionName === 'restart' ? 3500 : 1000);
      }
    } catch (error) {
      showToast(`操作失败：${error.message}`, true);
    } finally {
      window.setTimeout(() => document.querySelectorAll('[data-action]').forEach(button => button.disabled = false), 2000);
    }
  }

  document.querySelectorAll('[data-action]').forEach(button => {
    button.addEventListener('click', () => action(button.dataset.action, button.dataset.danger === 'true'));
  });
  preview?.addEventListener('error', () => setPreview(false));
  refresh();
  window.setInterval(refresh, 3000);
})();
