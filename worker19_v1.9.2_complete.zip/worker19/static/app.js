const App = (() => {
  let audioContext = null;
  let latestStatus = null;
  let lastStatusAt = 0;
  let socket = null;
  let reconnectTimer = null;
  const listeners = [];

  async function api(url, options = {}) {
    const response = await fetch(url, options);
    let data = {};
    try { data = await response.json(); } catch (_) {}
    if (!response.ok) throw new Error(data.detail || `请求失败：${response.status}`);
    return data;
  }

  function toast(message, type = "info") {
    const element = document.getElementById("toast");
    if (!element) return;
    element.textContent = message;
    element.className = `toast ${type}`;
    setTimeout(() => element.classList.add("hidden"), 3200);
  }

  function beep() {
    try {
      audioContext = audioContext || new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.frequency.value = 900;
      gain.gain.value = 0.15;
      oscillator.connect(gain);
      gain.connect(audioContext.destination);
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.45);
    } catch (_) {}
  }

  function showAlarm(event) {
    if (!event) return;
    const text = document.getElementById("alarm-text");
    const panel = document.getElementById("alarm-panel");
    if (!text || !panel) return;
    const title = document.getElementById("alarm-title");
    if (event.type === "fall" || event.event_type === "FALL") {
      if (title) title.textContent = "摔倒告警";
      text.textContent = event.message || `Track T${event.track_id ?? "?"} 检测到摔倒`;
    } else if (event.type === "shoplifting" || event.event_type === "SHOPLIFTING") {
      if (title) title.textContent = "盗窃告警";
      const cameraName = event.camera_name || event.camera_id || "摄像头";
      const scoreText = Number.isFinite(Number(event.score))
        ? ` · 置信度 ${(Number(event.score) * 100).toFixed(1)}%`
        : "";
      text.textContent = event.message || `${cameraName} 检测到盗窃行为${scoreText}`;
    } else if (event.type === "region_shortage_alert" || event.event_type === "REGION_SHORTAGE") {
      if (title) title.textContent = "区域缺员告警";
      const workstation = event.workstation_name || "工作台";
      const present = event.present_count ?? "?";
      const required = event.required_count ?? "?";
      const elapsed = event.elapsed_sec ?? 0;
      text.textContent = `${workstation} · 区域缺员 ${present}/${required} · 已持续 ${elapsed} 秒`;
    } else if (event.type === "absence_alert" && event.event_type === "NO_SHOW") {
      if (title) title.textContent = "未到岗告警";
      const employee = [event.employee_code, event.employee_name].filter(Boolean).join(" ") || "未命名员工";
      const workstation = event.workstation_name || "工作台";
      text.textContent = `${employee} · ${workstation} · 未到岗 ${event.elapsed_sec ?? 0} 秒`;
    } else if (event.type === "absence_alert") {
      if (title) title.textContent = "空岗告警";
      const employee = [event.employee_code, event.employee_name].filter(Boolean).join(" ") || "未命名员工";
      const workstation = event.workstation_name || "工作台";
      text.textContent = `${employee} · ${workstation} · 已缺勤 ${event.elapsed_sec ?? 0} 秒`;
    } else {
      if (title) title.textContent = "系统告警";
      text.textContent = event.message || `收到未识别事件：${event.event_type || event.type || "UNKNOWN"}`;
    }
    panel.classList.remove("hidden");
    beep();
  }

  function updateSystem(status) {
    if (!status) return;
    latestStatus = status;
    lastStatusAt = Date.now();

    const camera = status.camera || {};
    const pill = document.getElementById("camera-pill");
    if (pill) {
      const total = Number(camera.total_count || 0);
      const onlineCount = Number(camera.online_count || 0);
      if (total > 0) {
        pill.textContent = `${onlineCount}/${total} 路视觉节点在线`;
        pill.className = `system-pill ${onlineCount === total ? "online" : onlineCount > 0 ? "degraded" : "offline"}`;
      } else {
        pill.textContent = camera.online ? `${camera.active_device || "摄像头"} 在线` : "摄像头离线";
        pill.className = `system-pill ${camera.online ? "online" : "offline"}`;
      }
    }

    for (const listener of listeners) {
      try {
        listener(status);
      } catch (error) {
        console.error("页面状态渲染失败：", error);
      }
    }
  }

  async function pollStatus(force = false) {
    if (!force && Date.now() - lastStatusAt < 2500) return;
    try {
      const status = await api("/api/status", {cache: "no-store"});
      updateSystem(status);
    } catch (error) {
      console.warn("状态轮询失败：", error);
    }
  }

  function connect() {
    if (socket && socket.readyState <= WebSocket.OPEN) return;

    const protocol = location.protocol === "https:" ? "wss:" : "ws:";
    socket = new WebSocket(`${protocol}//${location.host}/ws/live`);

    socket.onopen = () => {
      if (reconnectTimer) clearTimeout(reconnectTimer);
    };

    socket.onmessage = event => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.status) updateSystem(payload.status);
        if (payload.alert) showAlarm(payload.alert);
      } catch (error) {
        console.error("WebSocket消息解析失败：", error);
      }
    };

    socket.onerror = () => {
      try { socket.close(); } catch (_) {}
    };

    socket.onclose = () => {
      reconnectTimer = setTimeout(connect, 1500);
    };
  }

  function onStatus(listener) {
    listeners.push(listener);
    if (latestStatus) {
      try { listener(latestStatus); } catch (error) { console.error(error); }
    }
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
    })[char]);
  }

  connect();
  pollStatus(true);
  setInterval(() => pollStatus(false), 1000);

  return { api, toast, onStatus, escapeHtml, pollStatus };
})();

function dismissAlarm() {
  document.getElementById("alarm-panel")?.classList.add("hidden");
}
