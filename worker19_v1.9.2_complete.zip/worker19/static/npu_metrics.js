(() => {
  const modelNames = {pose:'YOLOv8-Pose', theft:'YOLO11-Shoplifting', retinaface:'RetinaFace', recognition:'W600K-MBF'};
  const fmt = (v, digits=2) => v === null || v === undefined || v === '' ? '-' : Number(v).toFixed(digits);
  const esc = v => String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const duration = sec => { sec=Math.max(0,Number(sec||0)); const h=Math.floor(sec/3600); const m=Math.floor(sec%3600/60); const s=Math.floor(sec%60); return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`; };

  function renderModels(npu) {
    const body=document.getElementById('npu-model-body');
    const models=npu?.models||{};
    body.innerHTML=Object.entries(modelNames).map(([key,label])=>{
      const m=models[key]||{}; const lat=m.latency_ms||{}; const stage=m.stage_latency_ms||{};
      const input=m.input_shape?`${m.input_shape.join('×')} · ${m.input_dtype||'-'}`:'等待首次推理';
      const pipeline=stage.pipeline?.avg ? `<small>Pipe ${fmt(stage.pipeline.avg,2)} ms · Pre ${fmt(stage.pre?.avg,2)} · Post ${fmt(stage.post?.avg,2)}</small>` : '';
      return `<tr><td><strong>${label}</strong><small>${esc(m.model_path||'')}</small></td><td>${esc(m.execution_device||'-')}<br><b>Core ${esc(m.npu_core??'-')}</b></td><td><span class="badge info">${esc(m.quantization||'-')}</span><br><small>Lite ${esc(m.toolkit_version||npu.toolkit_lite_version||'-')}</small></td><td>${fmt(m.model_size_mb,3)} MB</td><td>${esc(input)}</td><td>${m.calls??0}<br><small>错误 ${m.errors??0}</small></td><td>${fmt(m.actual_call_rate_fps,2)}</td><td>${fmt(lat.avg,2)} / ${fmt(lat.p50,2)} / ${fmt(lat.p95,2)} ms${pipeline}</td><td>${fmt(m.theoretical_inference_fps,2)}</td><td><span class="badge ${m.npu_verified?'success':'warning'}">${m.npu_verified?'NPU已验证':'等待调用'}</span></td></tr>`;
    }).join('');
  }

  function renderEvaluation(evaluations) {
    const root=document.getElementById('evaluation-grid');
    const data=evaluations?.theft||{};
    if (!data.available) {
      root.innerHTML=`<article class="evaluation-card"><h3>YOLO11-Shoplifting</h3><p>${esc(data.message||'未找到真实离线评测文件')}</p><small>${(data.expected_paths||[]).map(esc).join('<br>')}</small></article>`;
      return;
    }
    root.innerHTML=`<article class="evaluation-card">
      <h3>${esc(data.model_name||'YOLO11-Shoplifting')}</h3>
      <div class="evaluation-fields">
        <label><span>校准图片</span><strong>${data.calibration_images ?? '-'}</strong></label>
        <label><span>验证图片</span><strong>${data.evaluation_images ?? '-'}</strong></label>
        <label><span>mAP50</span><strong>${fmt(data.map50_pct,4)}%</strong></label>
        <label><span>mAP50-95</span><strong>${fmt(data.map50_95_pct,4)}%</strong></label>
        <label><span>Shoplifting Precision</span><strong>${fmt(data.precision_pct,4)}%</strong></label>
        <label><span>Shoplifting Recall</span><strong>${fmt(data.recall_pct,4)}%</strong></label>
        <label><span>Shoplifting F1</span><strong>${fmt(data.f1_pct,4)}%</strong></label>
        <label><span>TP / FP / FN</span><strong>${data.tp??'-'} / ${data.fp??'-'} / ${data.fn??'-'}</strong></label>
      </div>
      <div class="evaluation-footer"><small>真实来源：${esc(data.source_path)}<br>文件时间：${esc(data.source_mtime||'-')}<br>评测参数：eval_conf=${esc(data.eval_conf_floor??'-')} · report_conf=${esc(data.report_conf??'-')} · NMS=${esc(data.nms_thresh??'-')} · max_det=${esc(data.max_det??'-')}</small></div>
    </article>`;
  }

  async function refresh() {
    try {
      const response=await fetch('/api/npu-metrics',{cache:'no-store'}); const data=await response.json(); if(!response.ok) throw new Error(`HTTP ${response.status}`);
      const npu=data.npu||{}, perf=data.performance||{};
      document.getElementById('npu-verified').textContent=npu.all_enabled_models_verified?'真实NPU推理中':'等待全部模型推理';
      document.getElementById('npu-platform').textContent=`${npu.platform||'RK3588'} · ${npu.backend||'RKNNLite'}`;
      document.getElementById('version-pair').textContent=`${npu.toolkit_lite_version||'-'} / ${npu.runtime_version_observed||'-'}`;
      document.getElementById('runtime-source').textContent=npu.runtime_version_source==='loaded_librknnrt'?'来自当前进程已加载 librknnrt.so':'Runtime版本尚未从进程读取';
      document.getElementById('driver-version').textContent=npu.driver_version_observed||'未读取';
      document.getElementById('npu-frequency').textContent=npu.npu_frequency_hz?`当前 ${(npu.npu_frequency_hz/1e6).toFixed(0)} MHz`:`Governor ${npu.npu_governor||'-'}`;
      document.getElementById('camera-loop-fps').textContent=`${fmt(perf.camera_loop_fps,2)} FPS`;
      document.getElementById('runtime-uptime').textContent=`运行 ${duration(perf.runtime_uptime_sec)}`;
      document.getElementById('perf-camera').textContent=`${fmt(perf.camera_loop_fps,2)} FPS`;
      document.getElementById('perf-pose').textContent=`${fmt(perf.pose_actual_fps,2)} FPS`;
      document.getElementById('perf-theft').textContent=`${fmt(perf.theft_actual_fps,2)} FPS`;
      document.getElementById('perf-face').textContent=`${fmt(perf.face_actual_fps,2)} FPS`;
      document.getElementById('perf-preview').textContent=`${fmt(perf.preview_actual_fps,2)} FPS`;
      document.getElementById('perf-jpeg').textContent=`${fmt(perf.preview_encode_ms,2)} ms`;
      document.getElementById('perf-preview-age').textContent=`${fmt(perf.preview_frame_age_ms,2)} ms`;
      document.getElementById('perf-pose-age').textContent=`${fmt(perf.pose_queue_frame_age_ms,2)} ms`;
      document.getElementById('perf-pose-lock').textContent=`${fmt(perf.pose_lock_wait_ms,2)} ms`;
      document.getElementById('perf-theft-age').textContent=`${fmt(perf.theft_queue_frame_age_ms,2)} ms`;
      document.getElementById('perf-theft-lock').textContent=`${fmt(perf.theft_lock_wait_ms,2)} ms`;
      document.getElementById('perf-preview-drop').textContent=perf.preview_dropped??0;
      document.getElementById('perf-pose-drop').textContent=perf.pose_dropped??0;
      document.getElementById('perf-theft-drop').textContent=perf.theft_dropped??0;
      document.getElementById('perf-tracks').textContent=data.track_count??0;
      document.getElementById('npu-load').textContent=npu.npu_load_raw||'当前内核未暴露 /sys/kernel/debug/rknpu/load；inference 调用计数仍来自真实RKNN执行。';
      document.getElementById('runtime-path').textContent=`librknnrt: ${npu.runtime_library||'未读取'}${npu.runtime_version_detail?`\nversion detail: ${npu.runtime_version_detail}`:''}${npu.driver_version_source?`\ndriver source: ${npu.driver_version_source}`:''}`;
      renderModels(npu); renderEvaluation(data.evaluations||{});
    } catch(error) { App.toast(`NPU数据刷新失败：${error.message}`, 'error'); }
  }
  refresh(); window.setInterval(refresh,1000);
})();
