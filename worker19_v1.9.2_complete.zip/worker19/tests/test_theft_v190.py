from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np

from workstation.database import Database
from workstation.models import TheftDetection
from workstation.theft_detection import TheftEventManager


class TheftV190Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.db = Database(Path(self.temp.name) / "db.json")
        self.manager = TheftEventManager(
            database=self.db,
            event_dir=Path(self.temp.name) / "events",
            config={
                "enabled": True,
                "alarm_class_id": 0,
                "alarm_confidence": 0.35,
                "window_seconds": 2.0,
                "minimum_hits": 5,
                "clear_seconds": 1.0,
                "cooldown_seconds": 2.0,
                "snapshot_enabled": False,
            },
            camera_id="cam1",
            camera_name="test camera",
        )
        self.frame = np.zeros((240, 320, 3), dtype=np.uint8)
        self.det = TheftDetection(
            bbox=np.asarray([20, 30, 180, 220], dtype=np.float32),
            score=0.88,
            class_id=0,
            class_name="Shoplifting",
        )

    def tearDown(self) -> None:
        self.temp.cleanup()

    def update(self, t: float, detections):
        return self.manager.update(
            frame=self.frame,
            detections=detections,
            tracks=[],
            bindings={},
            camera_device="/dev/video22",
            now_monotonic=t,
        )

    def test_five_hits_open_theft_event_and_clear_closes_it(self):
        for i in range(4):
            status = self.update(i * 0.25, [self.det])
            self.assertEqual(status.state, "SUSPECTED")
        status = self.update(1.0, [self.det])
        self.assertEqual(status.state, "ALERT")
        self.assertIsNotNone(status.event_id)

        events = self.db.query_events(category="theft")
        self.assertEqual(len(events), 1)
        self.assertEqual(events[0]["event_type"], "SHOPLIFTING")
        self.assertEqual(events[0]["status"], "OPEN")

        status = self.update(2.2, [])
        self.assertEqual(status.state, "COOLDOWN")
        events = self.db.query_events(category="theft")
        self.assertEqual(events[0]["status"], "CLOSED")

    def test_cooldown_does_not_retrigger_same_continuous_detection(self):
        for i in range(5):
            self.update(i * 0.25, [self.det])
        self.update(2.2, [])
        for t in (2.3, 2.6, 3.0, 3.8):
            status = self.update(t, [self.det])
            self.assertEqual(status.state, "COOLDOWN")
        self.assertEqual(len(self.db.query_events(category="theft")), 1)


if __name__ == "__main__":
    unittest.main()
