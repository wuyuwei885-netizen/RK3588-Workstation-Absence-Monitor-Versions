import json
import threading
import time
from pathlib import Path

import numpy as np

from workstation.control import DeviceInspector
from workstation.evaluation import load_model_evaluation
from workstation.runtime import JPEGStore, LatestJPEGEncoder, LatestPoseInferenceWorker, LatestTheftInferenceWorker
from workstation.system_metrics import detect_loaded_runtime_version


def test_evaluation_reads_real_json(tmp_path: Path):
    root = tmp_path / "shoplifting"
    model_dir = root / "models"
    eval_dir = root / "quant_eval_fast"
    model_dir.mkdir(parents=True)
    eval_dir.mkdir(parents=True)
    model = model_dir / "run1_best_i8_calib300.rknn"
    model.write_bytes(b"rknn")
    (eval_dir / "run1_best_i8_calib300.json").write_text(json.dumps({
        "model_name": model.name,
        "model_size_mb": 10.69,
        "images": 1867,
        "mAP50": 0.891174,
        "mAP50_95": 0.614775,
        "eval_conf_floor": 0.001,
        "report_conf": 0.25,
        "nms_thresh": 0.65,
        "max_det": 300,
        "classes": {"Shoplifting": {"P_at_conf": 0.84896, "R_at_conf": 0.90789, "F1_at_conf": 0.87743, "TP": 2001, "FP": 356, "FN": 203, "GT": 2204}}
    }), encoding="utf-8")
    data = load_model_evaluation(model)
    assert data["available"] is True
    assert data["calibration_images"] == 300
    assert data["evaluation_images"] == 1867
    assert data["map50_pct"] == 89.1174
    assert data["map50_95_pct"] == 61.4775
    assert data["precision_pct"] == 84.896
    assert data["source_path"].endswith("quant_eval_fast/run1_best_i8_calib300.json")


def test_runtime_version_is_parsed_from_loaded_library(monkeypatch):
    import workstation.system_metrics as sm
    monkeypatch.setattr(sm, "_strings", lambda path: "abc\nlibrknnrt version: 2.3.2 (429f97@2025)\nxyz")
    data = detect_loaded_runtime_version(["/usr/lib/librknnrt.so"])
    assert data["version"] == "2.3.2"
    assert data["library"] == "/usr/lib/librknnrt.so"
    assert data["source"] == "loaded_librknnrt"


def test_integrated_control_does_not_self_http(tmp_path: Path, monkeypatch):
    db = tmp_path / "workstation.db"
    db.write_text(json.dumps({"shifts": [], "absence_events": []}), encoding="utf-8")
    inspector = DeviceInspector(database_path=db, main_port=8090, control_port=8090, main_service="dummy", camera_device="/dev/null")
    monkeypatch.setattr(inspector.controller, "state", lambda: {"running": True, "state": "active", "backend": "test"})
    monkeypatch.setattr(inspector, "_main_status", lambda: (_ for _ in ()).throw(AssertionError("same-port mode must not HTTP itself")))
    monkeypatch.setattr(inspector, "_ip_addresses", lambda: [{"interface": "eth0", "address": "192.168.10.66", "kind": "有线网络"}])
    status = inspector.collect(main_status_override={"state": "running", "camera": {"online": True}, "model_paths": {}, "fall_summary": {}, "theft_summary": {}})
    assert status["runtime_state"] == "running"
    assert status["access_urls"][0]["control_url"] == "http://192.168.10.66:8090/control"


def test_latest_jpeg_encoder_keeps_stream_alive():
    annotated = JPEGStore(); raw = JPEGStore()
    worker = LatestJPEGEncoder(annotated, raw, 60)
    worker.start()
    image = np.zeros((64, 96, 3), dtype=np.uint8)
    capture = time.monotonic()
    worker.submit(image.copy(), image.copy(), capture)
    jpeg, version = annotated.wait(-1, timeout=2)
    worker.stop(); worker.join(timeout=2)
    assert version >= 0
    assert jpeg and jpeg.startswith(b"\xff\xd8")
    assert worker.metrics()["completed"] >= 1


class _FakeTheftModel:
    def infer(self, frame):
        time.sleep(0.01)
        return ["det"], {"pre_ms": 1.0, "npu_ms": 2.0, "post_ms": 3.0, "pipeline_ms": 6.0}


def test_theft_worker_runs_off_main_thread():
    results = []
    event = threading.Event()
    worker = LatestTheftInferenceWorker(_FakeTheftModel(), threading.RLock(), lambda result: (results.append(result), event.set()), "test-theft")
    worker.start()
    worker.submit({"frame": np.zeros((8, 8, 3), dtype=np.uint8), "capture_ts": time.monotonic(), "tracks": [], "bindings": {}, "camera_device": "/dev/video0"})
    assert event.wait(2)
    worker.stop(); worker.join(timeout=2)
    assert results[0]["detections"] == ["det"]
    assert results[0]["timing"]["npu_ms"] == 2.0
    assert worker.metrics()["completed"] == 1


def test_config_contains_no_fake_runtime_version():
    data = json.loads((Path(__file__).resolve().parents[1] / "config.json").read_text(encoding="utf-8"))
    assert "runtime_version_observed" not in data.get("rknn", {})
    assert "driver_version_observed" not in data.get("rknn", {})
    assert data["app"]["host"] == "0.0.0.0"
    assert data["app"]["port"] == 8090


class _FakePoseModel:
    def infer(self, frame):
        time.sleep(0.01)
        return ["pose"], 4.25


def test_pose_worker_runs_latest_only_off_main_thread():
    results = []
    event = threading.Event()
    worker = LatestPoseInferenceWorker(
        _FakePoseModel(), threading.RLock(),
        lambda result: (results.append(result), event.set()),
        "test-pose",
    )
    worker.start()
    worker.submit({"frame": np.zeros((8, 8, 3), dtype=np.uint8), "capture_ts": time.monotonic()})
    assert event.wait(2)
    worker.stop(); worker.join(timeout=2)
    assert results[0]["detections"] == ["pose"]
    assert results[0]["inference_ms"] == 4.25
    assert worker.metrics()["completed"] == 1


def test_package_has_no_separate_8091_control_service():
    root = Path(__file__).resolve().parents[1]
    assert not (root / "control_app.py").exists()
    assert not (root / "init.d" / "workstation-control").exists()
    monitor = (root / "templates" / "monitor.html").read_text(encoding="utf-8")
    assert ":8091" not in monitor
    assert 'href="/control"' in monitor


def test_installer_migrates_legacy_versions_and_control_port(tmp_path: Path):
    import importlib.util
    import shutil

    root = Path(__file__).resolve().parents[1]
    spec = importlib.util.spec_from_file_location("install_v191_safe", root / "tools" / "install_v191_safe.py")
    assert spec and spec.loader
    installer = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(installer)

    shutil.copy2(root / "config.example.json", tmp_path / "config.example.json")
    old = json.loads((root / "config.json").read_text(encoding="utf-8"))
    old["app"]["host"] = "127.0.0.1"
    old["app"]["port"] = 8123
    old["rknn"]["runtime_version_observed"] = "2.0.0b0"
    old["rknn"]["driver_version_observed"] = "0.9.6"
    old["control"] = {"port": 8091, "same_port": False}
    for model in old["models"].values():
        if isinstance(model, dict):
            model["toolkit_version"] = "2.3.2"
    (tmp_path / "config.json").write_text(json.dumps(old, ensure_ascii=False, indent=2), encoding="utf-8")

    installer.configure_project(tmp_path)
    migrated = json.loads((tmp_path / "config.json").read_text(encoding="utf-8"))

    assert migrated["app"]["host"] == "0.0.0.0"
    assert migrated["app"]["port"] == 8123
    assert migrated["control"]["same_port"] is True
    assert "port" not in migrated["control"]
    assert "runtime_version_observed" not in migrated["rknn"]
    assert "driver_version_observed" not in migrated["rknn"]
    assert migrated["models"]["pose"]["core"] == "0"
    assert migrated["models"]["shoplifting"]["core"] == "1"
    assert migrated["models"]["retinaface"]["core"] == "2"
    assert migrated["models"]["face_recognition"]["core"] == "2"
    assert migrated["models"]["shoplifting"]["path"].endswith("run1_best_i8_calib300.rknn")
    assert all("toolkit_version" not in model for model in migrated["models"].values())
