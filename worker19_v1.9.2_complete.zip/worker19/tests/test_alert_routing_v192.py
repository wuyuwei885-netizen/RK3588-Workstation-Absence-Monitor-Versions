from pathlib import Path


def test_frontend_alarm_routing_is_explicit():
    root = Path(__file__).resolve().parents[1]
    text = (root / "static" / "app.js").read_text(encoding="utf-8")
    assert 'event.type === "shoplifting"' in text
    assert 'event.type === "absence_alert"' in text
    assert 'title.textContent = "盗窃告警"' in text
    assert 'title.textContent = "系统告警"' in text


def test_websocket_does_not_replay_cached_alarm():
    root = Path(__file__).resolve().parents[1]
    text = (root / "workstation" / "web.py").read_text(encoding="utf-8")
    assert 'last_alert_revision, _ = alerts.latest()' in text
    assert 'last_alert_revision = -1' not in text
