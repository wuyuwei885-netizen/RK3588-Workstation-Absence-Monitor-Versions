#!/usr/bin/env python3
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / "config.json"


def mark(ok: bool) -> str:
    return "[OK]" if ok else "[FAIL]"


def main() -> int:
    errors = 0
    print("========== worker19 v1.9.1 preflight ==========")
    print("root:", ROOT)
    print("python:", sys.executable)
    print("python version:", sys.version.split()[0])

    try:
        config = json.loads(CONFIG.read_text(encoding="utf-8"))
        print(mark(True), "config.json valid")
    except Exception as exc:
        print(mark(False), "config.json", exc)
        return 2

    required = [
        ROOT / "app.py",
        ROOT / "workstation" / "models.py",
        ROOT / "workstation" / "runtime.py",
        ROOT / "workstation" / "system_metrics.py",
        ROOT / "workstation" / "evaluation.py",
        ROOT / "workstation" / "theft_detection.py",
        ROOT / "templates" / "control_dashboard.html",
        ROOT / "templates" / "npu_metrics.html",
        ROOT / "static" / "control.js",
        ROOT / "static" / "npu_metrics.js",
        ROOT / "init.d" / "workstation-absence",
    ]
    for path in required:
        ok = path.is_file()
        errors += 0 if ok else 1
        print(mark(ok), path.relative_to(ROOT))

    # 单端口规则
    app = config.get("app") or {}
    same_port_ok = str(app.get("host")) == "0.0.0.0" and int(app.get("port", 0)) > 0
    errors += 0 if same_port_ok else 1
    print(mark(same_port_ok), f"single web port: host={app.get('host')} port={app.get('port')}")
    legacy_files = [ROOT / "control_app.py", ROOT / "init.d" / "workstation-control"]
    legacy_ok = all(not path.exists() for path in legacy_files)
    errors += 0 if legacy_ok else 1
    print(mark(legacy_ok), "legacy 8091 control service removed from package")

    # 禁止配置文件伪造RKNN版本号
    rknn = config.get("rknn") or {}
    fake_keys = {"runtime_version_observed", "driver_version_observed", "toolkit_version"}
    version_config_ok = not any(key in rknn for key in fake_keys)
    version_config_ok = version_config_ok and all(
        "toolkit_version" not in item
        for item in (config.get("models") or {}).values()
        if isinstance(item, dict)
    )
    errors += 0 if version_config_ok else 1
    print(mark(version_config_ok), "RKNN versions are not stored in config")

    expected_cores = {"pose": "0", "shoplifting": "1", "retinaface": "2", "face_recognition": "2"}
    for key, expected in expected_cores.items():
        item = (config.get("models") or {}).get(key) or {}
        actual = str(item.get("core"))
        ok = actual == expected
        errors += 0 if ok else 1
        print(mark(ok), f"model {key}: core={actual}, expected={expected}")
        if item.get("enabled", True):
            model = Path(str(item.get("path", ""))).expanduser()
            exists = model.is_file()
            errors += 0 if exists else 1
            print(mark(exists), f"model path {key}: {model}")

    runtime = config.get("runtime") or {}
    latency_cfg_ok = (
        int((config.get("camera") or {}).get("buffers", 99)) <= 2
        and float(runtime.get("preview_fps", 0)) >= 10
        and float(runtime.get("status_fps", 0)) > 0
        and float(runtime.get("raw_preview_fps", 0)) > 0
    )
    errors += 0 if latency_cfg_ok else 1
    print(mark(latency_cfg_ok), "low-latency latest-frame/preview configuration")

    for item in config.get("cameras") or []:
        device = Path(str(item.get("device", "")))
        print(("[OK]" if device.exists() else "[INFO]"), f"camera {item.get('id')}: {device} {'exists' if device.exists() else 'not found now'}")

    print(("[OK]" if shutil.which("v4l2-ctl") else "[INFO]"), "v4l2-ctl", shutil.which("v4l2-ctl") or "not found in this environment")
    try:
        from rknnlite.api import RKNNLite  # noqa: F401
        from workstation.system_metrics import detect_toolkit_lite_version
        print(mark(True), "rknnlite.api import")
        print("[REAL] installed RKNN Lite Python package:", detect_toolkit_lite_version() or "version metadata unavailable")
    except Exception as exc:
        print(mark(False), "rknnlite.api import", exc)
        errors += 1

    # 这里只报告真实评测文件是否存在，不因缺失而制造默认指标。
    try:
        from workstation.evaluation import load_model_evaluation
        theft_path = (config.get("models") or {}).get("shoplifting", {}).get("path", "")
        evaluation = load_model_evaluation(theft_path)
        if evaluation.get("available"):
            print("[REAL] offline evaluation:", evaluation.get("source_path"))
        else:
            print("[INFO] offline evaluation JSON not found; NPU page will show unavailable")
            for path in evaluation.get("expected_paths", []):
                print("       expected:", path)
    except Exception as exc:
        print("[INFO] evaluation probe failed:", exc)

    print("===============================================")
    print("PASS" if errors == 0 else f"FAIL: {errors} required checks failed")
    return 0 if errors == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
