#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Iterable

VERSION = "1.9.1"
DEFAULT_TARGET = Path("/root/workstation/worker19")
DEFAULT_VENV = Path("/root/yolov8_rk3588/rknn310")
MAIN_SERVICE = Path("/etc/init.d/workstation-absence")
LEGACY_CONTROL_SERVICE = Path("/etc/init.d/workstation-control")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "v1.9.1安全安装器：设备控制并入主站同一端口；"
            "不下载/替换RKNN Runtime，不修改现有虚拟环境"
        )
    )
    parser.add_argument("--target", default=str(DEFAULT_TARGET), help="项目安装目录")
    parser.add_argument("--venv", default=str(DEFAULT_VENV), help="现有Python虚拟环境目录")
    parser.add_argument("--no-start", action="store_true", help="安装后不启动主服务")
    return parser.parse_args()


def run(args: Iterable[str], *, timeout: float = 120.0) -> subprocess.CompletedProcess[str]:
    command = [str(item) for item in args]
    print("+", " ".join(command))
    return subprocess.run(
        command,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )


def merge_missing(current: Any, defaults: Any) -> Any:
    if isinstance(current, dict) and isinstance(defaults, dict):
        result = dict(current)
        for key, value in defaults.items():
            result[key] = merge_missing(result[key], value) if key in result else value
        return result
    return current


def copy_item(source: Path, target: Path) -> None:
    if source.is_dir():
        shutil.copytree(source, target, dirs_exist_ok=True)
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def stop_service(path: Path) -> None:
    if not path.is_file():
        return
    result = run([str(path), "stop"], timeout=40)
    if result.stdout.strip():
        print(result.stdout.rstrip())


def stop_manual_python(target: Path) -> None:
    """只结束目标worker19的app.py/历史control_app.py，不碰其他Python进程。"""
    current_pid = os.getpid()
    parent_pid = os.getppid()
    result = subprocess.run(
        ["ps", "-eo", "pid=,args="],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    needles = (str(target / "app.py"), str(target / "control_app.py"))
    for line in result.stdout.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        pid_text, _, command = stripped.partition(" ")
        try:
            pid = int(pid_text)
        except ValueError:
            continue
        if pid in {current_pid, parent_pid}:
            continue
        if any(needle in command for needle in needles):
            print(f"停止旧worker19进程 PID={pid}: {command}")
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass


def backup_target(target: Path, timestamp: str) -> Path:
    backup = target.parent / f"{target.name}_backup_v191_{timestamp}"
    backup.mkdir(parents=True, exist_ok=False)
    names = [
        "app.py",
        "control_app.py",
        "workstation",
        "templates",
        "static",
        "tools",
        "tests",
        "init.d",
        "config.json",
        "config.example.json",
        "config.dual.example.json",
        "README.md",
        "VERSION",
    ]
    for name in names:
        source = target / name
        if source.exists():
            copy_item(source, backup / name)

    database_path = target / "data" / "workstation.db"
    config_path = target / "config.json"
    if config_path.is_file():
        try:
            configured = json.loads(config_path.read_text(encoding="utf-8")).get("app", {}).get("database")
            if configured:
                database_path = Path(str(configured)).expanduser()
        except (OSError, json.JSONDecodeError):
            pass
    if database_path.is_file():
        shutil.copy2(database_path, backup / "workstation.db")
    legacy_eval = target / "data" / "model_evaluation.json"
    if legacy_eval.is_file():
        shutil.copy2(legacy_eval, backup / "model_evaluation.legacy_v190.json")
    return backup


def deploy_source(source_root: Path, target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    skip = {"config.json", "data", ".git", ".pytest_cache", "__pycache__"}
    for item in source_root.iterdir():
        if item.name in skip or item.suffix == ".zip":
            continue
        destination = target / item.name
        if item.name == "models":
            destination.mkdir(parents=True, exist_ok=True)
            readme = item / "README.md"
            if readme.is_file():
                shutil.copy2(readme, destination / "README_v191.md")
            continue
        copy_item(item, destination)

    for cache in target.rglob("__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)
    for pyc in target.rglob("*.pyc"):
        pyc.unlink(missing_ok=True)

def clean_legacy_project_files(target: Path, timestamp: str) -> None:
    """清理旧双端口入口和旧网页手填精度文件；先改名保留，不直接丢用户内容。"""
    legacy_paths = [
        target / "control_app.py",
        target / "init.d" / "workstation-control",
    ]
    for path in legacy_paths:
        if not path.exists():
            continue
        backup = path.with_name(path.name + f".disabled_v191_{timestamp}")
        try:
            path.replace(backup)
            print(f"旧分离控制文件已禁用：{path} -> {backup.name}")
        except OSError:
            path.unlink(missing_ok=True)

    legacy_eval = target / "data" / "model_evaluation.json"
    if legacy_eval.is_file():
        backup = legacy_eval.with_name(f"model_evaluation.legacy_v190_{timestamp}.json")
        legacy_eval.replace(backup)
        print(f"旧网页手填精度文件已停用并保留：{backup}")


def configure_project(target: Path) -> Dict[str, Any]:
    example_path = target / "config.example.json"
    config_path = target / "config.json"
    defaults = json.loads(example_path.read_text(encoding="utf-8"))

    if config_path.is_file():
        try:
            current = json.loads(config_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"现有 config.json 不是有效JSON，安装中止：{exc}") from exc
    else:
        current = {}

    merged = merge_missing(current, defaults)
    for key in ("app", "camera", "models", "runtime", "fall_detection", "theft_detection", "control", "rknn"):
        merged.setdefault(key, {})

    # 单端口：继续使用用户原主站端口（默认8090），强制监听所有网卡。
    merged["app"]["host"] = "0.0.0.0"
    merged["app"]["port"] = int(merged["app"].get("port", 8090))

    # 低延迟采集/预览。设备节点、分辨率和用户数据路径保持原值。
    merged["camera"]["fps"] = 30
    merged["camera"]["buffers"] = 2
    merged["camera"]["warmup"] = int(merged["camera"].get("warmup", 6))
    merged["runtime"].update(
        {
            "pose_fps": 12.0,
            "face_fps": 3.0,
            "theft_fps": 6.0,
            "preview_fps": 12.0,
            "raw_preview_fps": 6.0,
            "preview_width": 960,
            "jpeg_quality": 68,
            "business_fps": 10.0,
            "status_fps": 5.0,
        }
    )

    # NPU核心固定分工：Core0=Pose，Core1=YOLO11盗窃，Core2=人脸。
    for key in ("pose", "shoplifting", "retinaface", "face_recognition"):
        merged["models"].setdefault(key, {})
        merged["models"][key].pop("toolkit_version", None)
    merged["models"]["pose"]["core"] = "0"
    merged["models"]["shoplifting"].update(
        {
            "enabled": True,
            "core": "1",
            "path": "/root/rk3588_yolo11_shoplifting/models/run1_best_i8_calib300.rknn",
        }
    )
    merged["models"]["shoplifting"].setdefault("confidence", 0.25)
    merged["models"]["shoplifting"].setdefault("nms", 0.45)
    merged["models"]["shoplifting"].setdefault("max_det", 50)
    merged["models"]["retinaface"]["core"] = "2"
    merged["models"]["face_recognition"]["core"] = "2"

    merged["fall_detection"]["enabled"] = True
    merged["fall_detection"]["detect_unknown_person"] = True
    merged["theft_detection"]["enabled"] = True
    merged["theft_detection"].setdefault("alarm_class_id", 0)
    merged["theft_detection"].setdefault("alarm_confidence", 0.35)
    merged["theft_detection"].setdefault("window_seconds", 2.0)
    merged["theft_detection"].setdefault("minimum_hits", 5)
    merged["theft_detection"].setdefault("clear_seconds", 2.0)
    merged["theft_detection"].setdefault("cooldown_seconds", 8.0)
    merged["theft_detection"].setdefault("association_iou", 0.10)
    merged["theft_detection"].setdefault("snapshot_enabled", True)

    # 版本号不允许来自配置。页面只读取当前进程真实Python包、已加载librknnrt和内核驱动。
    merged["rknn"] = {
        "platform": str(merged["rknn"].get("platform", "RK3588")),
        "backend": str(merged["rknn"].get("backend", "RKNNLite")),
        "metrics_window": int(merged["rknn"].get("metrics_window", 300)),
    }
    merged["control"] = {
        "same_port": True,
        "main_service": "workstation-absence.service",
        "status_timeout_sec": float(merged["control"].get("status_timeout_sec", 1.2)),
    }

    config_path.write_text(json.dumps(merged, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return merged


def patch_init_script(source: Path, destination: Path, *, target: Path, python: Path, port: int) -> None:
    text = source.read_text(encoding="utf-8")
    for key, value in {"WORKDIR": str(target), "PYTHON": str(python), "PORT": str(port)}.items():
        pattern = rf'(?m)^{key}="[^"]*"$'
        text, count = re.subn(pattern, f'{key}="{value}"', text, count=1)
        if count != 1:
            raise RuntimeError(f"服务脚本缺少 {key} 配置：{source}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(text, encoding="utf-8")
    destination.chmod(0o755)


def _remove_rc_links(name: str) -> None:
    candidates = list(Path("/etc").glob(f"rc*.d/*{name}*"))
    candidates += list(Path("/etc/rcS.d").glob(f"*{name}*")) if Path("/etc/rcS.d").exists() else []
    seen = set()
    for path in candidates:
        text = str(path)
        if text in seen:
            continue
        seen.add(text)
        try:
            if path.is_symlink() or path.exists():
                print(f"移除旧开机链接：{path}")
                path.unlink()
        except OSError as exc:
            print(f"警告：无法移除 {path}: {exc}")


def disable_legacy_control_service(timestamp: str) -> None:
    """停止并禁用旧8091控制服务，但保留备份，避免破坏性删除。"""
    stop_service(LEGACY_CONTROL_SERVICE)
    _remove_rc_links("workstation-control")
    if LEGACY_CONTROL_SERVICE.is_file():
        backup = LEGACY_CONTROL_SERVICE.with_name(f"workstation-control.disabled_v191_{timestamp}")
        if not backup.exists():
            shutil.copy2(LEGACY_CONTROL_SERVICE, backup)
            print(f"旧分离控制服务已备份：{backup}")
        LEGACY_CONTROL_SERVICE.unlink(missing_ok=True)


def install_main_service(target: Path, python: Path, config: Dict[str, Any], timestamp: str) -> None:
    Path("/etc/init.d").mkdir(parents=True, exist_ok=True)
    if MAIN_SERVICE.exists():
        shutil.copy2(MAIN_SERVICE, MAIN_SERVICE.with_name(MAIN_SERVICE.name + f".bak_{timestamp}"))
    patch_init_script(
        target / "init.d" / "workstation-absence",
        MAIN_SERVICE,
        target=target,
        python=python,
        port=int(config["app"].get("port", 8090)),
    )

    _remove_rc_links("workstation-absence")
    links = [("/etc/rcS.d/S98workstation-absence", MAIN_SERVICE)]
    for level in (2, 3, 4, 5):
        links.append((f"/etc/rc{level}.d/S98workstation-absence", MAIN_SERVICE))
    for level in (0, 1, 6):
        links.append((f"/etc/rc{level}.d/K02workstation-absence", MAIN_SERVICE))
    for link_text, destination in links:
        link = Path(link_text)
        link.parent.mkdir(parents=True, exist_ok=True)
        if link.is_symlink() or link.exists():
            link.unlink()
        link.symlink_to(destination)


def verify_required_files(target: Path, python: Path) -> None:
    required = [
        target / "app.py",
        target / "workstation" / "runtime.py",
        target / "workstation" / "system_metrics.py",
        target / "workstation" / "evaluation.py",
        target / "workstation" / "theft_detection.py",
        target / "workstation" / "control.py",
        target / "templates" / "control_dashboard.html",
        target / "templates" / "npu_metrics.html",
        target / "static" / "control.js",
        target / "static" / "npu_metrics.js",
        target / "init.d" / "workstation-absence",
        python,
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError("安装包缺少必要文件：\n" + "\n".join(missing))


def verify_model_paths(config: Dict[str, Any]) -> bool:
    print("\n模型路径检查（只读，不下载、不转换、不替换）：")
    all_ok = True
    for key, item in config.get("models", {}).items():
        if not item.get("enabled", True):
            print(f"  {key}: 已禁用")
            continue
        path = Path(str(item.get("path", ""))).expanduser()
        exists = path.is_file()
        print(f"  {key}: {'存在' if exists else '缺失'} -> {path}")
        all_ok = all_ok and exists
    return all_ok


def http_code(url: str, timeout: float = 3.0) -> int:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            return int(response.status)
    except (urllib.error.URLError, TimeoutError, OSError):
        return 0


def main() -> int:
    args = parse_args()
    source_root = Path(__file__).resolve().parent.parent
    target = Path(args.target).expanduser().resolve()
    venv = Path(args.venv).expanduser().resolve()
    python = venv / "bin" / "python"
    timestamp = time.strftime("%Y%m%d_%H%M%S")

    print("=" * 72)
    print(f"worker19 v{VERSION} 安全完整包安装")
    print("单端口模式：/monitor、/npu、/control 全部使用 app.port（默认8090）。")
    print("不会执行 curl/wget/pip/apt；不会替换 /usr/lib/librknnrt.so；不会删除RKNN环境。")
    print(f"源码目录：{source_root}")
    print(f"目标目录：{target}")
    print(f"现有环境：{venv}")
    print("=" * 72)

    if not python.is_file():
        raise FileNotFoundError(f"现有虚拟环境Python不存在：{python}")
    verify_required_files(source_root, python)

    stop_service(MAIN_SERVICE)
    disable_legacy_control_service(timestamp)
    stop_manual_python(target)
    time.sleep(0.5)

    if target.exists() and source_root != target:
        backup = backup_target(target, timestamp)
        print(f"已备份现有worker19代码和数据库：{backup}")
    elif source_root == target:
        print("源码目录就是目标目录，跳过代码复制。")

    if source_root != target:
        deploy_source(source_root, target)

    clean_legacy_project_files(target, timestamp)
    config = configure_project(target)
    verify_required_files(target, python)
    install_main_service(target, python, config, timestamp)
    model_ok = verify_model_paths(config)

    print("\n环境保护检查：")
    print(f"  Python环境：{venv}")
    print("  RKNN Runtime：未下载、未覆盖")
    print("  librknnrt.so：未替换")
    print("  旧8091控制服务：已停止并取消开机启动，控制页已合并至主端口")

    if args.no_start:
        print("\n安装完成；按 --no-start 要求未启动主服务。")
        return 0

    result = run([str(MAIN_SERVICE), "restart"], timeout=120)
    if result.stdout.strip():
        print(result.stdout.rstrip())

    port = int(config["app"].get("port", 8090))
    status_http = http_code(f"http://127.0.0.1:{port}/api/status")
    control_http = http_code(f"http://127.0.0.1:{port}/control")
    npu_http = http_code(f"http://127.0.0.1:{port}/api/npu-metrics")

    print("\n" + "=" * 72)
    print(f"HTTP检查：/api/status={status_http} /control={control_http} /api/npu-metrics={npu_http}")
    print(f"唯一网页端口：http://<板卡IP>:{port}/")
    print(f"实时监控：http://<板卡IP>:{port}/monitor")
    print(f"NPU真实指标：http://<板卡IP>:{port}/npu")
    print(f"手机设备控制：http://<板卡IP>:{port}/control")
    print("启动命令：source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation/worker19 && export PYTHONPATH=/root/workstation/worker19 && python -u app.py --config config.json")
    print("=" * 72)

    if result.returncode != 0 or status_http != 200 or control_http != 200 or npu_http != 200:
        print("主服务启动/同端口路由检查失败：tail -n 180 /var/log/workstation-absence.log")
        return 3
    if not model_ok:
        print("警告：至少一个模型文件缺失。网页可能在线，但对应NPU模型无法正常推理。")
        return 4
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"\n安装失败：{type(exc).__name__}: {exc}", file=sys.stderr)
        print("没有执行RKNN环境删除、Runtime下载或librknnrt替换。", file=sys.stderr)
        raise SystemExit(1)
