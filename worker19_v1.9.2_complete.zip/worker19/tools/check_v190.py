#!/usr/bin/env python3
"""兼容旧命令名；v1.9.1请使用check_v191.py。"""
from check_v191 import main

if __name__ == "__main__":
    raise SystemExit(main())
