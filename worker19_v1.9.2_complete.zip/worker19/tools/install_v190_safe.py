#!/usr/bin/env python3
"""兼容旧命令名；实际执行v1.9.1单端口安全安装器。"""
from install_v191_safe import main

if __name__ == "__main__":
    raise SystemExit(main())
