#!/usr/bin/env python3
from __future__ import annotations

import argparse
import statistics
from pathlib import Path

import cv2
import numpy as np

from workstation.models import ShopliftingDetector


def percentile(values, q: float) -> float:
    return float(np.percentile(np.asarray(values, dtype=np.float64), q)) if values else 0.0


def main() -> int:
    parser = argparse.ArgumentParser(description="worker19 YOLO11 Shoplifting NPU/Pipeline基准")
    parser.add_argument("--model", default="/root/rk3588_yolo11_shoplifting/models/run1_best_i8_calib300.rknn")
    parser.add_argument("--image", default="", help="可选真实图片；不填则使用1920x1080黑图")
    parser.add_argument("--core", default="1")
    parser.add_argument("--loops", type=int, default=100)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--conf", type=float, default=0.25)
    parser.add_argument("--nms", type=float, default=0.45)
    args = parser.parse_args()

    if args.image:
        frame = cv2.imread(args.image)
        if frame is None:
            raise SystemExit(f"无法读取图片：{args.image}")
    else:
        frame = np.zeros((1080, 1920, 3), dtype=np.uint8)

    detector = ShopliftingDetector({
        "path": str(Path(args.model).expanduser()),
        "core": str(args.core),
        "input_size": 640,
        "confidence": float(args.conf),
        "nms": float(args.nms),
        "max_det": 50,
        "metrics_window": max(300, int(args.loops) + 20),
        "quantization": "INT8",
    })

    try:
        for _ in range(max(0, args.warmup)):
            detector.infer(frame)

        rows = []
        det_counts = []
        for i in range(max(1, args.loops)):
            detections, timing = detector.infer(frame)
            rows.append(timing)
            det_counts.append(len(detections))
            if (i + 1) % 20 == 0 or i + 1 == args.loops:
                print(f"[BENCH] {i+1}/{args.loops} npu={timing['npu_ms']:.2f}ms pipe={timing['pipeline_ms']:.2f}ms det={len(detections)}")

        print("\n========== YOLO11 SHOPLIFTING BENCHMARK ==========")
        for key, label in (("pre_ms", "PRE"), ("npu_ms", "NPU inference"), ("post_ms", "POST"), ("pipeline_ms", "PIPELINE")):
            values = [float(row[key]) for row in rows]
            avg = statistics.fmean(values)
            print(f"{label:14s}: avg={avg:8.3f} ms  P50={percentile(values,50):8.3f}  P95={percentile(values,95):8.3f}  FPS={1000.0/avg if avg>0 else 0:8.2f}")
        print(f"detections/frame: avg={statistics.fmean(det_counts):.2f}, max={max(det_counts) if det_counts else 0}")
        print("说明：NPU inference 只包围 RKNNLite.inference()；PIPELINE 包含预处理+NPU+DFL/NMS后处理。")
        return 0
    finally:
        detector.close()


if __name__ == "__main__":
    raise SystemExit(main())
