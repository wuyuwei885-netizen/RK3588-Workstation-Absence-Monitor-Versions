from __future__ import annotations

import json
import shutil
import socket
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional


ALLOWED_SERVICE_ACTIONS = {"start", "stop", "restart"}
ALLOWED_DEVICE_ACTIONS = {"reboot", "poweroff"}


def _human_bytes(value: int) -> str:
    size = float(max(0, value))
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024.0 or unit == "TB":
            return f"{size:.1f} {unit}"
        size /= 1024.0
    return f"{size:.1f} TB"


def _human_duration(seconds: float) -> str:
    value = max(0, int(seconds))
    days, value = divmod(value, 86400)
    hours, value = divmod(value, 3600)
    minutes, secs = divmod(value, 60)
    if days:
        return f"{days}天 {hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


def _read_json_retry(path: Path, attempts: int = 3) -> Dict[str, Any]:
    for index in range(max(1, attempts)):
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (FileNotFoundError, UnicodeDecodeError, json.JSONDecodeError):
            if index + 1 >= attempts:
                return {}
            time.sleep(0.05)
    return {}


class ServiceController:
    def __init__(self, service_name: str, backend: Optional[str] = None) -> None:
        self.service_name = str(service_name)
        self.sysv_name = self.service_name.removesuffix(".service")
        self.init_script = Path("/etc/init.d") / self.sysv_name
        self.backend = backend or self._detect_backend()

    @staticmethod
    def _detect_backend() -> str:
        systemctl = shutil.which("systemctl")
        if systemctl and Path("/run/systemd/system").is_dir():
            return "systemd"
        return "sysv"

    @staticmethod
    def _run(args: List[str], timeout: float = 25.0) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            args,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )

    def _service_command(self, action: str) -> List[str]:
        if self.backend == "systemd":
            return ["systemctl", action, self.service_name]
        if not self.init_script.is_file():
            raise RuntimeError(f"缺少SysV服务脚本：{self.init_script}")
        return [str(self.init_script), action]

    def state(self) -> Dict[str, Any]:
        try:
            if self.backend == "systemd":
                result = self._run(["systemctl", "is-active", self.service_name], timeout=5)
                raw_state = (result.stdout or result.stderr).strip() or "unknown"
                running = result.returncode == 0 and raw_state == "active"
            else:
                if not self.init_script.is_file():
                    return {
                        "state": "unavailable",
                        "running": False,
                        "returncode": 127,
                        "backend": self.backend,
                        "detail": f"缺少服务脚本：{self.init_script}",
                    }
                result = self._run([str(self.init_script), "status"], timeout=5)
                raw_state = (result.stdout or result.stderr).strip() or "unknown"
                running = result.returncode == 0
            return {
                "state": "active" if running else "inactive",
                "running": running,
                "returncode": result.returncode,
                "backend": self.backend,
                "detail": raw_state,
            }
        except FileNotFoundError as exc:
            return {
                "state": "unavailable",
                "running": False,
                "returncode": 127,
                "backend": self.backend,
                "detail": str(exc),
            }

    def service_action(self, action: str) -> Dict[str, Any]:
        normalized = str(action).strip().lower()
        if normalized not in ALLOWED_SERVICE_ACTIONS:
            raise ValueError("不允许的检测服务操作")
        command = self._service_command(normalized)
        result = self._run(command, timeout=35)
        if result.returncode != 0:
            detail = (result.stderr or result.stdout).strip() or "检测服务操作失败"
            raise RuntimeError(detail)
        return {
            "ok": True,
            "action": normalized,
            "service": self.service_name,
            "backend": self.backend,
            "detail": (result.stdout or "").strip(),
        }

    @staticmethod
    def _first_command(candidates: List[List[str]]) -> List[str]:
        for candidate in candidates:
            executable = candidate[0]
            if executable.startswith("/"):
                if Path(executable).exists():
                    return candidate
            elif shutil.which(executable):
                return candidate
        raise RuntimeError("系统缺少可用的重启/关机命令")

    def device_action(self, action: str) -> Dict[str, Any]:
        normalized = str(action).strip().lower()
        if normalized not in ALLOWED_DEVICE_ACTIONS:
            raise ValueError("不允许的设备操作")
        if normalized == "reboot":
            command = self._first_command(
                [["/sbin/reboot"], ["/usr/sbin/reboot"], ["reboot"]]
            )
        else:
            command = self._first_command(
                [
                    ["/sbin/poweroff"],
                    ["/usr/sbin/poweroff"],
                    ["poweroff"],
                    ["/sbin/halt", "-p"],
                    ["halt", "-p"],
                    ["/sbin/shutdown", "-h", "now"],
                    ["shutdown", "-h", "now"],
                ]
            )
        result = self._run(command, timeout=10)
        # 重启/关机命令可能在连接断开前不返回；返回0表示已成功提交。
        if result.returncode != 0:
            detail = (result.stderr or result.stdout).strip() or "设备控制失败"
            raise RuntimeError(detail)
        return {"ok": True, "action": normalized, "command": command}


class DeviceInspector:
    def __init__(
        self,
        *,
        database_path: str | Path,
        main_port: int,
        control_port: int,
        main_service: str,
        camera_device: str,
        status_timeout_sec: float = 1.2,
    ) -> None:
        self.database_path = Path(database_path)
        self.main_port = int(main_port)
        self.control_port = int(control_port)
        self.main_service = str(main_service)
        self.camera_device = str(camera_device)
        self.status_timeout_sec = max(0.2, float(status_timeout_sec))
        self.controller = ServiceController(main_service)

    @staticmethod
    def _uptime() -> Dict[str, Any]:
        try:
            seconds = float(Path("/proc/uptime").read_text().split()[0])
        except Exception:
            seconds = 0.0
        return {"seconds": int(seconds), "text": _human_duration(seconds)}

    @staticmethod
    def _temperature() -> Dict[str, Any]:
        values: List[float] = []
        for path in sorted(Path("/sys/class/thermal").glob("thermal_zone*/temp")):
            try:
                raw = float(path.read_text().strip())
                value = raw / 1000.0 if raw > 500 else raw
                if -20.0 <= value <= 150.0:
                    values.append(value)
            except Exception:
                continue
        if not values:
            return {"available": False, "celsius": None, "text": "不可用"}
        # RK3588 多个 thermal zone 中取最高温度，便于安全监控。
        value = max(values)
        return {"available": True, "celsius": round(value, 1), "text": f"{value:.1f}℃"}

    @staticmethod
    def _memory() -> Dict[str, Any]:
        info: Dict[str, int] = {}
        try:
            for line in Path("/proc/meminfo").read_text().splitlines():
                key, value = line.split(":", 1)
                info[key] = int(value.strip().split()[0]) * 1024
        except Exception:
            pass
        total = int(info.get("MemTotal", 0))
        available = int(info.get("MemAvailable", info.get("MemFree", 0)))
        used = max(0, total - available)
        percent = round((used / total * 100.0), 1) if total else 0.0
        return {
            "total": total,
            "used": used,
            "available": available,
            "percent": percent,
            "text": f"{_human_bytes(used)} / {_human_bytes(total)}",
        }

    @staticmethod
    def _disk(path: Path) -> Dict[str, Any]:
        target = path if path.exists() else Path("/")
        usage = shutil.disk_usage(target)
        used = usage.total - usage.free
        percent = round((used / usage.total * 100.0), 1) if usage.total else 0.0
        return {
            "path": str(target),
            "total": usage.total,
            "used": used,
            "free": usage.free,
            "percent": percent,
            "text": f"{_human_bytes(used)} / {_human_bytes(usage.total)}",
        }

    @staticmethod
    def _ip_addresses() -> List[Dict[str, str]]:
        rows: List[Dict[str, str]] = []
        try:
            result = subprocess.run(
                ["ip", "-4", "-o", "addr", "show", "scope", "global"],
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                timeout=3,
                check=False,
            )
            for line in result.stdout.splitlines():
                parts = line.split()
                if len(parts) < 4:
                    continue
                interface = parts[1]
                address = parts[3].split("/", 1)[0]
                kind = (
                    "Tailscale"
                    if interface.startswith("tailscale")
                    else "Wi-Fi"
                    if interface.startswith(("wlan", "wl"))
                    else "有线网络"
                    if interface.startswith(("eth", "en"))
                    else "网络接口"
                )
                rows.append({"interface": interface, "address": address, "kind": kind})
        except Exception:
            pass
        if rows:
            return rows
        try:
            hostname = socket.gethostname()
            for address in socket.gethostbyname_ex(hostname)[2]:
                if not address.startswith("127."):
                    rows.append(
                        {"interface": "hostname", "address": address, "kind": "网络接口"}
                    )
        except Exception:
            pass
        return rows

    def _main_status(self) -> Optional[Dict[str, Any]]:
        url = f"http://127.0.0.1:{self.main_port}/api/status"
        try:
            with urllib.request.urlopen(url, timeout=self.status_timeout_sec) as response:
                return json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, OSError):
            return None

    def _database_counts(self) -> Dict[str, int]:
        data = _read_json_retry(self.database_path)
        shifts = data.get("shifts", []) if isinstance(data, dict) else []
        events = data.get("absence_events", []) if isinstance(data, dict) else []
        active_shifts = sum(1 for item in shifts if item.get("status") == "ACTIVE")
        open_alerts = sum(1 for item in events if item.get("status") == "OPEN")
        open_falls = sum(
            1
            for item in events
            if item.get("status") == "OPEN" and item.get("event_type") == "FALL"
        )
        return {
            "active_shifts": active_shifts,
            "open_alerts": open_alerts,
            "open_falls": open_falls,
        }

    def collect(self) -> Dict[str, Any]:
        service = self.controller.state()
        # 无论 PID 文件状态如何，都探测 8090 的真实状态接口。
        # 这样即使主程序曾被手工启动，手机后台仍能显示真实运行状态。
        main_status = self._main_status()
        effective_running = bool(service.get("running") or main_status is not None)
        if effective_running and not service.get("running"):
            service = {
                **service,
                "running": True,
                "state": "active",
                "detail": f"{service.get('detail', '')}；8090状态接口在线",
            }
        camera_status = (main_status or {}).get("camera", {})
        model_paths = (main_status or {}).get("model_paths", {})
        runtime_state = (main_status or {}).get("state")
        counts = self._database_counts()
        ips = self._ip_addresses()

        if not effective_running:
            camera_text = "检测服务已停止"
        elif camera_status.get("online"):
            camera_text = f"在线 · {camera_status.get('active_device', self.camera_device)}"
        elif main_status is None:
            camera_text = "服务启动中或状态接口不可达"
        else:
            camera_text = camera_status.get("error") or "离线"

        def model_item(key: str, label: str) -> Dict[str, Any]:
            path = model_paths.get(key)
            if not effective_running:
                return {"label": label, "ok": False, "state": "服务已停止", "path": path}
            if runtime_state == "error":
                return {"label": label, "ok": False, "state": "运行异常", "path": path}
            if path:
                return {"label": label, "ok": True, "state": "正常", "path": path}
            return {"label": label, "ok": False, "state": "未加载", "path": path}

        access_urls = []
        for item in ips:
            access_urls.append(
                {
                    **item,
                    "control_url": f"http://{item['address']}:{self.control_port}/",
                    "monitor_url": f"http://{item['address']}:{self.main_port}/monitor",
                    "history_url": f"http://{item['address']}:{self.main_port}/history",
                }
            )

        fall_summary = (main_status or {}).get("fall_summary", {})
        primary_ip = ips[0]["address"] if ips else "未获取"

        return {
            "device_online": True,
            "primary_ip": primary_ip,
            "hostname": socket.gethostname(),
            "service": service,
            "runtime_state": runtime_state or ("stopped" if not effective_running else "starting"),
            "uptime": self._uptime(),
            "temperature": self._temperature(),
            "memory": self._memory(),
            "disk": self._disk(self.database_path.parent),
            "camera": {
                "online": bool(camera_status.get("online")),
                "device_exists": Path(self.camera_device).exists(),
                "text": camera_text,
                "detail": camera_status,
            },
            "models": {
                "pose": model_item("pose", "Pose模型"),
                "retinaface": model_item("retinaface", "人脸检测模型"),
                "recognition": model_item("recognition", "人脸识别模型"),
                "fall": {
                    "label": "摔倒检测",
                    "ok": bool(effective_running and fall_summary.get("enabled", False)),
                    "state": (
                        "正常"
                        if effective_running and fall_summary.get("enabled", False)
                        else "服务已停止"
                        if not effective_running
                        else "未启用"
                    ),
                },
            },
            "counts": counts,
            "ips": ips,
            "access_urls": access_urls,
            "main_port": self.main_port,
            "control_port": self.control_port,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        }
