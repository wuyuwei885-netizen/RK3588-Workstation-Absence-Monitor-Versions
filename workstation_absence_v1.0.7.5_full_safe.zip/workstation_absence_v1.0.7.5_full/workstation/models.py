from __future__ import annotations

import threading
import time
from collections import deque
from dataclasses import dataclass
from itertools import product
from math import ceil
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import cv2
import numpy as np


@dataclass
class PersonDetection:
    bbox: np.ndarray
    score: float
    keypoints: np.ndarray


@dataclass
class FaceDetection:
    bbox: np.ndarray
    score: float
    landmarks: np.ndarray


def _core_mask(RKNNLite, name: str):
    mapping = {
        "auto": "NPU_CORE_AUTO",
        "0": "NPU_CORE_0",
        "1": "NPU_CORE_1",
        "2": "NPU_CORE_2",
        "01": "NPU_CORE_0_1",
        "012": "NPU_CORE_0_1_2",
    }
    if name not in mapping:
        raise ValueError(f"无效NPU核心配置：{name}")
    attribute = mapping[name]
    if hasattr(RKNNLite, attribute):
        return getattr(RKNNLite, attribute)
    if name in {"01", "012"}:
        return getattr(RKNNLite, "NPU_CORE_AUTO")
    raise RuntimeError(f"当前RKNNLite不支持核心配置：{name}")


class RKNNBackend:
    """RKNNLite NPU后端，并记录真实 inference() 调用统计。"""

    def __init__(
        self,
        model_path: str | Path,
        core: str,
        name: str,
        config: Dict[str, Any] | None = None,
        metrics_window: int = 300,
    ) -> None:
        path = Path(model_path).expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(f"{name}模型不存在：{path}")
        try:
            from rknnlite.api import RKNNLite
        except ImportError as exc:
            raise ImportError(
                "未安装rknn-toolkit-lite2；板端必须安装匹配Python版本的aarch64 wheel"
            ) from exc

        self.path = path
        self.name = name
        self.core = str(core)
        self.config = dict(config or {})
        self.quantization = str(self.config.get("quantization", "INT8"))
        self.toolkit_version = str(self.config.get("toolkit_version", "未知"))
        self._lock = threading.RLock()
        self._latencies = deque(maxlen=max(20, int(metrics_window)))
        self._timestamps = deque(maxlen=max(60, int(metrics_window) * 2))
        self._calls = 0
        self._errors = 0
        self._last_input_shape: List[int] | None = None
        self._last_input_dtype: str | None = None
        self._last_output_shapes: List[List[int]] = []
        self._last_inference_at: str | None = None
        self._initialized_at = time.strftime("%Y-%m-%d %H:%M:%S")

        self.runtime = RKNNLite(verbose=False)
        ret = self.runtime.load_rknn(str(path))
        if ret != 0:
            self.runtime.release()
            raise RuntimeError(f"{name} load_rknn失败：ret={ret}")
        ret = self.runtime.init_runtime(core_mask=_core_mask(RKNNLite, self.core))
        if ret != 0:
            self.runtime.release()
            raise RuntimeError(
                f"{name} init_runtime失败：ret={ret}；检查NPU驱动、librknnrt和模型版本"
            )
        self.initialized = True
        print(
            f"[NPU] {self.name} 已通过RKNNLite初始化到 RK3588 NPU Core {self.core}; "
            f"量化={self.quantization}; 模型={self.path}"
        )

    def infer(self, tensor: np.ndarray) -> Tuple[List[np.ndarray], float]:
        start = time.perf_counter()
        try:
            outputs = self.runtime.inference(inputs=[tensor])
        except Exception:
            with self._lock:
                self._errors += 1
            raise
        elapsed_ms = (time.perf_counter() - start) * 1000.0
        if outputs is None:
            with self._lock:
                self._errors += 1
            raise RuntimeError(
                f"{self.name}推理返回None；输入shape={tensor.shape}, dtype={tensor.dtype}"
            )
        now = time.monotonic()
        with self._lock:
            self._calls += 1
            self._latencies.append(float(elapsed_ms))
            self._timestamps.append(now)
            self._last_input_shape = [int(v) for v in tensor.shape]
            self._last_input_dtype = str(tensor.dtype)
            self._last_output_shapes = [
                [int(v) for v in np.asarray(item).shape] for item in outputs
            ]
            self._last_inference_at = time.strftime("%Y-%m-%d %H:%M:%S")
        return outputs, elapsed_ms

    @staticmethod
    def _loaded_runtime_libraries() -> List[str]:
        paths = set()
        try:
            for line in Path("/proc/self/maps").read_text(encoding="utf-8", errors="ignore").splitlines():
                if "librknnrt.so" in line:
                    candidate = line.rsplit(None, 1)[-1]
                    if candidate.startswith("/"):
                        paths.add(candidate)
        except OSError:
            pass
        return sorted(paths)

    def status(self) -> Dict[str, Any]:
        with self._lock:
            values = np.asarray(list(self._latencies), dtype=np.float64)
            timestamps = list(self._timestamps)
            calls = int(self._calls)
            errors = int(self._errors)
            last_shape = self._last_input_shape
            last_dtype = self._last_input_dtype
            output_shapes = list(self._last_output_shapes)
            last_at = self._last_inference_at
        if values.size:
            avg_ms = float(values.mean())
            last_ms = float(values[-1])
            minimum_ms = float(values.min())
            maximum_ms = float(values.max())
            p50_ms = float(np.percentile(values, 50))
            p95_ms = float(np.percentile(values, 95))
        else:
            avg_ms = last_ms = minimum_ms = maximum_ms = p50_ms = p95_ms = 0.0
        if len(timestamps) >= 2 and timestamps[-1] > timestamps[0]:
            call_rate = (len(timestamps) - 1) / (timestamps[-1] - timestamps[0])
        else:
            call_rate = 0.0
        theoretical_fps = 1000.0 / avg_ms if avg_ms > 0 else 0.0
        size_bytes = self.path.stat().st_size if self.path.is_file() else 0
        return {
            "name": self.name,
            "backend": "RKNNLite",
            "execution_device": "RK3588 NPU",
            "npu_core": self.core,
            "initialized": bool(getattr(self, "initialized", False)),
            "npu_verified": bool(getattr(self, "initialized", False) and calls > 0),
            "quantization": self.quantization,
            "toolkit_version": self.toolkit_version,
            "model_path": str(self.path),
            "model_size_bytes": size_bytes,
            "model_size_mb": round(size_bytes / 1024.0 / 1024.0, 3),
            "input_shape": last_shape,
            "input_dtype": last_dtype,
            "output_shapes": output_shapes,
            "calls": calls,
            "errors": errors,
            "last_inference_at": last_at,
            "latency_ms": {
                "last": round(last_ms, 3),
                "avg": round(avg_ms, 3),
                "min": round(minimum_ms, 3),
                "max": round(maximum_ms, 3),
                "p50": round(p50_ms, 3),
                "p95": round(p95_ms, 3),
            },
            "actual_call_rate_fps": round(call_rate, 3),
            "theoretical_inference_fps": round(theoretical_fps, 3),
            "runtime_libraries": self._loaded_runtime_libraries(),
            "initialized_at": self._initialized_at,
        }

    def close(self) -> None:
        self.runtime.release()


def letterbox(
    image: np.ndarray, size: int, color: int
) -> Tuple[np.ndarray, float, int, int]:
    height, width = image.shape[:2]
    ratio = min(size / width, size / height)
    resized_width = max(1, int(width * ratio))
    resized_height = max(1, int(height * ratio))
    resized = cv2.resize(
        image, (resized_width, resized_height), interpolation=cv2.INTER_AREA
    )
    canvas = np.full((size, size, 3), color, dtype=np.uint8)
    offset_x = (size - resized_width) // 2
    offset_y = (size - resized_height) // 2
    canvas[
        offset_y : offset_y + resized_height,
        offset_x : offset_x + resized_width,
    ] = resized
    return canvas, ratio, offset_x, offset_y


def prepare_input(
    image_bgr: np.ndarray,
    *,
    layout: str,
    color: str = "rgb",
    normalize: bool = False,
    scale: float = 1.0,
    mean: Sequence[float] = (0.0, 0.0, 0.0),
    std: Sequence[float] = (1.0, 1.0, 1.0),
) -> np.ndarray:
    image = image_bgr
    if color.lower() == "rgb":
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    elif color.lower() != "bgr":
        raise ValueError(f"不支持颜色顺序：{color}")

    if normalize:
        image = image.astype(np.float32) * float(scale)
        image = (
            image - np.asarray(mean, dtype=np.float32).reshape(1, 1, 3)
        ) / np.maximum(np.asarray(std, dtype=np.float32).reshape(1, 1, 3), 1e-12)
    else:
        image = image.astype(np.uint8, copy=False)

    if layout == "nhwc":
        tensor = image[None, ...]
    elif layout == "nchw":
        tensor = np.transpose(image, (2, 0, 1))[None, ...]
    else:
        raise ValueError(f"不支持输入布局：{layout}")
    return np.ascontiguousarray(tensor)


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -50.0, 50.0)))


def softmax(x: np.ndarray, axis: int = -1) -> np.ndarray:
    shifted = x - np.max(x, axis=axis, keepdims=True)
    exp_x = np.exp(shifted)
    return exp_x / np.sum(exp_x, axis=axis, keepdims=True)


def nms_xyxy(boxes: np.ndarray, scores: np.ndarray, threshold: float) -> np.ndarray:
    if boxes.size == 0:
        return np.empty((0,), dtype=np.int64)
    x1, y1, x2, y2 = boxes.T
    areas = np.maximum(0.0, x2 - x1) * np.maximum(0.0, y2 - y1)
    order = scores.argsort()[::-1]
    keep: List[int] = []
    while order.size:
        current = int(order[0])
        keep.append(current)
        if order.size == 1:
            break
        rest = order[1:]
        xx1 = np.maximum(x1[current], x1[rest])
        yy1 = np.maximum(y1[current], y1[rest])
        xx2 = np.minimum(x2[current], x2[rest])
        yy2 = np.minimum(y2[current], y2[rest])
        intersection = np.maximum(0.0, xx2 - xx1) * np.maximum(0.0, yy2 - yy1)
        iou = intersection / (areas[current] + areas[rest] - intersection + 1e-9)
        order = rest[iou <= threshold]
    return np.asarray(keep, dtype=np.int64)


class PoseDetector:
    """Rockchip Model Zoo YOLOv8-Pose四输出后处理。"""

    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.input_size = int(config.get("input_size", 640))
        self.layout = str(config.get("input_layout", "nhwc"))
        self.confidence = float(config.get("confidence", 0.45))
        self.nms_threshold = float(config.get("nms", 0.40))
        self.keypoint_confidence = float(config.get("keypoint_confidence", 0.35))
        self.backend = RKNNBackend(config["path"], str(config.get("core", "0")), "YOLOv8-Pose", config)
        self._printed = False

    @staticmethod
    def _normalize_outputs(outputs: Sequence[np.ndarray]):
        branches: List[np.ndarray] = []
        keypoints = None
        for output in outputs:
            array = np.asarray(output)
            if array.ndim == 4 and (array.shape[1] == 65 or array.shape[-1] == 65):
                if array.shape[-1] == 65:
                    array = np.transpose(array, (0, 3, 1, 2))
                branches.append(array.astype(np.float32, copy=False))
            elif 17 in array.shape and (3 in array.shape or 51 in array.shape):
                keypoints = array.astype(np.float32, copy=False)

        if len(branches) != 3 or keypoints is None:
            raise ValueError(
                f"Pose输出结构不匹配：{[tuple(np.asarray(item).shape) for item in outputs]}"
            )
        branches.sort(key=lambda item: item.shape[2] * item.shape[3], reverse=True)

        if keypoints.ndim == 4 and keypoints.shape[1:3] == (17, 3):
            pass
        elif keypoints.ndim == 4 and keypoints.shape[1:3] == (3, 17):
            keypoints = np.transpose(keypoints, (0, 2, 1, 3))
        elif keypoints.ndim == 3 and keypoints.shape[1] == 51:
            keypoints = keypoints.reshape(1, 17, 3, keypoints.shape[2])
        elif keypoints.ndim == 3 and keypoints.shape[2] == 51:
            keypoints = np.transpose(keypoints, (0, 2, 1))
            keypoints = keypoints.reshape(1, 17, 3, keypoints.shape[2])
        else:
            raise ValueError(f"无法解析Pose关键点输出：{keypoints.shape}")
        return branches, keypoints

    def infer(self, frame: np.ndarray) -> Tuple[List[PersonDetection], float]:
        model_image, ratio, offset_x, offset_y = letterbox(frame, self.input_size, 56)
        tensor = prepare_input(model_image, layout=self.layout, color="rgb")
        outputs, elapsed_ms = self.backend.infer(tensor)
        branches, keypoints = self._normalize_outputs(outputs)
        if not self._printed:
            print("[Pose] input", tensor.shape, tensor.dtype)
            print("[Pose] outputs", [np.asarray(item).shape for item in outputs])
            self._printed = True

        boxes_all: List[np.ndarray] = []
        scores_all: List[np.ndarray] = []
        keypoints_all: List[np.ndarray] = []
        bins = np.arange(16, dtype=np.float32)
        anchor_offset = 0

        for branch in branches:
            _, channels, height, width = branch.shape
            feature = branch.reshape(channels, -1)
            scores = sigmoid(feature[64])
            candidates = np.flatnonzero(scores >= self.confidence)
            if candidates.size == 0:
                anchor_offset += height * width
                continue

            logits = feature[:64, candidates].T.reshape(-1, 4, 16)
            distances = np.sum(softmax(logits, axis=2) * bins[None, None, :], axis=2)
            grid_y = candidates // width
            grid_x = candidates % width
            stride = self.input_size / height
            center_x = grid_x.astype(np.float32) + 0.5
            center_y = grid_y.astype(np.float32) + 0.5
            boxes = np.stack(
                (
                    (center_x - distances[:, 0]) * stride,
                    (center_y - distances[:, 1]) * stride,
                    (center_x + distances[:, 2]) * stride,
                    (center_y + distances[:, 3]) * stride,
                ),
                axis=1,
            )
            selected = np.take(keypoints[0], anchor_offset + candidates, axis=2)
            selected = np.transpose(selected, (2, 0, 1))
            boxes_all.append(boxes)
            scores_all.append(scores[candidates])
            keypoints_all.append(selected)
            anchor_offset += height * width

        if not boxes_all:
            return [], elapsed_ms

        boxes = np.concatenate(boxes_all)
        scores = np.concatenate(scores_all)
        kpts = np.concatenate(keypoints_all)
        keep = nms_xyxy(boxes, scores, self.nms_threshold)
        image_height, image_width = frame.shape[:2]
        results: List[PersonDetection] = []

        for index in keep:
            box = boxes[index].astype(np.float32, copy=True)
            box[[0, 2]] = (box[[0, 2]] - offset_x) / ratio
            box[[1, 3]] = (box[[1, 3]] - offset_y) / ratio
            box[[0, 2]] = np.clip(box[[0, 2]], 0, image_width - 1)
            box[[1, 3]] = np.clip(box[[1, 3]], 0, image_height - 1)

            person_kpts = kpts[index].astype(np.float32, copy=True)
            person_kpts[:, 0] = (person_kpts[:, 0] - offset_x) / ratio
            person_kpts[:, 1] = (person_kpts[:, 1] - offset_y) / ratio
            person_kpts[:, 0] = np.clip(person_kpts[:, 0], 0, image_width - 1)
            person_kpts[:, 1] = np.clip(person_kpts[:, 1], 0, image_height - 1)
            results.append(PersonDetection(box, float(scores[index]), person_kpts))
        return results, elapsed_ms

    def close(self) -> None:
        self.backend.close()


def prior_box(image_size: Tuple[int, int]) -> np.ndarray:
    anchors: List[float] = []
    min_sizes = [[16, 32], [64, 128], [256, 512]]
    steps = [8, 16, 32]
    feature_maps = [
        [ceil(image_size[0] / step), ceil(image_size[1] / step)] for step in steps
    ]
    for level, feature_map in enumerate(feature_maps):
        for row, col in product(range(feature_map[0]), range(feature_map[1])):
            for min_size in min_sizes[level]:
                anchors.extend(
                    [
                        (col + 0.5) * steps[level] / image_size[1],
                        (row + 0.5) * steps[level] / image_size[0],
                        min_size / image_size[1],
                        min_size / image_size[0],
                    ]
                )
    return np.asarray(anchors, dtype=np.float32).reshape(-1, 4)


def decode_face_boxes(locations: np.ndarray, priors: np.ndarray) -> np.ndarray:
    boxes = np.concatenate(
        (
            priors[:, :2] + locations[:, :2] * 0.1 * priors[:, 2:],
            priors[:, 2:] * np.exp(locations[:, 2:] * 0.2),
        ),
        axis=1,
    )
    boxes[:, :2] -= boxes[:, 2:] / 2.0
    boxes[:, 2:] += boxes[:, :2]
    return boxes


def decode_landmarks(prediction: np.ndarray, priors: np.ndarray) -> np.ndarray:
    return np.concatenate(
        [
            priors[:, :2] + prediction[:, start : start + 2] * 0.1 * priors[:, 2:]
            for start in range(0, 10, 2)
        ],
        axis=1,
    )


def normalize_face_output(output: np.ndarray, last_dimension: int) -> np.ndarray:
    array = np.squeeze(np.asarray(output))
    if array.ndim != 2:
        raise ValueError()
    if array.shape[1] == last_dimension:
        return array.astype(np.float32, copy=False)
    if array.shape[0] == last_dimension:
        return array.T.astype(np.float32, copy=False)
    raise ValueError()


class RetinaFaceDetector:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.input_size = int(config.get("input_size", 320))
        self.layout = str(config.get("input_layout", "nhwc"))
        self.candidate_confidence = float(config.get("candidate_confidence", 0.02))
        self.confidence = float(config.get("confidence", 0.25))
        self.nms_threshold = float(config.get("nms", 0.50))
        self.priors = prior_box((self.input_size, self.input_size))
        self.backend = RKNNBackend(
            config["path"], str(config.get("core", "1")), "RetinaFace", config
        )
        self._printed = False

    def infer(self, frame: np.ndarray) -> Tuple[List[FaceDetection], float]:
        image_height, image_width = frame.shape[:2]
        model_image, ratio, offset_x, offset_y = letterbox(frame, self.input_size, 114)
        tensor = prepare_input(model_image, layout=self.layout, color="rgb")
        outputs, elapsed_ms = self.backend.infer(tensor)

        locations = confidences = landmarks = None
        for output in outputs:
            for dimension, name in ((4, "loc"), (2, "conf"), (10, "land")):
                try:
                    normalized = normalize_face_output(output, dimension)
                except ValueError:
                    continue
                if name == "loc" and locations is None:
                    locations = normalized
                    break
                if name == "conf" and confidences is None:
                    confidences = normalized
                    break
                if name == "land" and landmarks is None:
                    landmarks = normalized
                    break

        if locations is None or confidences is None or landmarks is None:
            raise ValueError(
                f"RetinaFace输出结构不匹配：{[np.asarray(item).shape for item in outputs]}"
            )
        if locations.shape[0] != self.priors.shape[0]:
            raise ValueError(
                f"RetinaFace anchor数量不一致：{locations.shape[0]} vs {self.priors.shape[0]}"
            )
        if not self._printed:
            print("[RetinaFace] input", tensor.shape, tensor.dtype)
            print("[RetinaFace] outputs", [np.asarray(item).shape for item in outputs])
            self._printed = True

        boxes = decode_face_boxes(locations, self.priors)
        boxes *= np.asarray([self.input_size] * 4, dtype=np.float32)
        boxes[:, 0::2] = np.clip(
            (boxes[:, 0::2] - offset_x) / ratio, 0, image_width - 1
        )
        boxes[:, 1::2] = np.clip(
            (boxes[:, 1::2] - offset_y) / ratio, 0, image_height - 1
        )
        scores = confidences[:, 1]

        points = decode_landmarks(landmarks, self.priors)
        points *= np.asarray([self.input_size, self.input_size] * 5, dtype=np.float32)
        points[:, 0::2] = np.clip(
            (points[:, 0::2] - offset_x) / ratio, 0, image_width - 1
        )
        points[:, 1::2] = np.clip(
            (points[:, 1::2] - offset_y) / ratio, 0, image_height - 1
        )

        candidates = np.flatnonzero(scores > self.candidate_confidence)
        if candidates.size == 0:
            return [], elapsed_ms
        boxes = boxes[candidates]
        scores = scores[candidates]
        points = points[candidates]
        keep = nms_xyxy(boxes, scores, self.nms_threshold)
        results = [
            FaceDetection(
                bbox=boxes[index].copy(),
                score=float(scores[index]),
                landmarks=points[index].reshape(5, 2).copy(),
            )
            for index in keep
            if scores[index] >= self.confidence
        ]
        results.sort(
            key=lambda item: (item.bbox[2] - item.bbox[0])
            * (item.bbox[3] - item.bbox[1]),
            reverse=True,
        )
        return results, elapsed_ms

    def close(self) -> None:
        self.backend.close()


class FaceEmbeddingModel:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.input_width = int(config.get("input_width", 112))
        self.input_height = int(config.get("input_height", 112))
        self.layout = str(config.get("input_layout", "nhwc"))
        self.color = str(config.get("color", "rgb"))
        self.normalize = bool(config.get("normalize", False))
        self.scale = float(config.get("scale", 1.0))
        self.mean = config.get("mean", [0.0, 0.0, 0.0])
        self.std = config.get("std", [1.0, 1.0, 1.0])
        self.output_index = int(config.get("output_index", 0))
        self.backend = RKNNBackend(
            config["path"], str(config.get("core", "2")), "W600K-MBF", config
        )
        self._printed = False

    def infer(self, aligned_face_bgr: np.ndarray) -> Tuple[np.ndarray, float]:
        image = cv2.resize(
            aligned_face_bgr,
            (self.input_width, self.input_height),
            interpolation=cv2.INTER_LINEAR,
        )
        tensor = prepare_input(
            image,
            layout=self.layout,
            color=self.color,
            normalize=self.normalize,
            scale=self.scale,
            mean=self.mean,
            std=self.std,
        )
        outputs, elapsed_ms = self.backend.infer(tensor)
        embedding = np.asarray(outputs[self.output_index], dtype=np.float32).reshape(-1)
        norm = float(np.linalg.norm(embedding))
        if norm <= 1e-12:
            raise RuntimeError("人脸特征模型输出零向量")
        embedding /= norm
        if not self._printed:
            print("[W600K] input", tensor.shape, tensor.dtype)
            print("[W600K] outputs", [np.asarray(item).shape for item in outputs])
            print("[W600K] embedding", embedding.shape)
            self._printed = True
        return embedding, elapsed_ms

    def close(self) -> None:
        self.backend.close()


class ModelHub:
    def __init__(self, config: Dict[str, Any], rknn_config: Dict[str, Any] | None = None) -> None:
        self.pose_lock = threading.RLock()
        self.face_lock = threading.RLock()
        self.rknn_config = dict(rknn_config or {})
        self.pose = PoseDetector(config["pose"]) if config["pose"].get("enabled", True) else None
        self.face_detector = (
            RetinaFaceDetector(config["retinaface"])
            if config["retinaface"].get("enabled", True)
            else None
        )
        self.face_recognizer = (
            FaceEmbeddingModel(config["face_recognition"])
            if config["face_recognition"].get("enabled", True)
            else None
        )

    @staticmethod
    def _read_first(paths: Sequence[Path]) -> str | None:
        for path in paths:
            try:
                if path.is_file():
                    value = path.read_text(encoding="utf-8", errors="ignore").strip()
                    if value:
                        return value
            except OSError:
                continue
        return None

    def metrics(self) -> Dict[str, Any]:
        models: Dict[str, Any] = {}
        mapping = (
            ("pose", self.pose),
            ("retinaface", self.face_detector),
            ("recognition", self.face_recognizer),
        )
        for key, model in mapping:
            models[key] = model.backend.status() if model is not None else {
                "name": key,
                "initialized": False,
                "npu_verified": False,
                "state": "disabled",
            }

        load_text = self._read_first(
            [Path("/sys/kernel/debug/rknpu/load"), Path("/sys/kernel/debug/rknpu/load_info")]
        )
        freq_paths = sorted(Path("/sys/class/devfreq").glob("*npu*/cur_freq"))
        freq_text = self._read_first(freq_paths)
        governor_paths = sorted(Path("/sys/class/devfreq").glob("*npu*/governor"))
        governor = self._read_first(governor_paths)
        verified_count = sum(1 for item in models.values() if item.get("npu_verified"))
        initialized_count = sum(1 for item in models.values() if item.get("initialized"))
        return {
            "platform": str(self.rknn_config.get("platform", "RK3588")),
            "backend": str(self.rknn_config.get("backend", "RKNNLite")),
            "runtime_version_observed": self.rknn_config.get("runtime_version_observed"),
            "driver_version_observed": self.rknn_config.get("driver_version_observed"),
            "initialized_model_count": initialized_count,
            "verified_inference_model_count": verified_count,
            "all_enabled_models_verified": initialized_count > 0 and verified_count == initialized_count,
            "npu_load_raw": load_text,
            "npu_frequency_hz": int(freq_text) if freq_text and freq_text.isdigit() else None,
            "npu_governor": governor,
            "models": models,
        }

    def close(self) -> None:
        for model in (self.pose, self.face_detector, self.face_recognizer):
            if model is not None:
                model.close()

