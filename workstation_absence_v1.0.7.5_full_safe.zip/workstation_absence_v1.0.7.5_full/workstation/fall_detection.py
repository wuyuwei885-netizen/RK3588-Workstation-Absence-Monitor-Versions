from __future__ import annotations

import math
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Sequence

import cv2
import numpy as np

from .database import Database
from .identity import IdentityBinding
from .tracker import Track


@dataclass
class FallStatus:
    track_id: int
    state: str
    score: int
    maximum_score: int
    suspect_elapsed_sec: float
    fallen_elapsed_sec: float
    bbox_aspect_ratio: float
    torso_tilt_deg: Optional[float]
    shoulder_hip_vertical_ratio: Optional[float]
    keypoint_vertical_spread_ratio: Optional[float]
    downward_speed_ratio_per_sec: float
    employee_id: Optional[int]
    employee_code: Optional[str]
    employee_name: Optional[str]
    event_id: Optional[int]
    message: str


@dataclass
class _TrackState:
    track_id: int
    state: str = "NORMAL"
    suspect_since: Optional[float] = None
    fallen_since: Optional[float] = None
    recovery_since: Optional[float] = None
    last_seen: float = 0.0
    previous_center_y: Optional[float] = None
    previous_timestamp: Optional[float] = None
    maximum_score: int = 0
    event_id: Optional[int] = None
    event_started_iso: Optional[str] = None
    latest_status: Optional[FallStatus] = None
    employee_id: Optional[int] = None
    employee_code: Optional[str] = None
    employee_name: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class FallDetector:
    """基于 YOLOv8-Pose + Track ID 的全画面时序摔倒检测。

    判定不依赖 ROI，也不依赖人脸是否识别成功。人脸绑定只用于给事件补充员工身份。
    """

    VALID_STATES = {"NORMAL", "SUSPECTED", "FALLEN", "RECOVERING"}

    def __init__(
        self,
        *,
        database: Database,
        event_dir: str | Path,
        config: Dict[str, Any],
        alert_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> None:
        self.database = database
        self.event_dir = Path(event_dir)
        self.event_dir.mkdir(parents=True, exist_ok=True)
        self.config = dict(config or {})
        self.enabled = bool(self.config.get("enabled", True))
        self.detect_unknown_person = bool(
            self.config.get("detect_unknown_person", True)
        )
        self.keypoint_confidence = float(
            self.config.get("keypoint_confidence", 0.35)
        )
        self.bbox_aspect_ratio = float(
            self.config.get("bbox_aspect_ratio", 0.85)
        )
        self.torso_angle_deg = float(self.config.get("torso_angle_deg", 55.0))
        self.shoulder_hip_vertical_ratio = float(
            self.config.get("shoulder_hip_vertical_ratio", 0.25)
        )
        self.keypoint_vertical_spread_ratio = float(
            self.config.get("keypoint_vertical_spread_ratio", 0.42)
        )
        self.downward_speed_ratio_per_sec = float(
            self.config.get("downward_speed_ratio_per_sec", 0.18)
        )
        self.minimum_score = int(self.config.get("minimum_score", 3))
        self.recovery_score = int(self.config.get("recovery_score", 1))
        self.confirm_seconds = float(self.config.get("confirm_seconds", 1.2))
        self.recovery_seconds = float(self.config.get("recovery_seconds", 1.5))
        self.track_expire_seconds = float(
            self.config.get("track_expire_seconds", 3.0)
        )
        self.cooldown_seconds = float(self.config.get("cooldown_seconds", 10.0))
        self.snapshot_enabled = bool(self.config.get("snapshot_enabled", True))
        self.alert_callback = alert_callback
        self._tracks: Dict[int, _TrackState] = {}
        self._session_id = uuid.uuid4().hex[:10]
        self._last_closed_at: Dict[int, float] = {}

    @staticmethod
    def _midpoint(first: np.ndarray, second: np.ndarray) -> np.ndarray:
        return (first[:2] + second[:2]) / 2.0

    @staticmethod
    def _valid(points: np.ndarray, indexes: Sequence[int], threshold: float) -> bool:
        return all(
            0 <= index < len(points) and float(points[index][2]) >= threshold
            for index in indexes
        )

    def _features(
        self,
        track: Track,
        *,
        frame_height: int,
        now_monotonic: float,
        previous_center_y: Optional[float],
        previous_timestamp: Optional[float],
    ) -> Dict[str, Any]:
        x1, y1, x2, y2 = [float(value) for value in track.bbox]
        width = max(1.0, x2 - x1)
        height = max(1.0, y2 - y1)
        aspect = width / height
        center_y = (y1 + y2) / 2.0
        downward_speed = 0.0
        if previous_center_y is not None and previous_timestamp is not None:
            delta = now_monotonic - previous_timestamp
            if 0.02 <= delta <= 2.5 and frame_height > 0:
                downward_speed = max(
                    0.0,
                    (center_y - previous_center_y) / float(frame_height) / delta,
                )

        keypoints = np.asarray(track.keypoints, dtype=np.float32)
        torso_tilt: Optional[float] = None
        shoulder_hip_ratio: Optional[float] = None
        vertical_spread_ratio: Optional[float] = None
        valid_keypoint_count = 0

        if keypoints.shape == (17, 3):
            valid_mask = keypoints[:, 2] >= self.keypoint_confidence
            valid_keypoint_count = int(np.sum(valid_mask))
            valid_y = keypoints[valid_mask, 1]
            if valid_y.size >= 5:
                vertical_spread_ratio = float(
                    (float(np.max(valid_y)) - float(np.min(valid_y))) / height
                )

            if self._valid(keypoints, (5, 6, 11, 12), self.keypoint_confidence):
                shoulder = self._midpoint(keypoints[5], keypoints[6])
                hip = self._midpoint(keypoints[11], keypoints[12])
                vector = hip - shoulder
                # 与垂直方向夹角：站立接近 0°，横躺接近 90°。
                torso_tilt = float(
                    math.degrees(
                        math.atan2(abs(float(vector[0])), abs(float(vector[1])) + 1e-6)
                    )
                )
                shoulder_hip_ratio = float(abs(float(vector[1])) / height)

        flags = {
            "wide_bbox": aspect >= self.bbox_aspect_ratio,
            "horizontal_torso": (
                torso_tilt is not None and torso_tilt >= self.torso_angle_deg
            ),
            "compressed_torso_y": (
                shoulder_hip_ratio is not None
                and shoulder_hip_ratio <= self.shoulder_hip_vertical_ratio
            ),
            "compressed_keypoints_y": (
                vertical_spread_ratio is not None
                and vertical_spread_ratio <= self.keypoint_vertical_spread_ratio
            ),
            "fast_downward": downward_speed >= self.downward_speed_ratio_per_sec,
        }
        score = sum(1 for value in flags.values() if value)
        horizontal_evidence = bool(
            flags["wide_bbox"]
            or flags["horizontal_torso"]
            or (
                flags["compressed_torso_y"] and flags["compressed_keypoints_y"]
            )
        )
        suspected = score >= self.minimum_score and horizontal_evidence

        return {
            "bbox_aspect_ratio": aspect,
            "torso_tilt_deg": torso_tilt,
            "shoulder_hip_vertical_ratio": shoulder_hip_ratio,
            "keypoint_vertical_spread_ratio": vertical_spread_ratio,
            "downward_speed_ratio_per_sec": downward_speed,
            "valid_keypoint_count": valid_keypoint_count,
            "flags": flags,
            "score": score,
            "suspected": suspected,
            "center_y": center_y,
        }

    def _snapshot(self, frame: Optional[np.ndarray], track_id: int, suffix: str) -> Optional[str]:
        if not self.snapshot_enabled or frame is None:
            return None
        folder = self.event_dir / datetime.now().strftime("%Y-%m-%d")
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (
            f"fall_T{track_id}_{datetime.now().strftime('%H%M%S_%f')}_{suffix}.jpg"
        )
        return str(path) if cv2.imwrite(str(path), frame) else None

    @staticmethod
    def _identity_payload(binding: Optional[IdentityBinding]) -> Dict[str, Any]:
        if binding is None:
            return {
                "employee_id": None,
                "employee_code": None,
                "employee_name": None,
            }
        return {
            "employee_id": int(binding.employee_id),
            "employee_code": str(binding.employee_code),
            "employee_name": str(binding.employee_name),
        }

    def _confirm_fall(
        self,
        state: _TrackState,
        *,
        frame: Optional[np.ndarray],
        binding: Optional[IdentityBinding],
        features: Dict[str, Any],
        now_monotonic: float,
        now_wall: datetime,
        camera_device: str,
    ) -> None:
        identity = self._identity_payload(binding)
        state.employee_id = identity["employee_id"]
        state.employee_code = identity["employee_code"]
        state.employee_name = identity["employee_name"]
        alert_iso = now_wall.astimezone().isoformat(timespec="seconds")
        suspected_at = (
            datetime.fromtimestamp(
                now_wall.timestamp() - max(0.0, now_monotonic - (state.suspect_since or now_monotonic))
            )
            .astimezone()
            .isoformat(timespec="seconds")
        )
        snapshot = self._snapshot(frame, state.track_id, "alert")
        metadata = {
            "track_id": state.track_id,
            "camera_device": camera_device,
            "maximum_score": int(state.maximum_score),
            "latest_score": int(features["score"]),
            "features": {
                key: value
                for key, value in features.items()
                if key
                in {
                    "bbox_aspect_ratio",
                    "torso_tilt_deg",
                    "shoulder_hip_vertical_ratio",
                    "keypoint_vertical_spread_ratio",
                    "downward_speed_ratio_per_sec",
                    "valid_keypoint_count",
                    "flags",
                }
            },
        }
        event_id = self.database.open_event(
            event_scope="SAFETY",
            event_type="FALL",
            scope_key=f"fall:{self._session_id}:{state.track_id}",
            incident_id=self.database.new_incident_id(),
            round_id=None,
            shift_id=None,
            employee_id=state.employee_id,
            workstation_id=0,
            leave_at=suspected_at,
            leave_snapshot=snapshot,
            metadata=metadata,
        )
        self.database.mark_event_alert(event_id, alert_iso, snapshot)
        state.event_id = event_id
        state.event_started_iso = alert_iso
        state.metadata = metadata
        state.state = "FALLEN"
        state.fallen_since = now_monotonic
        state.recovery_since = None

        if self.alert_callback:
            self.alert_callback(
                {
                    "type": "fall",
                    "event_type": "FALL",
                    "event_id": event_id,
                    "track_id": state.track_id,
                    "employee_id": state.employee_id,
                    "employee_code": state.employee_code,
                    "employee_name": state.employee_name,
                    "score": int(features["score"]),
                    "message": (
                        f"检测到摔倒：{state.employee_code} {state.employee_name}"
                        if state.employee_name
                        else f"检测到未知人员摔倒：Track T{state.track_id}"
                    ),
                    "at": alert_iso,
                }
            )

    def _close_fall(
        self,
        state: _TrackState,
        *,
        frame: Optional[np.ndarray],
        now_monotonic: float,
        now_wall: datetime,
        reason: str,
    ) -> None:
        if state.event_id is not None:
            snapshot = self._snapshot(frame, state.track_id, "recovered")
            duration = max(0, int(round(now_monotonic - (state.fallen_since or now_monotonic))))
            self.database.close_event(
                state.event_id,
                return_at=now_wall.astimezone().isoformat(timespec="seconds"),
                duration_sec=duration,
                return_snapshot=snapshot,
                closed_reason=reason,
            )
        self._last_closed_at[state.track_id] = now_monotonic
        state.state = "NORMAL"
        state.suspect_since = None
        state.fallen_since = None
        state.recovery_since = None
        state.maximum_score = 0
        state.event_id = None
        state.event_started_iso = None
        state.metadata = {}

    def update(
        self,
        *,
        frame: Optional[np.ndarray],
        tracks: Sequence[Track],
        bindings: Dict[int, IdentityBinding],
        frame_height: int,
        camera_device: str,
        now_monotonic: Optional[float] = None,
        now_wall: Optional[datetime] = None,
    ) -> List[FallStatus]:
        if not self.enabled:
            return []
        monotonic_now = time.monotonic() if now_monotonic is None else float(now_monotonic)
        wall_now = datetime.now().astimezone() if now_wall is None else now_wall.astimezone()
        active_ids = {int(track.track_id) for track in tracks}
        results: List[FallStatus] = []

        for track in tracks:
            track_id = int(track.track_id)
            binding = bindings.get(track_id)
            if binding is None and not self.detect_unknown_person:
                continue
            state = self._tracks.setdefault(track_id, _TrackState(track_id=track_id))
            state.last_seen = monotonic_now
            features = self._features(
                track,
                frame_height=frame_height,
                now_monotonic=monotonic_now,
                previous_center_y=state.previous_center_y,
                previous_timestamp=state.previous_timestamp,
            )
            state.previous_center_y = float(features["center_y"])
            state.previous_timestamp = monotonic_now
            state.maximum_score = max(state.maximum_score, int(features["score"]))

            identity = self._identity_payload(binding)
            if binding is not None:
                previous_employee_id = state.employee_id
                state.employee_id = identity["employee_id"]
                state.employee_code = identity["employee_code"]
                state.employee_name = identity["employee_name"]
                if state.event_id is not None and previous_employee_id != state.employee_id:
                    self.database.update_event_identity(
                        state.event_id,
                        employee_id=state.employee_id,
                        metadata_updates={
                            "track_id": track_id,
                            "employee_code": state.employee_code,
                            "employee_name": state.employee_name,
                        },
                    )

            suspected = bool(features["suspected"])
            cooldown_ok = (
                monotonic_now - self._last_closed_at.get(track_id, -1e9)
                >= self.cooldown_seconds
            )

            if state.state == "NORMAL":
                if suspected and cooldown_ok:
                    state.state = "SUSPECTED"
                    state.suspect_since = monotonic_now
                    state.maximum_score = int(features["score"])
            elif state.state == "SUSPECTED":
                if not suspected:
                    state.state = "NORMAL"
                    state.suspect_since = None
                    state.maximum_score = 0
                elif monotonic_now - (state.suspect_since or monotonic_now) >= self.confirm_seconds:
                    self._confirm_fall(
                        state,
                        frame=frame,
                        binding=binding,
                        features=features,
                        now_monotonic=monotonic_now,
                        now_wall=wall_now,
                        camera_device=camera_device,
                    )
            elif state.state == "FALLEN":
                if int(features["score"]) <= self.recovery_score and not suspected:
                    state.state = "RECOVERING"
                    state.recovery_since = monotonic_now
                else:
                    state.recovery_since = None
            elif state.state == "RECOVERING":
                if suspected:
                    state.state = "FALLEN"
                    state.recovery_since = None
                elif monotonic_now - (state.recovery_since or monotonic_now) >= self.recovery_seconds:
                    self._close_fall(
                        state,
                        frame=frame,
                        now_monotonic=monotonic_now,
                        now_wall=wall_now,
                        reason="RECOVERED",
                    )

            suspect_elapsed = (
                max(0.0, monotonic_now - state.suspect_since)
                if state.suspect_since is not None
                else 0.0
            )
            fallen_elapsed = (
                max(0.0, monotonic_now - state.fallen_since)
                if state.fallen_since is not None
                else 0.0
            )
            message = {
                "NORMAL": "姿态正常",
                "SUSPECTED": f"疑似摔倒，确认倒计时 {max(0.0, self.confirm_seconds - suspect_elapsed):.1f}s",
                "FALLEN": "已确认摔倒",
                "RECOVERING": f"正在确认恢复 {max(0.0, self.recovery_seconds - (monotonic_now - (state.recovery_since or monotonic_now))):.1f}s",
            }.get(state.state, state.state)
            status = FallStatus(
                track_id=track_id,
                state=state.state,
                score=int(features["score"]),
                maximum_score=int(state.maximum_score),
                suspect_elapsed_sec=round(suspect_elapsed, 2),
                fallen_elapsed_sec=round(fallen_elapsed, 2),
                bbox_aspect_ratio=round(float(features["bbox_aspect_ratio"]), 3),
                torso_tilt_deg=(
                    round(float(features["torso_tilt_deg"]), 2)
                    if features["torso_tilt_deg"] is not None
                    else None
                ),
                shoulder_hip_vertical_ratio=(
                    round(float(features["shoulder_hip_vertical_ratio"]), 3)
                    if features["shoulder_hip_vertical_ratio"] is not None
                    else None
                ),
                keypoint_vertical_spread_ratio=(
                    round(float(features["keypoint_vertical_spread_ratio"]), 3)
                    if features["keypoint_vertical_spread_ratio"] is not None
                    else None
                ),
                downward_speed_ratio_per_sec=round(
                    float(features["downward_speed_ratio_per_sec"]), 3
                ),
                employee_id=state.employee_id,
                employee_code=state.employee_code,
                employee_name=state.employee_name,
                event_id=state.event_id,
                message=message,
            )
            state.latest_status = status
            results.append(status)

        for track_id, state in list(self._tracks.items()):
            if track_id in active_ids:
                continue
            if monotonic_now - state.last_seen < self.track_expire_seconds:
                continue
            if state.state in {"FALLEN", "RECOVERING"}:
                self._close_fall(
                    state,
                    frame=frame,
                    now_monotonic=monotonic_now,
                    now_wall=wall_now,
                    reason="TRACK_LOST",
                )
            self._tracks.pop(track_id, None)

        return results

    def close_all(self, reason: str = "SERVICE_STOPPED") -> None:
        monotonic_now = time.monotonic()
        wall_now = datetime.now().astimezone()
        for state in list(self._tracks.values()):
            if state.state in {"FALLEN", "RECOVERING"}:
                self._close_fall(
                    state,
                    frame=None,
                    now_monotonic=monotonic_now,
                    now_wall=wall_now,
                    reason=reason,
                )

    @staticmethod
    def serialize(statuses: Sequence[FallStatus]) -> List[Dict[str, Any]]:
        return [asdict(item) for item in statuses]
