(() => {
  const modelNames = {pose:'YOLOv8-Pose', retinaface:'RetinaFace', recognition:'W600K-MBF'};
  const fields = [
    ['dataset_name','验证集名称','text'], ['calibration_images','量化校准图片数','number'],
    ['evaluation_samples','验证样本数','number'], ['pt_map50_95','PT mAP50-95(%)','number'],
    ['rknn_map50_95','RKNN mAP50-95(%)','number'], ['precision','RKNN Precision(%)','number'],
    ['recall','RKNN Recall(%)','number'], ['notes','备注','text']
  ];
  const fmt = (v, digits=2) => v === null || v === undefined || v === '' ? '-' : Number(v).toFixed(digits);
  const esc = v => String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const duration = sec => { sec=Math.max(0,Number(sec||0)); const h=Math.floor(sec/3600); const m=Math.floor(sec%3600/60); const s=Math.floor(sec%60); return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`; };

  function renderModels(npu) {
    const body=document.getElementById('npu-model-body');
    const models=npu?.models||{};
    const rows=Object.entries(modelNames).map(([key,label])=>{
      const m=models[key]||{}; const lat=m.latency_ms||{};
      const input=m.input_shape?`${m.input_shape.join('×')} · ${m.input_dtype||'-'}`:'等待首次推理';
      return `<tr><td><strong>${label}</strong><small>${esc(m.model_path||'')}</small></td><td>${esc(m.execution_device||'-')}<br><b>Core ${esc(m.npu_core??'-')}</b></td><td><span class="badge info">${esc(m.quantization||'-')}</span><br><small>Toolkit ${esc(m.toolkit_version||'-')}</small></td><td>${fmt(m.model_size_mb,3)} MB</td><td>${esc(input)}</td><td>${m.calls??0}<br><small>错误 ${m.errors??0}</small></td><td>${fmt(m.actual_call_rate_fps,2)}</td><td>${fmt(lat.avg,2)} / ${fmt(lat.p50,2)} / ${fmt(lat.p95,2)} ms</td><td>${fmt(m.theoretical_inference_fps,2)}</td><td><span class="badge ${m.npu_verified?'success':'warning'}">${m.npu_verified?'NPU已验证':'等待调用'}</span></td></tr>`;
    });
    body.innerHTML=rows.join('');
  }

  function renderEvaluations(evaluations) {
    const root=document.getElementById('evaluation-grid');
    root.innerHTML=Object.entries(modelNames).map(([key,label])=>{
      const data=evaluations?.[key]||{};
      return `<form class="evaluation-card" data-model="${key}"><h3>${label}</h3><div class="evaluation-fields">${fields.map(([name,title,type])=>`<label><span>${title}</span><input name="${name}" type="${type}" ${type==='number'?'step="0.01" min="0"':''} value="${esc(data[name]??'')}"></label>`).join('')}</div><div class="evaluation-footer"><small>最后更新：${esc(data.updated_at||'未录入')}</small><button class="button primary" type="submit">保存评测数据</button></div></form>`;
    }).join('');
    root.querySelectorAll('form').forEach(form=>form.addEventListener('submit', saveEvaluation));
  }

  async function saveEvaluation(event) {
    event.preventDefault(); const form=event.currentTarget; const model=form.dataset.model;
    const payload={}; new FormData(form).forEach((value,key)=>payload[key]=value);
    try {
      const response=await fetch(`/api/model-evaluation/${model}`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
      const data=await response.json(); if(!response.ok) throw new Error(data.detail||`HTTP ${response.status}`);
      App.toast(`${modelNames[model]}评测数据已保存`); await refresh();
    } catch(error) { App.toast(`保存失败：${error.message}`, 'error'); }
  }

  let first=true;
  async function refresh() {
    try {
      const response=await fetch('/api/npu-metrics',{cache:'no-store'}); const data=await response.json(); if(!response.ok) throw new Error(`HTTP ${response.status}`);
      const npu=data.npu||{}, perf=data.performance||{};
      document.getElementById('npu-verified').textContent=npu.all_enabled_models_verified?'真实NPU推理中':'等待全部模型推理';
      document.getElementById('npu-platform').textContent=`${npu.platform||'RK3588'} · ${npu.backend||'RKNNLite'}`;
      document.getElementById('version-pair').textContent=`${npu.models?.pose?.toolkit_version||'-'} / ${npu.runtime_version_observed||'-'}`;
      document.getElementById('driver-version').textContent=npu.driver_version_observed||'-';
      document.getElementById('npu-frequency').textContent=npu.npu_frequency_hz?`频率 ${(npu.npu_frequency_hz/1e6).toFixed(0)} MHz`:`Governor ${npu.npu_governor||'-'}`;
      document.getElementById('camera-loop-fps').textContent=`${fmt(perf.camera_loop_fps,2)} FPS`;
      document.getElementById('runtime-uptime').textContent=`运行 ${duration(perf.runtime_uptime_sec)}`;
      document.getElementById('perf-camera').textContent=`${fmt(perf.camera_loop_fps,2)} FPS`;
      document.getElementById('perf-pose').textContent=`${fmt(perf.pose_actual_fps,2)} FPS`;
      document.getElementById('perf-face').textContent=`${fmt(perf.face_actual_fps,2)} FPS`;
      document.getElementById('perf-preview').textContent=`${fmt(perf.preview_actual_fps,2)} FPS`;
      document.getElementById('perf-tracks').textContent=data.track_count??0;
      document.getElementById('perf-falls').textContent=data.fall_summary?.fallen??0;
      document.getElementById('npu-load').textContent=npu.npu_load_raw||'当前内核未暴露 /sys/kernel/debug/rknpu/load；模型 inference 计数仍可证明实际NPU调用。';
      renderModels(npu); if(first){renderEvaluations(data.evaluations||{}); first=false;}
    } catch(error) { App.toast(`NPU数据刷新失败：${error.message}`, 'error'); }
  }
  refresh(); window.setInterval(refresh,1000);
})();
