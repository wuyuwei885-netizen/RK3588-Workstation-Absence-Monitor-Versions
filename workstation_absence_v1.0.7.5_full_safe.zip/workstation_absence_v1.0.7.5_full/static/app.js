const App = (() => {
  let audioContext = null;
  let latestStatus = null;
  let lastStatusAt = 0;
  let socket = null;
  let reconnectTimer = null;
  const listeners = [];

  async function api(url, options = {}) {
    const response = await fetch(url, options);
    let data = {};
    try { data = await response.json(); } catch (_) {}
    if (!response.ok) throw new Error(data.detail || `请求失败：${response.status}`);
    return data;
  }

  function toast(message, type = "info") {
    const element = document.getElementById("toast");
    if (!element) return;
    element.textContent = message;
    element.className = `toast ${type}`;
    setTimeout(() => element.classList.add("hidden"), 3200);
  }

  function beep() {
    try {
      audioContext = audioContext || new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.frequency.value = 900;
      gain.gain.value = 0.15;
      oscillator.connect(gain);
      gain.connect(audioContext.destination);
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 0.45);
    } catch (_) {}
  }

  function showAlarm(event) {
    if (!event) return;
    const text = document.getElementById("alarm-text");
    const panel = document.getElementById("alarm-panel");
    if (!text || !panel) return;
    const title = document.getElementById("alarm-title");
    if (event.type === "fall" || event.event_type === "FALL") {
      if (title) title.textContent = "摔倒告警";
      text.textContent = event.message || `Track T${event.track_id} 检测到摔倒`;
    } else if (event.type === "region_shortage_alert") {
      if (title) title.textContent = "区域缺员告警";
      text.textContent = `${event.workstation_name} · 区域缺员 ${event.present_count}/${event.required_count} · 已持续 ${event.elapsed_sec} 秒`;
    } else if (event.event_type === "NO_SHOW") {
      if (title) title.textContent = "未到岗告警";
      text.textContent = `${event.employee_code} ${event.employee_name} · ${event.workstation_name} · 未到岗 ${event.elapsed_sec} 秒`;
    } else {
      if (title) title.textContent = "空岗告警";
      text.textContent = `${event.employee_code} ${event.employee_name} · ${event.workstation_name} · 已缺勤 ${event.elapsed_sec} 秒`;
    }
    panel.classList.remove("hidden");
    beep();
  }

  function updateSystem(status) {
    if (!status) return;
    latestStatus = status;
    lastStatusAt = Date.now();

    const camera = status.camera || {};
    const pill = document.getElementById("camera-pill");
    if (pill) {
      pill.textContent = camera.online
        ? `${camera.active_device || "摄像头"} 在线`
        : "摄像头离线";
      pill.className = `system-pill ${camera.online ? "online" : "offline"}`;
    }

    for (const listener of listeners) {
      try {
        listener(status);
      } catch (error) {
        console.error("页面状态渲染失败：", error);
      }
    }
  }

  async function pollStatus(force = false) {
    if (!force && Date.now() - lastStatusAt < 2500) return;
    try {
      const status = await api("/api/status", {cache: "no-store"});
      updateSystem(status);
    } catch (error) {
      console.warn("状态轮询失败：", error);
    }
  }

  function connect() {
    if (socket && socket.readyState <= WebSocket.OPEN) return;

    const protocol = location.protocol === "https:" ? "wss:" : "ws:";
    socket = new WebSocket(`${protocol}//${location.host}/ws/live`);

    socket.onopen = () => {
      if (reconnectTimer) clearTimeout(reconnectTimer);
    };

    socket.onmessage = event => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.status) updateSystem(payload.status);
        if (payload.alert) showAlarm(payload.alert);
      } catch (error) {
        console.error("WebSocket消息解析失败：", error);
      }
    };

    socket.onerror = () => {
      try { socket.close(); } catch (_) {}
    };

    socket.onclose = () => {
      reconnectTimer = setTimeout(connect, 1500);
    };
  }

  function onStatus(listener) {
    listeners.push(listener);
    if (latestStatus) {
      try { listener(latestStatus); } catch (error) { console.error(error); }
    }
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
    })[char]);
  }

  connect();
  pollStatus(true);
  setInterval(() => pollStatus(false), 1000);

  return { api, toast, onStatus, escapeHtml, pollStatus };
})();

function dismissAlarm() {
  document.getElementById("alarm-panel")?.classList.add("hidden");
}

(function initControlLink(){
  const link=document.getElementById("control-backend-link");
  if(link) link.href=`${location.protocol}//${location.hostname}:8091/`;
})();
