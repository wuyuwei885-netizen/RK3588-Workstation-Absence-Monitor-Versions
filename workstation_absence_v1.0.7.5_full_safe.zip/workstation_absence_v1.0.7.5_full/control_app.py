#!/usr/bin/env python3
from __future__ import annotations

import argparse
import threading
import time
from pathlib import Path

import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from workstation.config import load_config
from workstation.control import DeviceInspector


def parse_args():
    parser = argparse.ArgumentParser(description="RK3588手机控制后台（局域网直达版）")
    parser.add_argument("--config", default="config.json", help="主系统配置文件")
    return parser.parse_args()


def _template_response(templates: Jinja2Templates, request: Request, name: str, context):
    payload = dict(context or {})
    payload["request"] = request
    try:
        return templates.TemplateResponse(request=request, name=name, context=payload)
    except TypeError:
        return templates.TemplateResponse(name, payload)


def create_control_app(config_path: str) -> FastAPI:
    config = load_config(config_path)
    root = Path(__file__).resolve().parent
    templates = Jinja2Templates(directory=str(root / "templates"))
    inspector = DeviceInspector(
        database_path=config.app["database"],
        main_port=int(config.control.get("main_port", config.app["port"])),
        control_port=int(config.control.get("port", 8091)),
        main_service=str(config.control.get("main_service", "workstation-absence.service")),
        camera_device=str(config.camera["device"]),
        status_timeout_sec=float(config.control.get("status_timeout_sec", 1.2)),
    )

    app = FastAPI(title="RK3588手机控制后台", docs_url=None, redoc_url=None)
    app.mount("/static", StaticFiles(directory=str(root / "static")), name="static")

    @app.get("/", response_class=HTMLResponse)
    async def dashboard(request: Request):
        status = inspector.collect()
        return _template_response(
            templates,
            request,
            "control_dashboard.html",
            {"status": status, "main_port": status["main_port"]},
        )

    @app.get("/api/status")
    async def api_status():
        return JSONResponse(inspector.collect())

    @app.post("/api/action/{action}")
    async def api_action(action: str):
        normalized = action.strip().lower()
        try:
            if normalized in {"start", "stop", "restart"}:
                return JSONResponse(inspector.controller.service_action(normalized))
            if normalized in {"reboot", "poweroff"}:
                # 先向手机返回成功，再延迟执行设备级操作。
                def delayed_action() -> None:
                    time.sleep(1.0)
                    inspector.controller.device_action(normalized)

                threading.Thread(target=delayed_action, daemon=True).start()
                return JSONResponse({"ok": True, "action": normalized, "scheduled": True})
            raise ValueError("未知操作")
        except Exception as exc:
            raise HTTPException(status_code=500, detail=str(exc)) from exc

    return app


def main() -> None:
    args = parse_args()
    config = load_config(args.config)
    app = create_control_app(str(config.source_path))
    uvicorn.run(
        app,
        host=str(config.control.get("host", "0.0.0.0")),
        port=int(config.control.get("port", 8091)),
        log_level="info",
        log_config=None,
    )


if __name__ == "__main__":
    main()
