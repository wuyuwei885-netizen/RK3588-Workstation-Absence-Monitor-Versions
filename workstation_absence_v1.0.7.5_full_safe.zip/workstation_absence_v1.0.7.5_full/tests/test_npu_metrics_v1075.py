import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

from workstation.models import RKNNBackend


class FakeRuntime:
    def inference(self, inputs):
        return [np.zeros((1, 4), dtype=np.float32)]
    def release(self):
        pass


class TestNpuMetrics(unittest.TestCase):
    def test_status_after_inference(self):
        with tempfile.NamedTemporaryFile(suffix='.rknn') as f:
            backend = object.__new__(RKNNBackend)
            backend.path = Path(f.name)
            backend.name = 'test'
            backend.core = '0'
            backend.config = {'quantization':'INT8','toolkit_version':'2.3.2'}
            backend.quantization = 'INT8'
            backend.toolkit_version = '2.3.2'
            import threading
            from collections import deque
            backend._lock = threading.RLock()
            backend._latencies = deque(maxlen=20)
            backend._timestamps = deque(maxlen=40)
            backend._calls = 0; backend._errors = 0
            backend._last_input_shape = None; backend._last_input_dtype = None
            backend._last_output_shapes = []; backend._last_inference_at = None
            backend._initialized_at = 'now'; backend.initialized = True
            backend.runtime = FakeRuntime()
            out, elapsed = backend.infer(np.zeros((1,4,4,3),dtype=np.uint8))
            status = backend.status()
            self.assertEqual(status['calls'], 1)
            self.assertEqual(status['input_dtype'], 'uint8')
            self.assertTrue(status['npu_verified'])
            self.assertEqual(status['quantization'], 'INT8')

if __name__ == '__main__': unittest.main()
