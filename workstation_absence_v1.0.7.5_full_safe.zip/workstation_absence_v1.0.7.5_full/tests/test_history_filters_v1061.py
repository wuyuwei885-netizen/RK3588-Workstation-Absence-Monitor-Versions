from __future__ import annotations

import unittest

from fastapi import HTTPException

from workstation.web import _clean_query_text, _optional_query_int


class HistoryFilterV1061Tests(unittest.TestCase):
    """板端兼容测试：不依赖Starlette TestClient/httpx2。"""

    def test_empty_select_values_become_none(self):
        self.assertIsNone(_optional_query_int("", "员工ID"))
        self.assertIsNone(_optional_query_int(None, "工作台ID"))
        self.assertIsNone(_clean_query_text(""))
        self.assertIsNone(_clean_query_text("   "))

    def test_non_empty_ids_are_converted_to_int(self):
        self.assertEqual(_optional_query_int("2", "员工ID"), 2)
        self.assertEqual(_optional_query_int(" 3 ", "工作台ID"), 3)

    def test_invalid_id_returns_clear_400(self):
        with self.assertRaises(HTTPException) as context:
            _optional_query_int("abc", "员工ID")
        self.assertEqual(context.exception.status_code, 400)
        self.assertEqual(context.exception.detail, "员工ID必须是整数")

    def test_non_positive_id_returns_clear_400(self):
        with self.assertRaises(HTTPException) as context:
            _optional_query_int("0", "工作台ID")
        self.assertEqual(context.exception.status_code, 400)
        self.assertEqual(context.exception.detail, "工作台ID必须大于0")


if __name__ == "__main__":
    unittest.main(verbosity=2)
