from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from workstation.database import Database


class HistoryDeleteTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / "workstation.db"
        payload = Database._empty_data()
        payload["counters"]["absence_events"] = 3
        payload["absence_events"] = [
            {
                "id": 1, "workstation_id": 1, "employee_id": 1,
                "leave_at": "2026-07-29T09:00:00+08:00", "status": "CLOSED",
                "event_scope": "PERSONAL", "event_type": "ABSENCE",
                "leave_status": "NONE", "record_version": "v1.0.6",
            },
            {
                "id": 2, "workstation_id": 1, "employee_id": None,
                "leave_at": "2026-07-29T10:00:00+08:00", "status": "CLOSED",
                "event_scope": "REGION", "event_type": "REGION_SHORTAGE",
                "leave_status": "NONE", "record_version": "v1.0.6",
            },
            {
                "id": 3, "workstation_id": 1, "employee_id": 1,
                "leave_at": "2026-07-30T10:00:00+08:00", "status": "OPEN",
                "event_scope": "PERSONAL", "event_type": "ABSENCE",
                "leave_status": "NONE", "record_version": "v1.0.6",
            },
        ]
        self.path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        self.db = Database(self.path)

    def tearDown(self):
        self.temp.cleanup()

    def test_delete_one_closed(self):
        deleted = self.db.delete_event(1)
        self.assertEqual(deleted["id"], 1)
        self.assertEqual([x["id"] for x in self.db._data["absence_events"]], [2, 3])

    def test_open_event_is_protected(self):
        with self.assertRaisesRegex(ValueError, "活动中的告警"):
            self.db.delete_event(3)

    def test_bulk_delete_keeps_open(self):
        result = self.db.delete_events(workstation_id=1, category="all")
        self.assertEqual(result["deleted_count"], 2)
        self.assertEqual(result["skipped_open"], 1)
        self.assertEqual([x["id"] for x in self.db._data["absence_events"]], [3])


if __name__ == "__main__":
    unittest.main(verbosity=2)
