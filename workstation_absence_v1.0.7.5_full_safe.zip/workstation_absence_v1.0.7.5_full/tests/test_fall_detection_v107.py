from __future__ import annotations

import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np

from workstation.database import Database
from workstation.fall_detection import FallDetector
from workstation.tracker import Track


def horizontal_track(track_id: int = 1) -> Track:
    keypoints = np.zeros((17, 3), dtype=np.float32)
    keypoints[:, 2] = 0.95
    keypoints[:, 0] = np.linspace(110, 290, 17)
    keypoints[:, 1] = 160
    keypoints[5] = [120, 150, 0.95]
    keypoints[6] = [130, 170, 0.95]
    keypoints[11] = [220, 150, 0.95]
    keypoints[12] = [230, 170, 0.95]
    return Track(
        track_id=track_id,
        bbox=np.asarray([100, 120, 310, 210], dtype=np.float32),
        score=0.95,
        keypoints=keypoints,
    )


def standing_track(track_id: int = 1) -> Track:
    keypoints = np.zeros((17, 3), dtype=np.float32)
    keypoints[:, 2] = 0.95
    keypoints[:, 0] = 140
    keypoints[:, 1] = np.linspace(70, 330, 17)
    keypoints[5] = [125, 120, 0.95]
    keypoints[6] = [155, 120, 0.95]
    keypoints[11] = [130, 220, 0.95]
    keypoints[12] = [150, 220, 0.95]
    return Track(
        track_id=track_id,
        bbox=np.asarray([100, 50, 180, 350], dtype=np.float32),
        score=0.95,
        keypoints=keypoints,
    )


class FallDetectorV107Tests(unittest.TestCase):
    def test_full_frame_fall_opens_and_recovers_event(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            database = Database(root / "workstation.db")
            detector = FallDetector(
                database=database,
                event_dir=root / "events",
                config={
                    "enabled": True,
                    "detect_unknown_person": True,
                    "minimum_score": 3,
                    "confirm_seconds": 1.0,
                    "recovery_seconds": 1.0,
                    "cooldown_seconds": 0.0,
                    "snapshot_enabled": False,
                },
            )
            base_wall = datetime(2026, 7, 30, 15, 0, tzinfo=timezone.utc)
            first = detector.update(
                frame=None,
                tracks=[horizontal_track()],
                bindings={},
                frame_height=480,
                camera_device="/dev/video22",
                now_monotonic=100.0,
                now_wall=base_wall,
            )
            self.assertEqual(first[0].state, "SUSPECTED")
            confirmed = detector.update(
                frame=None,
                tracks=[horizontal_track()],
                bindings={},
                frame_height=480,
                camera_device="/dev/video22",
                now_monotonic=101.2,
                now_wall=base_wall + timedelta(seconds=1.2),
            )
            self.assertEqual(confirmed[0].state, "FALLEN")
            events = database.query_events(category="fall")
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0]["status"], "OPEN")
            self.assertEqual(events[0]["metadata"]["track_id"], 1)

            recovering = detector.update(
                frame=None,
                tracks=[standing_track()],
                bindings={},
                frame_height=480,
                camera_device="/dev/video22",
                now_monotonic=101.4,
                now_wall=base_wall + timedelta(seconds=1.4),
            )
            self.assertEqual(recovering[0].state, "RECOVERING")
            normal = detector.update(
                frame=None,
                tracks=[standing_track()],
                bindings={},
                frame_height=480,
                camera_device="/dev/video22",
                now_monotonic=102.6,
                now_wall=base_wall + timedelta(seconds=2.6),
            )
            self.assertEqual(normal[0].state, "NORMAL")
            events = database.query_events(category="fall")
            self.assertEqual(events[0]["status"], "CLOSED")
            self.assertEqual(events[0]["closed_reason"], "RECOVERED")

    def test_standing_person_does_not_trigger(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            database = Database(root / "workstation.db")
            detector = FallDetector(
                database=database,
                event_dir=root / "events",
                config={"snapshot_enabled": False},
            )
            statuses = detector.update(
                frame=None,
                tracks=[standing_track()],
                bindings={},
                frame_height=480,
                camera_device="/dev/video22",
                now_monotonic=200.0,
                now_wall=datetime.now(timezone.utc),
            )
            self.assertEqual(statuses[0].state, "NORMAL")
            self.assertEqual(database.query_events(category="fall"), [])


if __name__ == "__main__":
    unittest.main()
