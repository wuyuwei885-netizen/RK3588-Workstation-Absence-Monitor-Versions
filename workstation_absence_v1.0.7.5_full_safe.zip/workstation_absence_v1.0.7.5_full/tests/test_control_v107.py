from __future__ import annotations

import subprocess
import tempfile
import unittest
from pathlib import Path

from workstation.control import DeviceInspector, ServiceController


class ControlV107Tests(unittest.TestCase):
    def test_service_actions_are_fixed_whitelist(self):
        controller = ServiceController("workstation-absence.service", backend="systemd")
        calls = []

        def fake_run(args, timeout=25.0):
            calls.append(args)
            return subprocess.CompletedProcess(args, 0, stdout="", stderr="")

        controller._run = fake_run  # type: ignore[method-assign]
        controller.service_action("restart")
        self.assertEqual(
            calls[-1],
            ["systemctl", "restart", "workstation-absence.service"],
        )
        with self.assertRaises(ValueError):
            controller.service_action("restart; rm -rf /")

    def test_status_contains_real_runtime_fields(self):
        with tempfile.TemporaryDirectory() as directory:
            db = Path(directory) / "workstation.db"
            db.write_text(
                '{"shifts":[{"status":"ACTIVE"}],"absence_events":['
                '{"status":"OPEN","event_type":"FALL"}]}'
            )
            inspector = DeviceInspector(
                database_path=db,
                main_port=8090,
                control_port=8091,
                main_service="workstation-absence.service",
                camera_device="/dev/video22",
            )
            inspector.controller.state = lambda: {"state": "active", "running": True, "returncode": 0}  # type: ignore[method-assign]
            inspector._main_status = lambda: {  # type: ignore[method-assign]
                "state": "running",
                "camera": {"online": True, "active_device": "/dev/video22"},
                "model_paths": {"pose": "/m/pose.rknn", "retinaface": "/m/face.rknn", "recognition": "/m/rec.rknn"},
            }
            inspector._ip_addresses = lambda: [{"interface": "eth0", "address": "192.168.10.66", "kind": "有线网络"}]  # type: ignore[method-assign]
            status = inspector.collect()
            self.assertTrue(status["service"]["running"])
            self.assertEqual(status["counts"]["active_shifts"], 1)
            self.assertEqual(status["counts"]["open_alerts"], 1)
            self.assertEqual(status["counts"]["open_falls"], 1)
            self.assertEqual(status["ips"][0]["address"], "192.168.10.66")
            self.assertEqual(status["primary_ip"], "192.168.10.66")
            self.assertEqual(status["models"]["pose"]["state"], "正常")


if __name__ == "__main__":
    unittest.main()
