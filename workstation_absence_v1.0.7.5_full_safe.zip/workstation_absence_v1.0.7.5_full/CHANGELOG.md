# CHANGELOG

## 1.0.7.5
- 支持用户固定命令直接启动；自动停止旧的同项目 app.py，避免 8090 Address already in use。
- app.py 自动维护 /var/run/workstation-absence.pid，手机控制后台可管理手工启动进程。
- 新增 /npu NPU量化与推理数据后台。
- 记录真实 RKNNLite inference 调用次数、延迟 Avg/P50/P95、实际调度FPS、理论FPS、输入dtype/shape、模型大小与NPU Core。
- 新增离线量化精度数据录入，保存至 data/model_evaluation.json。
- 不下载或替换 RKNN Runtime，不修改 rknn310 虚拟环境。
