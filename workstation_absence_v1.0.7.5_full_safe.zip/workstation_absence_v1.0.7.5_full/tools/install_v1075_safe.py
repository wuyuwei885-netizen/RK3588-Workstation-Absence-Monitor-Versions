#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, Iterable

VERSION = "1.0.7.5"
DEFAULT_TARGET = Path("/root/workstation_absence")
DEFAULT_VENV = Path("/root/yolov8_rk3588/rknn310")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="v1.0.7.5安全安装器：只部署项目代码和SysV服务，不修改RKNN/虚拟环境"
    )
    parser.add_argument("--target", default=str(DEFAULT_TARGET), help="项目安装目录")
    parser.add_argument("--venv", default=str(DEFAULT_VENV), help="现有Python虚拟环境目录")
    parser.add_argument("--no-start", action="store_true", help="安装后不启动服务")
    return parser.parse_args()


def run(args: Iterable[str], *, check: bool = False, timeout: float = 120.0) -> subprocess.CompletedProcess[str]:
    command = [str(item) for item in args]
    print("+", " ".join(command))
    return subprocess.run(
        command,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=check,
    )


def merge_missing(current: Any, defaults: Any) -> Any:
    if isinstance(current, dict) and isinstance(defaults, dict):
        result = dict(current)
        for key, value in defaults.items():
            if key in result:
                result[key] = merge_missing(result[key], value)
            else:
                result[key] = value
        return result
    return current


def copy_item(source: Path, target: Path) -> None:
    if source.is_dir():
        shutil.copytree(source, target, dirs_exist_ok=True)
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def stop_service(path: Path) -> None:
    if not path.is_file():
        return
    result = run([str(path), "stop"], timeout=40)
    if result.stdout.strip():
        print(result.stdout.rstrip())


def stop_manual_python(target: Path) -> None:
    """只停止该项目的 app.py/control_app.py，不触碰其他Python或虚拟环境。"""
    current_pid = os.getpid()
    parent_pid = os.getppid()
    result = subprocess.run(
        ["ps", "-eo", "pid=,args="],
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    needles = (
        str(target / "app.py"),
        str(target / "control_app.py"),
    )
    for line in result.stdout.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        pid_text, _, command = stripped.partition(" ")
        try:
            pid = int(pid_text)
        except ValueError:
            continue
        if pid in {current_pid, parent_pid}:
            continue
        if any(needle in command for needle in needles):
            print(f"停止旧项目进程 PID={pid}: {command}")
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass


def backup_target(target: Path, timestamp: str) -> Path:
    backup = target.parent / f"{target.name}_backup_v1075_{timestamp}"
    backup.mkdir(parents=True, exist_ok=False)
    names = [
        "app.py",
        "control_app.py",
        "workstation",
        "templates",
        "static",
        "tools",
        "tests",
        "init.d",
        "config.json",
        "config.example.json",
        "README.md",
        "VERSION",
    ]
    for name in names:
        source = target / name
        if source.exists():
            copy_item(source, backup / name)

    # 只额外备份数据库文件，不复制整个人脸/截图目录。
    config_path = target / "config.json"
    database_path = target / "data" / "workstation.db"
    if config_path.is_file():
        try:
            data = json.loads(config_path.read_text(encoding="utf-8"))
            configured = data.get("app", {}).get("database")
            if configured:
                database_path = Path(str(configured)).expanduser()
        except (OSError, json.JSONDecodeError):
            pass
    if database_path.is_file():
        shutil.copy2(database_path, backup / "workstation.db")
    return backup


def deploy_source(source_root: Path, target: Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    skip = {
        "config.json",
        "data",
        ".git",
        "__pycache__",
    }
    for item in source_root.iterdir():
        if item.name in skip or item.suffix == ".zip":
            continue
        destination = target / item.name
        if item.name == "models":
            destination.mkdir(parents=True, exist_ok=True)
            readme = item / "README.md"
            if readme.is_file():
                shutil.copy2(readme, destination / "README_v1075.md")
            continue
        copy_item(item, destination)

    for cache in target.rglob("__pycache__"):
        shutil.rmtree(cache, ignore_errors=True)
    for pyc in target.rglob("*.pyc"):
        pyc.unlink(missing_ok=True)


def configure_project(target: Path) -> Dict[str, Any]:
    example_path = target / "config.example.json"
    config_path = target / "config.json"
    defaults = json.loads(example_path.read_text(encoding="utf-8"))

    if config_path.is_file():
        try:
            current = json.loads(config_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"现有 config.json 不是有效JSON，已停止安装：{exc}") from exc
    else:
        current = {}

    merged = merge_missing(current, defaults)
    merged.setdefault("app", {})
    merged.setdefault("fall_detection", {})
    merged.setdefault("control", {})

    # 保留用户原有模型、摄像头、数据库路径；仅确保新功能被启用。
    merged["fall_detection"]["enabled"] = True
    merged["fall_detection"]["detect_unknown_person"] = True
    merged["control"]["host"] = "0.0.0.0"
    merged["control"]["port"] = 8091
    merged["control"]["main_port"] = int(merged["app"].get("port", 8090))
    merged["control"]["main_service"] = "workstation-absence.service"

    config_path.write_text(
        json.dumps(merged, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return merged


def patch_init_script(source: Path, destination: Path, *, target: Path, python: Path, port: int) -> None:
    text = source.read_text(encoding="utf-8")
    replacements = {
        "WORKDIR": str(target),
        "PYTHON": str(python),
        "PORT": str(port),
    }
    for key, value in replacements.items():
        pattern = rf'(?m)^{key}="[^"]*"$'
        text, count = re.subn(pattern, f'{key}="{value}"', text, count=1)
        if count != 1:
            raise RuntimeError(f"服务脚本缺少 {key} 配置：{source}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(text, encoding="utf-8")
    destination.chmod(0o755)


def install_services(target: Path, python: Path, config: Dict[str, Any], timestamp: str) -> None:
    init_dir = Path("/etc/init.d")
    init_dir.mkdir(parents=True, exist_ok=True)
    main_dst = init_dir / "workstation-absence"
    control_dst = init_dir / "workstation-control"

    for path in (main_dst, control_dst):
        if path.exists():
            shutil.copy2(path, path.with_name(path.name + f".bak_{timestamp}"))

    patch_init_script(
        target / "init.d" / "workstation-absence",
        main_dst,
        target=target,
        python=python,
        port=int(config["app"].get("port", 8090)),
    )
    patch_init_script(
        target / "init.d" / "workstation-control",
        control_dst,
        target=target,
        python=python,
        port=int(config["control"].get("port", 8091)),
    )

    # 兼容该板卡的 BusyBox/SysVinit。只创建启动链接，不安装systemd。
    link_specs = [
        ("/etc/rcS.d/S98workstation-absence", main_dst),
        ("/etc/rcS.d/S99workstation-control", control_dst),
    ]
    for level in (2, 3, 4, 5):
        link_specs.extend(
            [
                (f"/etc/rc{level}.d/S98workstation-absence", main_dst),
                (f"/etc/rc{level}.d/S99workstation-control", control_dst),
            ]
        )
    for level in (0, 1, 6):
        link_specs.extend(
            [
                (f"/etc/rc{level}.d/K01workstation-control", control_dst),
                (f"/etc/rc{level}.d/K02workstation-absence", main_dst),
            ]
        )

    for link_text, destination in link_specs:
        link = Path(link_text)
        link.parent.mkdir(parents=True, exist_ok=True)
        if link.is_symlink() or link.exists():
            link.unlink()
        link.symlink_to(destination)


def verify_required_files(target: Path, python: Path) -> None:
    required = [
        target / "app.py",
        target / "control_app.py",
        target / "workstation" / "fall_detection.py",
        target / "workstation" / "runtime.py",
        target / "workstation" / "control.py",
        target / "templates" / "control_dashboard.html",
        target / "templates" / "npu_metrics.html",
        target / "static" / "npu_metrics.js",
        target / "static" / "control.js",
        python,
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError("安装后仍缺少必要文件：\n" + "\n".join(missing))


def verify_model_paths(config: Dict[str, Any]) -> None:
    print("\n模型路径检查（只读，不下载、不转换、不替换）：")
    for key, item in config.get("models", {}).items():
        if not item.get("enabled", True):
            print(f"  {key}: 已禁用")
            continue
        path = Path(str(item.get("path", ""))).expanduser()
        print(f"  {key}: {'存在' if path.is_file() else '缺失'} -> {path}")


def http_code(url: str, timeout: float = 3.0) -> int:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            return int(response.status)
    except (urllib.error.URLError, TimeoutError, OSError):
        return 0


def main() -> int:
    args = parse_args()
    source_root = Path(__file__).resolve().parent.parent
    target = Path(args.target).expanduser().resolve()
    venv = Path(args.venv).expanduser().resolve()
    python = venv / "bin" / "python"
    timestamp = time.strftime("%Y%m%d_%H%M%S")

    print("=" * 68)
    print(f"workstation_absence v{VERSION} 安全完整包安装")
    print("本安装器不会执行 curl/wget/pip/apt，不会修改或删除 rknn-toolkit、虚拟环境、librknnrt.so。")
    print(f"源码目录：{source_root}")
    print(f"目标目录：{target}")
    print(f"现有环境：{venv}")
    print("=" * 68)

    if not python.is_file():
        raise FileNotFoundError(f"现有虚拟环境Python不存在：{python}")
    if not (source_root / "workstation" / "fall_detection.py").is_file():
        raise FileNotFoundError("完整包损坏：缺少 workstation/fall_detection.py")

    stop_service(Path("/etc/init.d/workstation-absence"))
    stop_service(Path("/etc/init.d/workstation-control"))
    stop_manual_python(target)
    time.sleep(1)

    if target.exists() and source_root != target:
        backup = backup_target(target, timestamp)
        print(f"已备份现有代码和数据库：{backup}")
    elif source_root == target:
        print("源码目录就是目标目录，跳过代码复制。")

    if source_root != target:
        deploy_source(source_root, target)

    config = configure_project(target)
    verify_required_files(target, python)
    install_services(target, python, config, timestamp)
    verify_model_paths(config)

    print("\n环境保护检查：")
    print(f"  rknn虚拟环境仍使用：{venv}")
    print("  未下载RKNN Runtime")
    print("  未替换 /usr/lib/librknnrt.so")
    print("  未删除任何 rknn-toolkit 文件")

    if args.no_start:
        print("\n安装完成，按 --no-start 要求未启动服务。")
        return 0

    control_result = run(["/etc/init.d/workstation-control", "restart"], timeout=45)
    print(control_result.stdout.rstrip())
    main_result = run(["/etc/init.d/workstation-absence", "restart"], timeout=120)
    print(main_result.stdout.rstrip())

    main_port = int(config["app"].get("port", 8090))
    control_port = int(config["control"].get("port", 8091))
    main_http = http_code(f"http://127.0.0.1:{main_port}/api/status")
    control_http = http_code(f"http://127.0.0.1:{control_port}/")

    print("\n" + "=" * 68)
    print(f"安装结果：主系统 HTTP={main_http}，控制后台 HTTP={control_http}")
    print(f"实时监控：http://<真实IP>:{main_port}/monitor")
    print(f"历史记录：http://<真实IP>:{main_port}/history")
    print(f"NPU量化后台：http://<真实IP>:{main_port}/npu")
    print("直接启动命令：source /root/yolov8_rk3588/rknn310/bin/activate && cd /root/workstation_absence && export PYTHONPATH=/root/workstation_absence && python app.py --config config.json")
    print(f"手机控制：http://<真实IP>:{control_port}/")
    print("摔倒检测：全画面所有Pose Track，包括UNKNOWN人员")
    print("=" * 68)

    if control_result.returncode != 0 or control_http != 200:
        print("控制后台启动失败，查看：tail -n 120 /var/log/workstation-control.log")
        return 2
    if main_result.returncode != 0 or main_http != 200:
        print("主系统启动失败，查看：tail -n 160 /var/log/workstation-absence.log")
        return 3
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"\n安装失败：{type(exc).__name__}: {exc}", file=sys.stderr)
        print("没有执行环境删除或RKNN Runtime替换。", file=sys.stderr)
        raise SystemExit(1)
