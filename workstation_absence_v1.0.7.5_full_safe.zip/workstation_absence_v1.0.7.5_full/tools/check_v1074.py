#!/usr/bin/env python3
from __future__ import annotations

import json
import py_compile
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REQUIRED = [
    "app.py",
    "control_app.py",
    "workstation/fall_detection.py",
    "workstation/runtime.py",
    "workstation/control.py",
    "workstation/web.py",
    "templates/control_dashboard.html",
    "templates/monitor.html",
    "templates/history.html",
    "static/control.js",
    "static/control.css",
    "init.d/workstation-absence",
    "init.d/workstation-control",
]


def main() -> int:
    failures = []
    for relative in REQUIRED:
        path = ROOT / relative
        ok = path.is_file()
        print(f"{'PASS' if ok else 'FAIL'} {relative}")
        if not ok:
            failures.append(relative)

    for path in sorted(ROOT.rglob("*.py")):
        if "__pycache__" in path.parts:
            continue
        try:
            py_compile.compile(str(path), doraise=True)
        except py_compile.PyCompileError as exc:
            failures.append(str(path.relative_to(ROOT)))
            print(f"FAIL Python编译：{path.relative_to(ROOT)} -> {exc.msg}")

    config_path = ROOT / "config.example.json"
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
        assert config["fall_detection"]["enabled"] is True
        assert config["fall_detection"]["detect_unknown_person"] is True
        assert int(config["control"]["port"]) == 8091
        print("PASS 配置：摔倒检测启用、UNKNOWN启用、控制端口8091")
    except Exception as exc:
        failures.append("config.example.json")
        print(f"FAIL 配置：{exc}")

    if failures:
        print("\n检查失败：", ", ".join(failures))
        return 1
    print("\n完整包静态检查通过。该检查不加载RKNN模型，也不修改环境。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
